# CINEMORA audit (2026-10-19)

## What was and was not tested
| Area | How | Result |
|---|---|---|
| Shared logic (sources, availability, downloads rules, search, metadata client, subtitles, translation) | 24 unit tests (`npm run test:shared`) + strict `tsc` on `shared/` | All pass |
| Web app behavior | Real `src/` code bundled with esbuild and run in headless Chromium, with a router stand-in, mocked TMDB/translation, generated audio for the "video". 25 tests, run at 1280x800 and at a 390x844 touch viewport | 25/25 pass on both, no runtime errors |
| Static scan (all web, mobile, server code) | Link targets vs routes, dead controls, XSS patterns, hardcoded secrets, CORS, supply chain | See findings |
| Layout / mobile viewport | Real CSS only exists in the single-file prototype: measured at 320, 390, 768, 1280 px | Fixed (see below) |
| **Not tested** | React web app styling and responsiveness (Tailwind not installed here); real react-router; any real TMDB, Supabase, DeepL or LibreTranslate call; whether the Internet Archive URLs actually play (no network); the entire Android app (never run, never type-checked); downloads on a device; the three server functions; web `src` type-checking (no React types here) | Needs your machine/device |

## Bugs found and fixed in this audit
1. **Prototype claimed titles were streamable/downloadable with no verified source** (Nosferatu, Metropolis, etc.). Corrected and republished: nothing in the prototype is playable.
2. **Home rows vanished**: a title in several TMDB lists kept only its first list, so "Top rated"/"Recently added" could be empty. Titles now keep every list.
3. **"Try again" after a failed search/Explore load fetched page 2 instead of retrying page 1** (web and Android).
4. **Player never saved position** when you seeked or left the page without pausing (web). Now saved on seek and on leaving.
5. **Search missed swapped letters ("sintle") and joined words ("madmax") and matched almost everything for one letter ("a")**. Search is now 20/20 on the test list.
6. **Prototype scrolled sideways on phones** (nav overflow at 320 and 390 px). Fixed.
7. **Android tab screens would draw under the status bar** (edge-to-edge). Headings now respect the safe area.
8. **Web content could sit under the notch in an installed PWA, and mobile web had no logo**. Added top safe-area padding and a mobile logo.
9. **"Recently added" was a misleading label** (TMDB now-playing = in cinemas). Renamed "Now in cinemas".
10. `delete-user` function had a hard-coded wildcard CORS; now follows `ALLOWED_ORIGIN` like the others.

## Working features (with the evidence level)
- Navigation: every top-nav and bottom-nav link, unknown routes (fall back to Home), deep links to details/watch, Sources page. (browser tests, router stand-in; static check found no broken targets in web or Android)
- Catalog: home rows, hero, sample vs live labeling, TMDB attribution notice. (browser, mocked TMDB)
- Search: suggestions, results, "Load more" pagination, empty state, error + retry, offline message, request encoding. (browser + unit)
- Explore: genre, language, year filters with pagination; partial years not sent. (browser)
- Details: full metadata load, inline error when details fail, 404 handling, watchlist persistence. (browser)
- Availability rules: withdrawn, expired, unverified, no-streaming, territory; download rules (license, DRM, HLS). (unit)
- Player: authorized source loads, speed, resume, unreachable source shows an error and Try again recovers, titles without a source can't be played. Uses a generated audio file, not the real films. (browser)
- Subtitles: SRT/WebVTT import, correct timing, gaps hidden, size and delay, persistence, bad-file rejection. (browser + unit)
- Translation: offered only when the server lists the language; machine-translated label; timing unchanged; provider failure, quota, unreachable service handled; nothing shown when not configured. (browser with a mock provider + unit)
- Settings: country persists; Downloads and Sources pages render; account card says accounts are optional when Supabase is unset.
- Written but untested on a device: the whole Android app, offline downloads, Supabase sign-in and sync, the three server functions.

## Remaining limitations
**Playback and sources**
- Three playable titles only (Blender films). Their URLs are built from Internet Archive listings and were not played. They are third-party uploads, so file integrity is unverified.
- Sources are bundled in the app. A takedown or expired license needs a new build (or the planned `sources` table) to take effect, including for already-downloaded copies.
- Regional checks use the country the user selects; this is not enforcement. All current sources are worldwide.
- No HLS/DASH, no quality or audio-track choice, no next-episode (no series).

**Search and metadata**
- With TMDB, search matches titles only (no actor, director, plot or genre words). Sample records have no director. Typo tolerance there is TMDB's.
- In live mode the Nollywood, Bollywood, Hollywood, Classic and International rows contain only sample records; genre rows come from the ~60 loaded titles.
- TMDB lists give no country, runtime or cast until a title is opened. Sample records have no posters.
- Related titles come only from loaded titles. No ratings, reviews, content ratings, available audio/subtitle languages.

**Controls and features not built or not wired**
- Saved "preferred subtitle language" and "audio language" don't affect playback. Subtitle delay isn't saved; no subtitle colors; no "report translation error".
- Web subtitles don't show in the browser's native fullscreen; Android subtitles don't show in native fullscreen or picture-in-picture.
- No parental controls, profiles, password reset or social login. Android has no sign-in. Account deletion needs the `delete-user` function deployed.
- Downloads run only while the app is open; no Wi-Fi-only option, notifications or offline HLS.
- PWA install may need 192/512 px PNG icons; offline mode caches only the app shell and data, not video.
- Accessibility not audited with a screen reader; React app tap-target sizes not measured (no CSS here).

## Security findings
- **No XSS patterns, hardcoded secrets, `http://` URLs, or unsafe external links** in the code. Subtitles are rendered as plain text. Uploads are capped at 2 MB.
- **Public anon key can call the TMDB and translation proxies**: anyone could spend your quota. There is no per-user rate limit; CORS defaults to `*` if `ALLOWED_ORIGIN` is unset. Set `ALLOWED_ORIGIN`, provider spending caps, and consider `REQUIRE_USER=true` or a rate-limiting layer.
- **Android dependencies are pinned to `*` with no lockfile**: builds are not reproducible and exposed to supply-chain changes. Run `npx expo install --fix`, commit the lockfile, run `npm audit`.
- **No Content-Security-Policy** is set. Suggested: `connect-src` your proxies, `img-src` image.tmdb.org, `media-src` *.archive.org.
- **Privacy**: video requests go to archive.org (and its redirect hosts) and poster requests to TMDB's CDN, exposing user IPs. A privacy policy is needed (also for Google Play's data-safety form).
- Supabase sessions live in browser storage, the normal pattern but sensitive to any future XSS. Region gating and sources are client-side and visible to users.
- Row-level security is defined for user tables; policies were not exercised against a live database.

## External services and credentials
| Need | For | Required? |
|---|---|---|
| TMDB API read token + a deployed proxy | All live metadata | Optional (app falls back to labeled samples) |
| Supabase project (anon key; functions deployed) | Accounts, sync, hosting the proxies | Optional |
| DeepL API key **or** a LibreTranslate server | Subtitle translation | Optional (feature hidden without it) |
| Expo account | Cloud APK builds (local builds don't need one) | Optional |
| Google Play developer account | Publishing on Google Play | Only to publish |
| A web host + HTTPS + domain | Public web app and PWA install | To go public |

## Costs beyond free quotas (figures are what I last knew or found; confirm each before launch)
- **TMDB**: free for non-commercial use only. Commercial use (including sponsorship revenue) needs a paid agreement; price not published to me.
- **Supabase**: free tier has limits on database size, monthly users, function calls and bandwidth, and free projects can pause when inactive. The Pro plan was about $25/month. Public use of the proxies can burn function calls.
- **DeepL API**: free plan about 500,000 characters/month; beyond that pay per character. A feature film's subtitles are roughly 40,000-60,000 characters (my estimate), so about 8-12 films a month on the free plan. Each uncached translation counts. Dozens of users translating can exceed it quickly.
- **LibreTranslate**: free software, but you pay for a server (typically a few dollars to ~$10+ a month for enough memory), or for a hosted plan.
- **Expo EAS**: free plan about 15 Android builds/month in a slow queue; Starter was about $19/month. Local builds are free.
- **Google Play**: one-time registration fee (about $25). Apple (if you ever add iOS): about $99/year.
- **Video bandwidth**: linking to the Internet Archive costs you nothing but depends on their goodwill and limits. If you host your own copies, expect storage plus egress: e.g. a 1 GB film watched 1,000 times is about 1 TB of transfer (tens of dollars on typical clouds, less with zero-egress providers).
- **Web hosting/domain**: static hosting has free tiers; a domain is typically $10-20/year.
- **Hidden cost risks**: unauthenticated proxies, traffic spikes, translation of long files, and moving to commercial TMDB use.

---
## v0.10 fixes (after the audit)
Changes made, all re-tested with the same harness (27 browser tests at desktop and 390 px touch viewports, 29 unit tests; same limits as above):
1. **App icons**: real PNG icons (192, 512, maskable 512, 180 px `apple-touch-icon`) and Android icon + adaptive icon; manifest and `index.html` updated. Not yet seen on a real phone's home screen.
2. **Server abuse protection** (`supabase/functions/_shared/guard.ts`, used by `tmdb`, `translate`, `delete-user`): browsers on other sites are refused (403); with `ALLOWED_ORIGIN` unset only localhost is accepted (fails closed, replacing the old wildcard); per-IP rate limit (default 120/min for TMDB, 30/min for translation, 5/min for account deletion; `RATE_LIMIT_PER_MIN` to change). The limit is best-effort per function instance. Guard logic is unit tested; the functions themselves were not run (no Deno here).
3. **Security headers**: `public/_headers` (CSP, no-referrer, nosniff, permissions policy, frame blocking) for Netlify/Cloudflare-style hosts, plus a `no-referrer` meta tag. Replace `YOUR-PROJECT` in the CSP. The CSP was not exercised in a browser, so check the console for blocked requests after deploying.
4. **Release/security gate** (`scripts/check-env.cjs`): runs before `npm run build` and as `npm run release-check` in `mobile/`. It fails if a public variable looks like a secret (service-role key, TMDB token, provider key, `http://` URL) and, for release, if the Android package is still `com.example.*`, icons are missing, or backups are on. **It currently fails `mobile` on purpose until you choose a permanent package id.**
5. **Android permissions**: external-storage and overlay permissions blocked in `app.json`; the app uses only private storage.
6. **Fullscreen with subtitles (web)**: own fullscreen button that keeps the subtitle overlay, plus an exit button inside the player (found by a failing test). iPhone Safari falls back to its system player, where subtitles are hidden.
7. **Settings**: removed a "preferred subtitle language" control that did nothing and an outdated note; fixed the player's Back button when the page is opened directly.

Still open after v0.10: real-device and iOS testing, the Android app never run, Android dependencies still `*` (run `npx expo install --fix`, commit the lockfile), real TMDB/Supabase/DeepL calls, the three video URLs not played, per-user limits, takedown of already-downloaded copies, and TMDB commercial licensing.

---
## v0.11 (fixing the "still open" list)
| Item | Result |
|---|---|
| Android package id | Replaced the placeholder with `app.cinemora.mobile` (proposal; availability on Google Play not checked). Release check passes. |
| Per-user limits | **Done.** Per-user rate limit (keyed by the verified JWT user, across IPs) and a persistent daily translation character quota per user and overall. Unit tested (guard, quota logic); SQL and the functions themselves were not run. |
| Downloaded copies can't be taken down | **Done.** Remote takedown feed that can only restrict; web and Android apply it (cached for offline), Android deletes revoked downloads. Unit tested (10 cases) and browser tested (5 scenarios incl. offline persistence, restore, tamper attempt). Android purge/UI not run on a device. |
| Dependencies unpinned | **Not fixable here**: the package registry is unreachable from this sandbox, and I will not guess versions. Added a release gate that blocks `*` ranges and a missing lockfile. You must run `npx expo install --fix` and commit the lockfile. |
| Video URLs not test-played | **Not fixable here**: the video host is unreachable. Added `npm run check:sources` (tested against a local server for good files, error pages, 404s, tiny files, timeouts, missing Range support). You must run it and watch each film. |

Tests after these changes: 36 unit tests and 32 browser tests (desktop and 390 px touch) pass with no runtime errors; all 60 source files parse; strict `tsc` is clean on `shared/` and the function helpers. Not run: Android app, functions, SQL, CSP in a browser, real services.
