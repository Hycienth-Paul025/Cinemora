import {Movie} from './types'
// SAMPLE DATA for interface testing only. verified:false means "not from a metadata provider".
const m=(id:string,title:string,year:number,genres:string[],country:string,language:string,runtime:number,collection:string,synopsis:string,cast:string[]=[]):Movie=>({id,title,year,genres,country,language,runtime,collection,synopsis,cast,verified:false})
export const SAMPLE:Movie[]=[
m('s-bbb','Big Buck Bunny',2008,['Animation','Comedy','Family'],'Netherlands','English',10,'Animation','A giant rabbit takes revenge on three bullying rodents.',[]),
m('s-sintel','Sintel',2010,['Animation','Fantasy','Adventure'],'Netherlands','English',15,'Animation','A young woman searches the world for the dragon she once befriended.',['Halina Reijn']),
m('s-tos','Tears of Steel',2012,['Science fiction','Action'],'Netherlands','English',12,'Science fiction','Fighters in Amsterdam try to save the world from rogue robots.',['Derek de Lint']),
m('s-1','Nosferatu',1922,['Horror','Fantasy'],'Germany','German',94,'Classic','A clerk travels to Transylvania to meet a pale count.',['Max Schreck']),
m('s-2','Living in Bondage',1992,['Drama','Supernatural'],'Nigeria','Igbo',160,'Nollywood','A man’s ambition draws him into a secret cult.',['Kenneth Okonkwo']),
m('s-3','Lagaan',2001,['Drama','Musical','Historical'],'India','Hindi',224,'Bollywood','Villagers stake their tax on a cricket match.',['Aamir Khan']),
m('s-4','Night of the Living Dead',1968,['Horror'],'USA','English',96,'Hollywood','Strangers barricade themselves in a farmhouse.',['Duane Jones']),
m('s-5','Charade',1963,['Romance','Thriller','Mystery'],'USA','English',113,'Classic','A widow in Paris is pursued over her husband’s money.',['Audrey Hepburn','Cary Grant']),
m('s-6','Parasite',2019,['Thriller','Drama'],'South Korea','Korean',132,'International','A poor family schemes its way into a wealthy household.',['Song Kang-ho']),
m('s-7','Spirited Away',2001,['Animation','Fantasy','Family'],'Japan','Japanese',125,'International','A girl must work in a spirit bathhouse to free her parents.',['Rumi Hiiragi']),
m('s-8','Mad Max: Fury Road',2015,['Action','Adventure'],'Australia','English',120,'Hollywood','A drifter helps a fugitive crew cross a wasteland.',['Tom Hardy'])]
