import type {Cue,SubtitleTrack} from './types'
import type {KV} from './metadata'
// Subtitle translation to English through YOUR server-side proxy (supabase/functions/translate). No provider secret is ever in the app.
export type TranslateErrorCode='not_configured'|'unsupported_language'|'rate_limited'|'quota'|'network'|'provider_error'|'cancelled'|'bad_response'
export class TranslationError extends Error{code:TranslateErrorCode;constructor(code:TranslateErrorCode,message:string){super(message);this.code=code}}
const FRIENDLY:Record<TranslateErrorCode,string>={not_configured:'Translation isn’t set up on the server.',unsupported_language:'The translation service doesn’t support this language.',rate_limited:'The translation service is busy. Try again in a minute.',quota:'The translation quota has been used up.',network:'Couldn’t reach the translation service. Check your connection.',provider_error:'The translation service had a problem.',cancelled:'Translation was cancelled.',bad_response:'The translation service returned an unexpected result.'}
export const friendlyError=(e?:unknown)=>e instanceof TranslationError?(e.message&&e.code!=='provider_error'?e.message:FRIENDLY[e.code]):e?FRIENDLY.provider_error:''
export interface TranslationClient{configured:boolean;languages(signal?:AbortSignal):Promise<string[]>;translate(texts:string[],source:string|undefined,signal?:AbortSignal):Promise<string[]>}
export function createTranslationClient(cfg:{baseUrl?:string;anonKey?:string}):TranslationClient{
 const BASE=cfg.baseUrl?.replace(/\/$/,'');let lc:{at:number;v:string[]}|undefined
 async function call(init:{method:string;body?:string},query:string,signal?:AbortSignal):Promise<any>{ // eslint-disable-line @typescript-eslint/no-explicit-any
  if(!BASE)throw new TranslationError('not_configured',FRIENDLY.not_configured)
  let res:Response
  try{res=await fetch(BASE+query,{...init,signal,headers:{'Content-Type':'application/json',...(cfg.anonKey?{apikey:cfg.anonKey,Authorization:`Bearer ${cfg.anonKey}`}:{})}})}
  catch{throw signal?.aborted?new TranslationError('cancelled',FRIENDLY.cancelled):new TranslationError('network',FRIENDLY.network)}
  let body:any=null;try{body=await res.json()}catch{/* not JSON */} // eslint-disable-line @typescript-eslint/no-explicit-any
  if(!res.ok)throw new TranslationError((body?.error?.code as TranslateErrorCode)||(res.status===429?'rate_limited':'provider_error'),body?.error?.message||`Translation service error (${res.status}).`)
  return body}
 return{configured:Boolean(BASE),
  async languages(signal){if(lc&&Date.now()-lc.at<3600e3)return lc.v
   const b=await call({method:'GET'},'?action=languages',signal);if(!Array.isArray(b?.sources))throw new TranslationError('bad_response',FRIENDLY.bad_response)
   lc={at:Date.now(),v:b.sources.map((x:unknown)=>String(x).toLowerCase())};return lc.v},
  async translate(texts,source,signal){const b=await call({method:'POST',body:JSON.stringify({texts,source,target:'en'})},'',signal)
   if(!Array.isArray(b?.translations)||b.translations.length!==texts.length||b.translations.some((t:unknown)=>typeof t!=='string'))throw new TranslationError('bad_response',FRIENDLY.bad_response)
   return b.translations as string[]}}}
/** Text sent to the provider: markup removed, line breaks joined into one line. */
export const plainText=(s:string)=>s.replace(/\{\\[^}]*\}/g,'').replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&').replace(/\s*\n\s*/g,' ').trim()
const hash=(s:string)=>{let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return(h>>>0).toString(36)}
export interface TranslateResult{cues:Cue[];translated:number;failed:number;error?:TranslationError}
export interface TranslateOptions{source?:string;signal?:AbortSignal;onProgress?:(done:number,total:number)=>void;storage?:KV;maxItems?:number;maxChars?:number;retries?:number;sleep?:(ms:number)=>Promise<void>}
const FATAL:TranslateErrorCode[]=['unsupported_language','quota','not_configured']
/**
 * Translates cue TEXT only. start/end/id are never modified, so timing and order are preserved exactly.
 * Failed batches keep their original text (reported in `failed`). Throws only if nothing at all could be translated, or on cancel.
 */
export async function translateCues(cues:Cue[],client:TranslationClient,o:TranslateOptions={}):Promise<TranslateResult>{
 const plain=cues.map(c=>plainText(c.text)),out=cues.map(c=>({...c})),maxItems=o.maxItems??40,maxChars=o.maxChars??4500,retries=o.retries??2,sleep=o.sleep??(ms=>new Promise<void>(r=>setTimeout(r,ms)))
 const todo=plain.map((p,i)=>i).filter(i=>plain[i].length>0&&plain[i].length<=1000),skippedLong=plain.filter(p=>p.length>1000).length
 const key='cm.sub.tr.'+hash((o.source||'auto')+'|'+plain.join('\u0001'))
 if(o.storage){try{const raw=await o.storage.get(key);if(raw){const t=JSON.parse(raw) as string[];if(Array.isArray(t)&&t.length===cues.length){t.forEach((x,i)=>{if(typeof x==='string'&&x)out[i].text=x});return{cues:out,translated:todo.length,failed:0}}}}catch{/* cache miss */}}
 const batches:number[][]=[];let cur:number[]=[],chars=0
 for(const i of todo){if(cur.length&&(cur.length>=maxItems||chars+plain[i].length>maxChars)){batches.push(cur);cur=[];chars=0}cur.push(i);chars+=plain[i].length}
 if(cur.length)batches.push(cur)
 let done=0,failed=skippedLong,last:TranslationError|undefined,stopped=false
 for(let b=0;b<batches.length;b++){const batch=batches[b]
  if(o.signal?.aborted)throw new TranslationError('cancelled',FRIENDLY.cancelled)
  let res:string[]|undefined
  for(let a=0;a<=retries;a++){try{const r=await client.translate(batch.map(i=>plain[i]),o.source,o.signal)
    if(!Array.isArray(r)||r.length!==batch.length)throw new TranslationError('bad_response',FRIENDLY.bad_response);res=r;break}
   catch(e){const te=e instanceof TranslationError?e:new TranslationError('provider_error',FRIENDLY.provider_error);if(te.code==='cancelled')throw te;last=te;if(FATAL.includes(te.code))break;if(a<retries)await sleep(500*2**a)}}
  if(res){batch.forEach((i,k)=>{if(res![k])out[i].text=res![k]});done+=batch.length}
  else{failed+=batch.length;if(last&&FATAL.includes(last.code)){for(const rest of batches.slice(b+1))failed+=rest.length;stopped=true}}
  o.onProgress?.(done+failed-skippedLong,todo.length);if(stopped)break}
 if(todo.length>0&&done===0)throw last||new TranslationError('provider_error',FRIENDLY.provider_error)
 if(failed===0&&o.storage){try{await o.storage.set(key,JSON.stringify(out.map(c=>c.text)))}catch{/* cache is optional */}}
 return{cues:out,translated:done,failed,error:failed?last||new TranslationError('provider_error','Some lines could not be translated.'):undefined}}
export const translatedTrack=(src:SubtitleTrack,r:TranslateResult):SubtitleTrack=>({id:`${src.id}-en`,label:`${src.label} → English (machine-translated${r.failed?`; ${r.failed} line${r.failed===1?'':'s'} left in the original`:''})`,lang:'en',origin:'translated',format:src.format,cues:r.cues,machine:true,from:src.id,untranslated:r.failed||undefined})
