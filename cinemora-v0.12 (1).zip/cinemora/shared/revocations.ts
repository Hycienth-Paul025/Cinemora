import type {Source} from './types'
import type {KV} from './metadata'
// Remote takedown feed. The app downloads a small JSON file you host and applies it ON TOP of the built-in source records.
// The feed can only RESTRICT access (withdraw, expire, un-verify, switch off streaming/download). It can never grant anything,
// so a tampered or mistaken feed cannot make an unverified title playable. The last good feed is cached so a takedown keeps
// working offline. Feed format: {"version":1,"updated":"2026-10-20","sources":{"src-sintel":{"withdrawn":true}}}
export interface SourceOverride{withdrawn?:true;expiresAt?:string;verified?:false;streaming?:false;download?:false}
export type Overrides=Record<string,SourceOverride>
const KEY='cm.srcstatus'
export function sanitizeFeed(raw:unknown):Overrides|null{
 if(!raw||typeof raw!=='object')return null;const src=(raw as {sources?:unknown}).sources
 if(!src||typeof src!=='object'||Array.isArray(src))return null
 const out:Overrides={}
 for(const[id,v]of Object.entries(src as Record<string,unknown>)){if(!v||typeof v!=='object')continue;const o=v as Record<string,unknown>,r:SourceOverride={}
  if(o.withdrawn===true)r.withdrawn=true;if(typeof o.expiresAt==='string'&&!Number.isNaN(Date.parse(o.expiresAt)))r.expiresAt=o.expiresAt
  if(o.verified===false)r.verified=false;if(o.streaming===false)r.streaming=false;if(o.download===false)r.download=false
  if(Object.keys(r).length)out[id]=r}
 return out}
export function applyOverride(s:Source,o?:SourceOverride):Source{if(!o)return s
 return{...s,...(o.withdrawn?{withdrawn:true}:{}),...(o.expiresAt&&(!s.expiresAt||Date.parse(o.expiresAt)<Date.parse(s.expiresAt))?{expiresAt:o.expiresAt}:{}),
  ...(o.verified===false?{verified:false}:{}),...(o.streaming===false?{streaming:false}:{}),...(o.download===false?{download:false}:{})}}
/** Last good feed from storage (instant). `exists` is false on the very first run. */
export async function readCachedOverrides(kv:KV):Promise<{overrides:Overrides;exists:boolean}>{
 try{const raw=await kv.get(KEY);if(!raw)return{overrides:{},exists:false};const o=sanitizeFeed(JSON.parse(raw));return o?{overrides:o,exists:true}:{overrides:{},exists:false}}catch{return{overrides:{},exists:false}}}
/** Fetch the feed. On success it REPLACES the cache (so un-withdrawing works); on any failure the cache stays and `fresh` is false. */
export async function fetchOverrides(url:string|undefined,kv:KV,f:typeof fetch=fetch,timeoutMs=8000):Promise<{overrides:Overrides;fresh:boolean}>{
 const cached=async()=>({overrides:(await readCachedOverrides(kv)).overrides,fresh:false})
 if(!url)return cached()
 const c=new AbortController(),t=setTimeout(()=>c.abort(),timeoutMs)
 try{const r=await f(url,{cache:'no-store',signal:c.signal});if(!r.ok)return cached();const o=sanitizeFeed(await r.json());if(!o)return cached()
  try{await kv.set(KEY,JSON.stringify({sources:o}))}catch{/* cache is best effort */}
  return{overrides:o,fresh:true}}
 catch{return cached()}finally{clearTimeout(t)}}
