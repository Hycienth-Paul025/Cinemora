export type LicenseStatus="public-domain"|"cc-by"|"licensed-free"
export interface Source{id:string;movieId:string;provider:{name:string;url:string};mediaUrl:string;mediaType:"mp4"|"webm"|"ogv"|"hls"
 license:{name:string;url:string;status:LicenseStatus};evidence:string[];streaming:boolean;download:boolean;territories:"worldwide"|string[]
 expiresAt?:string;withdrawn?:boolean;verified:boolean;verifiedAt?:string;attribution:string;restrictions?:string;note?:string;drm?:boolean}
export interface Availability{ok:boolean;state:"available"|"under-review"|"region"|"expired"|"withdrawn"|"no-streaming";badge:string;message:string}
export interface Movie{id:string;title:string;year:number;genres:string[];country:string;language:string;runtime:number;synopsis:string;cast:string[];collection:string;collections?:string[];poster?:string;backdrop?:string;tagline?:string;tmdbId?:number;verified:boolean}
export interface Progress{t:number;d:number;at:number}
export interface Settings{subLang:string;subSize:number;audioLang:string;region?:string}

export interface Cue{start:number;end:number;text:string;id?:string}
export interface SubtitleTrack{id:string;label:string;lang:string;origin:'catalog'|'imported'|'translated';format:'srt'|'vtt';cues:Cue[];machine?:boolean;from?:string;untranslated?:number}
