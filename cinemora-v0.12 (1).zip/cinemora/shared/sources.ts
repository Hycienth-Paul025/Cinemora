import {Availability,Source} from './types'
import {Overrides,applyOverride} from './revocations'
// SOURCE MANAGEMENT. Playback sources are tracked here, separate from metadata, keyed by Movie.id.
// A title can play only if its record is verified, streaming-permitted, not withdrawn/expired, and allowed in the viewer's country.
// Never add a record without checking the license yourself and listing the pages you checked in `evidence`.
const IA='https://archive.org/download/Sintel_201709/'
const IA_PAGE={name:'Internet Archive',url:'https://archive.org/details/Sintel_201709'}
export const SOURCES:Source[]=[
 {id:'src-sintel',movieId:'s-sintel',provider:IA_PAGE,mediaUrl:IA+'Sintel.mp4',mediaType:'mp4',
  license:{name:'Creative Commons Attribution 3.0',url:'https://creativecommons.org/licenses/by/3.0/',status:'cc-by'},
  evidence:['https://durian.blender.org/about/','https://archive.org/details/Sintel'],streaming:true,download:true,territories:'worldwide',
  verified:true,verifiedAt:'2026-10-18',attribution:'“Sintel” © Blender Foundation | durian.blender.org (CC BY 3.0)',
  restrictions:'Share freely if the film’s own credit scroll is kept. Logos in the film are excluded from the license.',
  note:'License confirmed on the official Durian site and the Internet Archive item. The file URL is built from the Internet Archive item listing and was not test-played in this build.'},
 {id:'src-bbb',movieId:'s-bbb',provider:IA_PAGE,mediaUrl:IA+'Big%20Buck%20Bunny.mp4',mediaType:'mp4',
  license:{name:'Creative Commons Attribution 3.0',url:'https://creativecommons.org/licenses/by/3.0/',status:'cc-by'},
  evidence:['https://peach.blender.org/about','https://archive.org/details/Sintel_201709'],streaming:true,download:true,territories:'worldwide',
  verified:true,verifiedAt:'2026-10-18',attribution:'© copyright Blender Foundation | www.bigbuckbunny.org (CC BY 3.0)',
  restrictions:'Attribution required. Logos on the project site (Blender, Peach, Creative Commons) are excluded. The isolated music score has a different license (non-commercial, no derivatives); only the film is listed here.',
  note:'License confirmed on the official Peach "About" page. The file is `Big Buck Bunny.mp4` in a third-party Internet Archive upload; the URL follows IA’s download pattern and was not test-played in this build.'},
 {id:'src-tos',movieId:'s-tos',provider:IA_PAGE,mediaUrl:IA+'Tears%20of%20Steel.mp4',mediaType:'mp4',
  license:{name:'Creative Commons Attribution 3.0',url:'https://creativecommons.org/licenses/by/3.0/',status:'cc-by'},
  evidence:['https://anna.lysator.liu.se/pub/xiph/media/tearsofsteel/README.txt','https://davidrevoy.com/article136/movie-concept-art-tears-of-steel-blender-foundation','https://archive.org/details/Sintel_201709'],streaming:true,download:true,territories:'worldwide',
  verified:true,verifiedAt:'2026-10-18',attribution:'(CC) Blender Foundation | mango.blender.org (CC BY 3.0)',
  restrictions:'Attribution required. Logos (Blender, Mango, Creative Commons, sponsors) are excluded. Actors keep their personal image and privacy rights.',
  note:'License confirmed from a Xiph mirror README and a production artist’s page, not from the official mango.blender.org site (not reached). Re-check there when possible. File URL not test-played.'}]
export const REGIONS:[string,string][]=[['NG','Nigeria'],['GH','Ghana'],['ZA','South Africa'],['EG','Egypt'],['KE','Kenya'],['US','United States'],['GB','United Kingdom'],['CA','Canada'],['IN','India'],['DE','Germany'],['FR','France'],['BR','Brazil'],['KR','South Korea'],['JP','Japan'],['AU','Australia']]
let overrides:Overrides={}
/** Apply the remote takedown feed (see revocations.ts). Called by the app stores; replaces any previous feed. */
export const setSourceOverrides=(o:Overrides)=>{overrides=o}
/** Built-in records with the remote takedown feed applied. Always use this (not SOURCES) to decide what may play or download. */
export const listSources=():Source[]=>SOURCES.map(s=>applyOverride(s,overrides[s.id]))
export const getSource=(movieId:string)=>listSources().find(s=>s.movieId===movieId)
/** True when a downloaded copy of this source is no longer authorized and should be deleted from the device (region differences do not count). */
export function needsPurge(sourceId:string):boolean{const s=listSources().find(x=>x.id===sourceId);if(!s)return true
 return['withdrawn','expired','under-review','no-streaming'].includes(evaluateSource(s).state)||!s.download||Boolean(s.drm)||s.mediaType==='hls'}
export function evaluateSource(s:Source,region?:string,now=new Date()):Availability{
 if(s.withdrawn)return{ok:false,state:'withdrawn',badge:'Withdrawn',message:'This source was withdrawn, for example after a takedown or a license change.'}
 if(s.expiresAt&&new Date(s.expiresAt)<=now)return{ok:false,state:'expired',badge:'License expired',message:'The permission to stream this title has expired.'}
 if(!s.verified)return{ok:false,state:'under-review',badge:'Source under review',message:'A reviewer has not confirmed this title’s license yet, so playback is switched off.'}
 if(!s.streaming)return{ok:false,state:'no-streaming',badge:'No streaming rights',message:'The license does not allow streaming this title.'}
 if(s.territories!=='worldwide'){
  if(!region)return{ok:false,state:'region',badge:'Set your country',message:`This title is licensed only for ${s.territories.join(', ')}. Choose your country in Settings.`}
  if(!s.territories.includes(region))return{ok:false,state:'region',badge:'Not in your region',message:`This title isn’t licensed for your country (${region}). It is available in ${s.territories.join(', ')}.`}}
 return{ok:true,state:'available',badge:'Free to watch',message:'Available to stream.'}}
export const availabilityFor=(movieId:string,region?:string)=>{const s=getSource(movieId);return s?evaluateSource(s,region):undefined}
export const isPlayable=(movieId:string,region?:string)=>Boolean(availabilityFor(movieId,region)?.ok)
/** Downloads are allowed only when streaming is authorized AND the license permits copies AND the file is DRM-free plain media. */
export function canDownload(s:Source,region?:string):{ok:boolean;reason:string}{
 const a=evaluateSource(s,region);if(!a.ok)return{ok:false,reason:a.message}
 if(!s.download)return{ok:false,reason:'The license does not permit downloading this title.'}
 if(s.drm)return{ok:false,reason:'This source uses DRM. Protected content needs the distributor’s own offline-license flow, which this app does not implement.'}
 if(s.mediaType==='hls')return{ok:false,reason:'This source is stream-only (HLS); plain-file download is not supported.'}
 return{ok:true,reason:''}}
