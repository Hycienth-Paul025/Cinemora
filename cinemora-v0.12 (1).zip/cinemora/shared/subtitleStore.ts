import type {KV} from './metadata'
import type {SubtitleTrack} from './types'
// Per-movie subtitle tracks (imported and translated) persisted as JSON. Use the platform's KV adapter.
const key=(movieId:string)=>`cm.subs.${movieId}`
export async function loadTracks(kv:KV,movieId:string):Promise<SubtitleTrack[]>{try{const v=JSON.parse(await kv.get(key(movieId))||'[]');return Array.isArray(v)?v as SubtitleTrack[]:[]}catch{return[]}}
export async function saveTracks(kv:KV,movieId:string,tracks:SubtitleTrack[]):Promise<void>{await kv.set(key(movieId),JSON.stringify(tracks))}   // throws if storage is full
