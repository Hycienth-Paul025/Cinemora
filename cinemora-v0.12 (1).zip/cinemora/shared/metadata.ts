import {Movie} from './types'
import {SAMPLE} from './sample'
// Platform-neutral metadata client (TMDB via YOUR proxy). Storage is injected: AsyncStorage on mobile, localStorage on web.
export interface KV{get(k:string):Promise<string|null>;set(k:string,v:string):Promise<void>;remove(k:string):Promise<void>;keys():Promise<string[]>}
export interface Page{items:Movie[];page:number;totalPages:number;totalResults:number}
export class MetadataError extends Error{status:number;constructor(m:string,status=0){super(m);this.status=status}}
export interface MetaConfig{baseUrl?:string;anonKey?:string;storage:KV}
const TTL={list:6*3600e3,detail:24*3600e3,genres:7*864e5},PFX='cm.tm.',SEEN='cm.seen',SEEN_TTL=30*864e5,IMG='https://image.tmdb.org/t/p/'
interface RawList{id:number;title:string;release_date?:string;genre_ids?:number[];original_language?:string;overview?:string;poster_path?:string|null;backdrop_path?:string|null}
interface RawPage{results:RawList[];page:number;total_pages:number;total_results:number}
interface RawDetail extends Omit<RawList,'genre_ids'>{genres:{id:number;name:string}[];runtime?:number|null;tagline?:string;production_countries?:{name:string}[];spoken_languages?:{english_name:string}[];credits?:{cast:{name:string}[]}}
type Params=Record<string,string|number|undefined>
const qs=(p:Params)=>Object.keys(p).sort().filter(k=>p[k]!==undefined&&p[k]!=='').map(k=>`${encodeURIComponent(k)}=${encodeURIComponent(String(p[k]))}`).join('&')
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms))
const langName=(c?:string)=>{if(!c)return'Unknown';try{return new Intl.DisplayNames(['en'],{type:'language'}).of(c)||c}catch{return c}}
const base=(r:RawList,collection:string):Movie=>({id:'tmdb-'+r.id,tmdbId:r.id,title:r.title,year:Number((r.release_date||'').slice(0,4))||0,genres:[],country:'Unknown',language:langName(r.original_language),runtime:0,synopsis:r.overview||'',cast:[],collection,poster:r.poster_path?IMG+'w342'+r.poster_path:undefined,backdrop:r.backdrop_path?IMG+'w780'+r.backdrop_path:undefined,verified:true})
export function createMetadata(cfg:MetaConfig){
 const BASE=cfg.baseUrl?.replace(/\/$/,''),st=cfg.storage,mem=new Map<string,{at:number;v:unknown}>()
 async function read<T>(k:string,ttl:number):Promise<T|undefined>{const m=mem.get(k);if(m&&Date.now()-m.at<ttl)return m.v as T
  try{const raw=await st.get(PFX+k);if(raw){const r=JSON.parse(raw) as {at:number;v:T};if(Date.now()-r.at<ttl){mem.set(k,r);return r.v}}}catch{/* ignore */}}
 async function write(k:string,v:unknown){const e={at:Date.now(),v};mem.set(k,e);try{await st.set(PFX+k,JSON.stringify(e))}catch{/* quota */}}
 async function clearCache(){mem.clear();try{for(const k of await st.keys())if(k.startsWith(PFX))await st.remove(k)}catch{/* ignore */}}
 async function request<T>(path:string,params:Params,ttl:number,signal?:AbortSignal):Promise<T>{
  if(!BASE)throw new MetadataError('Metadata service is not configured')
  const q=qs(params),key=`${path}?${q}`,hit=await read<T>(key,ttl);if(hit)return hit
  for(let i=0;;i++){let res:Response
   try{res=await fetch(`${BASE}${path}?${q}`,{signal,headers:cfg.anonKey?{apikey:cfg.anonKey,Authorization:`Bearer ${cfg.anonKey}`}:undefined})}
   catch(e){if(signal?.aborted)throw e;if(i<2){await sleep(500*2**i);continue}throw new MetadataError('Network error. Check your connection and try again.')}
   if(res.ok){const j=await res.json() as T;await write(key,j);return j}
   if((res.status===429||res.status>=500)&&i<2){await sleep(Number(res.headers.get('retry-after'))*1000||500*2**i);continue}
   throw new MetadataError(res.status===404?'Not found':res.status===429?'Too many requests. Wait a moment.':`Metadata service error (${res.status})`,res.status)}}
 type SeenMap=Record<string,{at:number;m:Movie}>
 const seen=async():Promise<SeenMap>=>{try{return JSON.parse(await st.get(SEEN)||'{}') as SeenMap}catch{return{}}}
 async function remember(ms:Movie[]){const s=await seen(),now=Date.now();for(const m of ms)if(m.verified)s[m.id]={at:now,m}
  const o:SeenMap={};Object.keys(s).filter(k=>now-s[k].at<SEEN_TTL).sort((a,b)=>s[b].at-s[a].at).slice(0,300).forEach(k=>{o[k]=s[k]});try{await st.set(SEEN,JSON.stringify(o))}catch{/* ignore */}}
 async function recall(id:string):Promise<Movie|undefined>{const e=(await seen())[id];return e&&Date.now()-e.at<SEEN_TTL?e.m:undefined}
 const getGenres=()=>request<{genres:{id:number;name:string}[]}>('/genre/movie/list',{language:'en-US'},TTL.genres).then(r=>r.genres)
 let gm:Promise<Map<number,string>>|undefined
 const genreMap=()=>gm??=getGenres().then(g=>new Map(g.map(x=>[x.id,x.name] as [number,string]))).catch(e=>{gm=undefined;throw e})
 async function toPage(r:RawPage,collection:string):Promise<Page>{const g=await genreMap()
  const items=r.results.map(x=>({...base(x,collection),genres:(x.genre_ids||[]).map(i=>g.get(i)).filter((n):n is string=>Boolean(n))}))
  await remember(items);return{items,page:r.page,totalPages:Math.min(r.total_pages,500),totalResults:r.total_results}}
 return{configured:Boolean(BASE),getGenres,recall,clearCache,
  async listMovies(kind:'popular'|'top_rated'|'now_playing',page=1,collection='Trending',signal?:AbortSignal){return toPage(await request<RawPage>(`/movie/${kind}`,{page,language:'en-US'},TTL.list,signal),collection)},
  async discover(o:{page:number;genre?:string;language?:string;country?:string;year?:string},signal?:AbortSignal){return toPage(await request<RawPage>('/discover/movie',{page:o.page,with_genres:o.genre,with_original_language:o.language,with_origin_country:o.country,primary_release_year:o.year,sort_by:'popularity.desc',language:'en-US'},TTL.list,signal),'Explore')},
  async searchMovies(query:string,page=1,signal?:AbortSignal):Promise<Page>{const q=query.trim().slice(0,100);if(!q)return{items:[],page:1,totalPages:1,totalResults:0}
   return toPage(await request<RawPage>('/search/movie',{query:q,page,language:'en-US'},TTL.list,signal),'Search')},
  async getMovieDetails(tmdbId:number,signal?:AbortSignal):Promise<Movie>{const r=await request<RawDetail>(`/movie/${tmdbId}`,{language:'en-US'},TTL.detail,signal)
   const m:Movie={...base(r,'Details'),genres:r.genres.map(g=>g.name),runtime:r.runtime||0,country:r.production_countries?.[0]?.name||'Unknown',language:r.spoken_languages?.[0]?.english_name||langName(r.original_language),cast:(r.credits?.cast||[]).slice(0,8).map(c=>c.name),tagline:r.tagline||undefined}
   await remember([m]);return m}}}
export type MetadataClient=ReturnType<typeof createMetadata>
/** Home catalog: three TMDB lists + sample records. Titles in several lists keep their first collection. */
export async function loadCatalog(meta:MetadataClient,force=false):Promise<{movies:Movie[];live:boolean}>{
 if(!meta.configured)return{movies:SAMPLE,live:false}
 if(force)await meta.clearCache()
 const[a,b,c]=await Promise.all([meta.listMovies('popular',1,'Trending'),meta.listMovies('now_playing',1,'Recently added'),meta.listMovies('top_rated',1,'Top rated')])
 const byId=new Map<string,Movie>();for(const m of [...a.items,...b.items,...c.items]){const e=byId.get(m.id);if(e)e.collections=[...new Set([...(e.collections||[]),m.collection])];else byId.set(m.id,{...m,collections:[m.collection]})}
 const movies=[...byId.values()]
 return{movies:[...movies,...SAMPLE],live:true}}
