import {Movie} from './types'
export const norm=(s:string)=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9 ]/g,' ').trim()
/** Edit distance where swapping two adjacent letters ("sintle" for "sintel") counts as ONE typo. */
function dist(a:string,b:string){const d:number[][]=Array.from({length:a.length+1},(_,i)=>[i]);for(let j=1;j<=b.length;j++)d[0][j]=j
 for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++){d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1))
  if(i>1&&j>1&&a[i-1]===b[j-2]&&a[i-2]===b[j-1])d[i][j]=Math.min(d[i][j],d[i-2][j-2]+1)}
 return d[a.length][b.length]}
const wordScore=(tok:string,wd:string)=>wd===tok?1:wd.startsWith(tok)?.8:tok.length>3&&dist(tok,wd.slice(0,tok.length+1))<=Math.max(1,Math.floor(tok.length/4))?.6:0
function score(m:Movie,q:string){const f:[string,number][]=[[m.title,5],[m.cast.join(' '),3],[m.genres.join(' '),2],[m.language,2],[m.country,2],[String(m.year),2],[m.synopsis,1]]
 const toks=norm(q).split(' ').filter(t=>t.length>=2);if(!toks.length)return 0   // one-letter tokens match nearly everything: ignored
 let tot=0
 for(const tok of toks){let best=0
  for(const[t,w]of f){const n=norm(t);for(const wd of n.split(' '))best=Math.max(best,wordScore(tok,wd)*w)
   if(w>=3&&tok.length>=4&&n.replace(/ /g,'').startsWith(tok))best=Math.max(best,.8*w)}   // "madmax" -> "Mad Max: Fury Road"
  if(!best)return 0;tot+=best}return tot}
export const search=(ms:Movie[],q:string)=>ms.map(m=>[m,score(m,q)] as const).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]).map(x=>x[0])
