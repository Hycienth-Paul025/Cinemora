import {test} from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
import {sanitizeFeed,applyOverride,fetchOverrides,readCachedOverrides} from '../revocations'
import {setSourceOverrides,availabilityFor,isPlayable,needsPurge,listSources,getSource,canDownload,SOURCES} from '../sources'
import {checkSource} from '../sourceCheck'
import {consumeQuota,GLOBAL_ID} from '../../supabase/functions/_shared/quota'
import {makeGuard,userFromAuth} from '../../supabase/functions/_shared/guard'
import type {Source} from '../types'
const mkKV=()=>{const m=new Map<string,string>();return{get:async(k:string)=>m.get(k)??null,set:async(k:string,v:string)=>{m.set(k,v)},remove:async(k:string)=>{m.delete(k)},keys:async()=>[...m.keys()]}}
const feed=(o:unknown,status=200)=>(async()=>new Response(JSON.stringify(o),{status}))as unknown as typeof fetch
test('takedown feed can only restrict, never grant',()=>{
 assert.equal(sanitizeFeed(null),null);assert.equal(sanitizeFeed({sources:[]}),null);assert.equal(sanitizeFeed({}),null)
 const o=sanitizeFeed({sources:{a:{withdrawn:true,verified:true,mediaUrl:'https://evil',license:{name:'x'}},b:{verified:true},c:{expiresAt:'not a date'},d:{expiresAt:'2026-01-01',download:false},e:'junk'}})!
 assert.deepEqual(o,{a:{withdrawn:true},d:{expiresAt:'2026-01-01',download:false}})
 const base:Source={id:'x',movieId:'m',provider:{name:'p',url:'u'},mediaUrl:'https://p/x.mp4',mediaType:'mp4',license:{name:'l',url:'',status:'cc-by'},evidence:['e'],streaming:true,download:true,territories:'worldwide',verified:false,attribution:'a'}
 assert.equal(applyOverride(base,{verified:true as unknown as false}).verified,false,'cannot un-verify→verify');assert.equal(applyOverride(base,{withdrawn:true}).withdrawn,true)
 assert.equal(applyOverride({...base,expiresAt:'2030-01-01'},{expiresAt:'2040-01-01'}).expiresAt,'2030-01-01','cannot extend an expiry');assert.equal(applyOverride({...base,expiresAt:'2030-01-01'},{expiresAt:'2027-01-01'}).expiresAt,'2027-01-01')})
test('feed loading: fresh replaces cache, failures fall back to cache, un-withdrawing works',async()=>{const kv=mkKV()
 assert.deepEqual(await readCachedOverrides(kv),{overrides:{},exists:false})
 let r=await fetchOverrides('https://x/s.json',kv,feed({sources:{s1:{withdrawn:true}}}));assert.equal(r.fresh,true);assert.deepEqual(r.overrides,{s1:{withdrawn:true}});assert.equal((await readCachedOverrides(kv)).exists,true)
 for(const f of [feed({},500),feed('nonsense'),(async()=>{throw new TypeError('offline')})as unknown as typeof fetch]){r=await fetchOverrides('https://x/s.json',kv,f);assert.equal(r.fresh,false);assert.deepEqual(r.overrides,{s1:{withdrawn:true}},'takedown survives being offline')}
 assert.deepEqual((await fetchOverrides(undefined,kv)).overrides,{s1:{withdrawn:true}})
 r=await fetchOverrides('https://x/s.json',kv,feed({sources:{}}));assert.deepEqual(r.overrides,{},'dropping an entry restores the source')})
test('takedown feed changes playback, download and purge decisions',()=>{try{
 assert.equal(isPlayable('s-sintel'),true);assert.equal(needsPurge('src-sintel'),false);assert.equal(needsPurge('no-such-source'),true,'a source the app no longer lists must not stay on devices')
 setSourceOverrides({'src-sintel':{withdrawn:true}});assert.equal(availabilityFor('s-sintel')?.state,'withdrawn');assert.equal(isPlayable('s-sintel'),false);assert.equal(canDownload(getSource('s-sintel')!).ok,false);assert.equal(needsPurge('src-sintel'),true);assert.equal(isPlayable('s-bbb'),true,'other titles unaffected')
 setSourceOverrides({'src-bbb':{download:false}});assert.equal(isPlayable('s-bbb'),true,'streaming still allowed');assert.equal(needsPurge('src-bbb'),true,'but copies must go');assert.equal(canDownload(getSource('s-bbb')!).ok,false)
 setSourceOverrides({'src-tos':{expiresAt:'2000-01-01'}});assert.equal(availabilityFor('s-tos')?.state,'expired');assert.equal(needsPurge('src-tos'),true)
 setSourceOverrides({'src-sintel':{verified:false}});assert.equal(availabilityFor('s-sintel')?.state,'under-review')
 assert.equal(listSources().length,SOURCES.length)}finally{setSourceOverrides({})}assert.equal(isPlayable('s-sintel'),true)})
test('quota: per-user then global, fails closed, anonymous uses global only',async()=>{const calls:string[]=[];const mk=(res:Record<string,boolean|'err'>)=>(async(_f:string,a:Record<string,unknown>)=>{calls.push(String(a.p_user));const v=res[String(a.p_user)];return v==='err'?{data:null,error:{message:'db'}}:{data:v===true,error:null}})
 const L={perUserDaily:100,globalDaily:1000}
 assert.deepEqual(await consumeQuota(mk({u1:true,[GLOBAL_ID]:true}),'u1',50,L),{ok:true});assert.deepEqual(calls,['u1',GLOBAL_ID]);calls.length=0
 let r=await consumeQuota(mk({u1:false,[GLOBAL_ID]:true}),'u1',50,L);assert.ok(!r.ok&&r.code==='quota'&&/today/.test(r.message));assert.deepEqual(calls,['u1'],'global budget not spent when the user is over their limit');calls.length=0
 r=await consumeQuota(mk({[GLOBAL_ID]:false}),null,50,L);assert.ok(!r.ok&&r.code==='quota'&&/capacity/.test(r.message));assert.deepEqual(calls,[GLOBAL_ID])
 r=await consumeQuota(mk({[GLOBAL_ID]:'err'}),null,5,L);assert.ok(!r.ok&&r.code==='provider_error','database trouble must block spending, not allow it')})
const b64=(o:object)=>Buffer.from(JSON.stringify(o)).toString('base64url'),jwt=(p:object)=>`h.${b64(p)}.s`
test('guard: per-user limit across many IPs; anon and malformed tokens are not users',()=>{const g=makeGuard({limit:100,userLimit:3,windowMs:60000,now:()=>1000})
 const r=(ip:string,auth?:string)=>({method:'POST',headers:{get:(k:string)=>k==='x-forwarded-for'?ip:k==='authorization'?(auth??null):null}})
 const u1=`Bearer ${jwt({role:'authenticated',sub:'user-1'})}`,u2=`Bearer ${jwt({role:'authenticated',sub:'user-2'})}`
 for(let i=0;i<3;i++)assert.ok(g.check(r('10.0.0.'+i,u1)).ok);const blocked=g.check(r('10.0.0.99',u1));assert.ok(!blocked.ok&&blocked.status===429,'same user from a new IP is still limited')
 assert.ok(g.check(r('10.0.0.1',u2)).ok,'other users unaffected')
 for(let i=0;i<10;i++)assert.ok(g.check(r('20.0.0.'+i,`Bearer ${jwt({role:'anon'})}`)).ok,'anon key is not a user');assert.equal(userFromAuth('Bearer not.a.jwt'),null);assert.equal(userFromAuth(null),null);assert.equal(userFromAuth(`Bearer ${jwt({role:'authenticated'})}`),null,'needs a sub')})
const dep=(pkg:object,lock:boolean,warn=false)=>{const d=fs.mkdtempSync(path.join(os.tmpdir(),'cd-'));fs.writeFileSync(path.join(d,'package.json'),JSON.stringify(pkg));if(lock)fs.writeFileSync(path.join(d,'package-lock.json'),'{}');const x=spawnSync(process.execPath,[path.resolve('scripts/check-deps.cjs'),d,...(warn?['--warn']:[])],{encoding:'utf8'});return{code:x.status,out:x.stdout+x.stderr}}
test('dependency gate: unpinned ranges and missing lockfile block a release',()=>{assert.equal(dep({dependencies:{a:'1.2.3'},devDependencies:{b:'^2.0.0'}},true).code,0);assert.equal(dep({dependencies:{a:'*'}},true).code,1);assert.equal(dep({dependencies:{a:'latest'}},true).code,1);assert.equal(dep({dependencies:{a:'1.0.0'}},false).code,1);assert.equal(dep({dependencies:{a:'*'}},false,true).code,0,'--warn never blocks')
 const real=spawnSync(process.execPath,[path.resolve('scripts/check-deps.cjs'),'mobile'],{encoding:'utf8'});assert.equal(real.status,1,'the shipped mobile package.json must still be blocked until you pin it');assert.match(real.stderr,/expo install --fix/)})
test('source checker: accepts real media, rejects error pages, 404s, tiny files, timeouts; warns without Range support',async()=>{
 const big=Buffer.alloc(2_000_000,1),srv=http.createServer((q,s)=>{const rg=q.headers.range
  if(q.url==='/ok.mp4'){if(rg){s.writeHead(206,{'content-type':'video/mp4','content-range':`bytes 0-1023/${big.length}`,'content-length':'1024'});return s.end(big.subarray(0,1024))}s.writeHead(200,{'content-type':'video/mp4','content-length':String(big.length)});return s.end(big)}
  if(q.url==='/norange.mp4'){s.writeHead(200,{'content-type':'video/mp4','content-length':String(big.length)});return s.end(big.subarray(0,1024))}
  if(q.url==='/page.mp4'){s.writeHead(200,{'content-type':'text/html'});return s.end('<html>blocked</html>')}
  if(q.url==='/tiny.mp4'){s.writeHead(200,{'content-type':'video/mp4','content-length':'5000'});return s.end(Buffer.alloc(5000))}
  if(q.url==='/slow.mp4')return;s.writeHead(404);s.end()})
 await new Promise<void>(r=>srv.listen(0,r));const base=`http://127.0.0.1:${(srv.address() as {port:number}).port}`
 try{const ok=await checkSource(base+'/ok.mp4');assert.ok(ok.ok);assert.equal(ok.bytes,2_000_000);assert.equal(ok.warning,undefined)
  const nr=await checkSource(base+'/norange.mp4');assert.ok(nr.ok&&/Range/.test(nr.warning||''))
  assert.match((await checkSource(base+'/page.mp4')).problem||'',/content type/);assert.match((await checkSource(base+'/tiny.mp4')).problem||'',/small/);assert.match((await checkSource(base+'/nope')).problem||'',/404/)
  assert.match((await checkSource(base+'/slow.mp4',fetch,300)).problem||'',/timed out/);assert.match((await checkSource('http://127.0.0.1:1/x.mp4')).problem||'',/network error/)}finally{srv.closeAllConnections();srv.close()}})
