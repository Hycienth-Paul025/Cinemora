import {test} from 'node:test'
import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {makeGuard} from '../../supabase/functions/_shared/guard'
const req=(o:{method?:string;origin?:string;ip?:string;cf?:string})=>({method:o.method??'GET',headers:{get:(k:string)=>(({origin:o.origin,'x-forwarded-for':o.ip,'cf-connecting-ip':o.cf}) as Record<string,string|undefined>)[k.toLowerCase()]??null}})
test('guard: origin rules',()=>{const g=makeGuard({allowedOrigin:'https://cinemora.example',limit:100,windowMs:60000})
 const ok=g.check(req({origin:'https://cinemora.example'}));assert.ok(ok.ok);assert.equal(ok.headers['Access-Control-Allow-Origin'],'https://cinemora.example')
 const bad=g.check(req({origin:'https://evil.example'}));assert.ok(!bad.ok);assert.equal(!bad.ok&&bad.status,403);assert.equal(bad.headers['Access-Control-Allow-Origin'],undefined)
 assert.ok(g.check(req({})).ok,'native apps send no Origin');assert.ok(!g.check(req({origin:'http://localhost:5173'})).ok,'localhost refused when a production origin is set')
 const dev=makeGuard({limit:100,windowMs:60000});assert.ok(dev.check(req({origin:'http://localhost:5173'})).ok);assert.ok(dev.check(req({origin:'http://127.0.0.1:3000'})).ok);assert.ok(!dev.check(req({origin:'https://evil.example'})).ok,'fails closed when ALLOWED_ORIGIN is unset')})
test('guard: per-IP rate limit, window reset, preflight is free, proxy headers',()=>{let t=1000;const g=makeGuard({limit:3,windowMs:60000,now:()=>t})
 for(let i=0;i<3;i++)assert.ok(g.check(req({ip:'1.1.1.1, 9.9.9.9'})).ok)
 const r=g.check(req({ip:'1.1.1.1'}));assert.ok(!r.ok);assert.equal(!r.ok&&r.status,429);assert.ok(Number(r.headers['Retry-After'])>=1)
 assert.ok(g.check(req({ip:'2.2.2.2'})).ok,'other IPs are unaffected');for(let i=0;i<10;i++)assert.ok(g.check(req({ip:'1.1.1.1',method:'OPTIONS'})).ok,'OPTIONS not counted')
 assert.ok(!g.check(req({ip:'1.1.1.1'})).ok);t+=60001;assert.ok(g.check(req({ip:'1.1.1.1'})).ok,'window resets')
 const c=makeGuard({limit:1,windowMs:60000,now:()=>t});assert.ok(c.check(req({cf:'5.5.5.5',ip:'6.6.6.6'})).ok);assert.ok(!c.check(req({cf:'5.5.5.5',ip:'7.7.7.7'})).ok,'cf-connecting-ip wins over x-forwarded-for')})
const script=path.resolve('scripts/check-env.cjs'),b64=(o:object)=>Buffer.from(JSON.stringify(o)).toString('base64url'),jwt=(p:object)=>`${b64({alg:'HS256'})}.${b64(p)}.sig`
const run=(env:string,app?:object,files:string[]=[],release=false)=>{const d=fs.mkdtempSync(path.join(os.tmpdir(),'cm-'));fs.writeFileSync(path.join(d,'.env'),env);if(app)fs.writeFileSync(path.join(d,'app.json'),JSON.stringify({expo:app}));for(const f of files){fs.mkdirSync(path.dirname(path.join(d,f)),{recursive:true});fs.writeFileSync(path.join(d,f),'x')}
 const r=spawnSync(process.execPath,[script,d,...(release?['--release']:[])],{encoding:'utf8',env:{PATH:process.env.PATH}});return{code:r.status,out:r.stderr+r.stdout}}
test('check-env: blocks secrets that would ship inside the app',()=>{
 assert.equal(run(`VITE_CATALOG_PROXY_URL=https://x.supabase.co/functions/v1/tmdb\nVITE_SUPABASE_ANON_KEY=${jwt({role:'anon'})}\n`).code,0)
 assert.equal(run(`VITE_SUPABASE_ANON_KEY=${jwt({role:'service_role'})}\n`).code,1,'service_role key');assert.equal(run('VITE_TMDB_TOKEN=abc\n').code,1,'secret-like name');assert.equal(run('EXPO_PUBLIC_DEEPL_API_KEY=abc:fx\n').code,1)
 assert.equal(run(`VITE_X=${jwt({aud:'abc',scopes:['api_read']})}\n`).code,1,'TMDB-style token in a public variable');assert.equal(run('VITE_CATALOG_PROXY_URL=http://example.com/tmdb\n').code,1,'cleartext URL');assert.equal(run('VITE_CATALOG_PROXY_URL=http://localhost:54321/functions/v1/tmdb\n').code,0,'localhost http is fine for development')})
test('check-env --release: placeholder id, missing icons, backups',()=>{const good={icon:'./assets/icon.png',android:{package:'org.mycinemora.app',allowBackup:false,adaptiveIcon:{foregroundImage:'./assets/adaptive-icon.png'}}},files=['assets/icon.png','assets/adaptive-icon.png']
 assert.equal(run('',good,files,true).code,0);assert.match(run('',{...good,android:{...good.android,package:'com.example.cinemora'}},files,true).out,/placeholder/);assert.equal(run('',good,[],true).code,1,'missing icon files')
 assert.equal(run('',{...good,android:{...good.android,allowBackup:true}},files,true).code,1);assert.equal(run('',{...good,android:{...good.android,package:'Bad Id'}},files,true).code,1)})
test('release assets: manifest icons exist with the declared sizes; iOS and Android install tags present; the real app.json passes the release gate',()=>{
 const man=JSON.parse(fs.readFileSync('public/manifest.webmanifest','utf8'));for(const i of man.icons){const f=path.join('public',i.src);assert.ok(fs.existsSync(f),f)}
 const png=(f:string)=>{const b=fs.readFileSync(f);return[b.readUInt32BE(16),b.readUInt32BE(20)]};assert.deepEqual(png('public/icon-192.png'),[192,192]);assert.deepEqual(png('public/icon-512.png'),[512,512]);assert.deepEqual(png('public/apple-touch-icon.png'),[180,180]);assert.deepEqual(png('mobile/assets/icon.png'),[1024,1024])
 assert.ok(man.icons.some((i:{purpose:string})=>i.purpose==='maskable'));const html=fs.readFileSync('index.html','utf8');assert.match(html,/rel="apple-touch-icon"/);assert.match(html,/name="referrer" content="no-referrer"/)
 const real=spawnSync(process.execPath,[script,'mobile','--release'],{encoding:'utf8'});assert.equal(real.status,0,real.stderr);assert.doesNotMatch(JSON.parse(fs.readFileSync('mobile/app.json','utf8')).expo.android.package,/^com\.example/,'placeholder package id replaced')})
