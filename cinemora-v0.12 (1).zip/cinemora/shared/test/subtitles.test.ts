import {test} from 'node:test'
import assert from 'node:assert/strict'
import {parseSubtitles,serializeSrt,serializeVtt,cueAt,decodeSubtitleBytes,SubtitleError,parseTimestamp,stripTags} from '../subtitles.ts'
import {translateCues,TranslationError,createTranslationClient,translatedTrack,friendlyError} from '../translate.ts'
import type {TranslationClient} from '../translate.ts'
const SRT='\uFEFF1\r\n00:00:01,000 --> 00:00:03,500\r\n<i>Hola</i>\r\nmundo\r\n\r\n2\r\n00:01:02,250 --> 00:01:04,000\r\n¿Cómo estás?\r\n\r\n3\r\nbroken --> line\r\nignored\r\n\r\n4\r\n01:00:00,001 --> 01:00:02,000\r\nAdiós\r\n'
const VTT='WEBVTT - demo\n\nNOTE a comment\n--> not a cue\n\nintro\n00:01.500 --> 00:03.000 align:start position:10%\nHello <b>there</b>\n\n01:02:03.456 --> 01:02:05.000\nSecond\nline\n'
const fake=(fn:(t:string[],s?:string)=>string[]|Promise<string[]>):TranslationClient=>({configured:true,languages:async()=>['es'],translate:async(t,s)=>fn(t,s)})
const nosleep=async()=>{}
const many=(n:number)=>Array.from({length:n},(_,i)=>({start:i*1000,end:i*1000+900,text:`line ${i}`}))
test('parses SRT with BOM, CRLF, tags, multi-line, skips malformed cues',()=>{const r=parseSubtitles(SRT);assert.equal(r.format,'srt');assert.equal(r.cues.length,3)
 assert.deepEqual([r.cues[0].start,r.cues[0].end],[1000,3500]);assert.equal(r.cues[0].text,'<i>Hola</i>\nmundo');assert.equal(r.cues[0].id,'1')
 assert.deepEqual([r.cues[1].start,r.cues[1].end],[62250,64000]);assert.equal(r.cues[2].start,3600001)})
test('parses WebVTT: header, NOTE, ids, settings, short and long timestamps',()=>{const r=parseSubtitles(VTT);assert.equal(r.format,'vtt');assert.equal(r.cues.length,2)
 assert.deepEqual([r.cues[0].start,r.cues[0].end],[1500,3000]);assert.equal(r.cues[0].id,'intro');assert.equal(r.cues[1].start,3723456);assert.equal(r.cues[1].text,'Second\nline')})
test('timestamps survive a round trip through both formats',()=>{const a=parseSubtitles(SRT).cues,viaSrt=parseSubtitles(serializeSrt(a)).cues,viaVtt=parseSubtitles(serializeVtt(a)).cues
 for(const b of [viaSrt,viaVtt]){assert.equal(b.length,a.length);b.forEach((c,i)=>{assert.equal(c.start,a[i].start);assert.equal(c.end,a[i].end);assert.equal(c.text,a[i].text)})}})
test('rejects empty and non-subtitle input with clear errors',()=>{assert.throws(()=>parseSubtitles('   '),SubtitleError);assert.throws(()=>parseSubtitles('hello world'),/No subtitle lines/);assert.throws(()=>parseSubtitles('x'.repeat(2*1024*1024+1)),/too large/)})
test('parseTimestamp and stripTags',()=>{assert.equal(parseTimestamp('00:00:01,5'),1500);assert.equal(parseTimestamp('nope'),null);assert.equal(stripTags('{\\an8}<i>A &amp; B</i>'),'A & B')})
test('cueAt finds the active cue and respects gaps',()=>{const c=parseSubtitles(SRT).cues;assert.equal(cueAt(c,500),undefined);assert.equal(cueAt(c,1000)?.text,'<i>Hola</i>\nmundo');assert.equal(cueAt(c,3500),undefined);assert.equal(cueAt(c,63000)?.id,'2');assert.equal(cueAt(c,1000-500+500)?.id,'1')})
test('decodes UTF-8 and UTF-16 bytes',()=>{assert.equal(decodeSubtitleBytes(new TextEncoder().encode('¿Qué?')),'¿Qué?');const u=Buffer.from('\uFEFFhi','utf16le');assert.equal(decodeSubtitleBytes(new Uint8Array(u)),'hi')})
test('translation changes only text: timing, ids and order are preserved; markup and line breaks are not sent',async()=>{const cues=parseSubtitles(SRT).cues,sent:string[]=[]
 const r=await translateCues(cues,fake(t=>{sent.push(...t);return t.map(x=>'EN:'+x)}),{source:'es',sleep:nosleep});assert.equal(r.failed,0);assert.equal(r.cues.length,cues.length)
 r.cues.forEach((c,i)=>{assert.equal(c.start,cues[i].start);assert.equal(c.end,cues[i].end);assert.equal(c.id,cues[i].id);assert.ok(c.text.startsWith('EN:'))});assert.equal(sent[0],'Hola mundo');assert.equal(cues[0].text,'<i>Hola</i>\nmundo')})
test('batches respect the item limit',async()=>{const sizes:number[]=[];await translateCues(many(100),fake(t=>{sizes.push(t.length);return t}),{maxItems:40,sleep:nosleep});assert.deepEqual(sizes,[40,40,20])})
test('a failed batch keeps its original text and is reported, without failing the whole job',async()=>{let n=0
 const r=await translateCues(many(90),fake(t=>{n++;if(n===2)throw new TranslationError('provider_error','boom');return t.map(x=>'T:'+x)}),{maxItems:40,retries:0,sleep:nosleep})
 assert.equal(r.failed,40);assert.equal(r.translated,50);assert.equal(r.cues[0].text,'T:line 0');assert.equal(r.cues[40].text,'line 40');assert.equal(r.cues[40].start,40000);assert.equal(r.error?.code,'provider_error')
 const t=translatedTrack({id:'x',label:'Spanish',lang:'es',origin:'imported',format:'srt',cues:[]},r);assert.match(t.label,/40 lines left in the original/);assert.equal(t.machine,true)})
test('transient errors are retried and then succeed',async()=>{let n=0;const r=await translateCues(many(3),fake(t=>{n++;if(n<3)throw new TranslationError('network','x');return t.map(x=>'ok')}),{sleep:nosleep});assert.equal(n,3);assert.equal(r.failed,0)})
test('translating nothing successfully throws; fatal errors stop immediately',async()=>{let calls=0
 await assert.rejects(translateCues(many(100),fake(()=>{calls++;throw new TranslationError('unsupported_language','no yo')}),{maxItems:10,sleep:nosleep}),(e:unknown)=>e instanceof TranslationError&&e.code==='unsupported_language');assert.equal(calls,1)
 await assert.rejects(translateCues(many(5),fake(()=>{throw new TranslationError('provider_error','x')}),{retries:1,sleep:nosleep}),TranslationError)})
test('a malformed provider reply (wrong length) counts as failure, not corruption',async()=>{await assert.rejects(translateCues(many(3),fake(()=>['only one']),{retries:0,sleep:nosleep}),(e:unknown)=>e instanceof TranslationError&&e.code==='bad_response')})
test('cancellation',async()=>{const c=new AbortController();c.abort();await assert.rejects(translateCues(many(3),fake(t=>t),{signal:c.signal}),(e:unknown)=>e instanceof TranslationError&&e.code==='cancelled')})
test('results are cached so the provider is not called twice',async()=>{const mem=new Map<string,string>(),kv={get:async(k:string)=>mem.get(k)??null,set:async(k:string,v:string)=>{mem.set(k,v)},remove:async(k:string)=>{mem.delete(k)},keys:async()=>[...mem.keys()]};let calls=0
 const cl=fake(t=>{calls++;return t.map(x=>'T:'+x)});const a=await translateCues(many(5),cl,{storage:kv,source:'es'});const b=await translateCues(many(5),cl,{storage:kv,source:'es'});assert.equal(calls,1);assert.deepEqual(a.cues,b.cues)})
test('client: unconfigured, language list, HTTP errors and malformed replies',async()=>{
 await assert.rejects(createTranslationClient({}).languages(),(e:unknown)=>e instanceof TranslationError&&e.code==='not_configured')
 const real=globalThis.fetch;const reply=(status:number,body:unknown)=>{globalThis.fetch=(async()=>new Response(JSON.stringify(body),{status}))as typeof fetch}
 try{const c=createTranslationClient({baseUrl:'https://x.test/translate/',anonKey:'anon'})
  reply(200,{sources:['ES','fr']});assert.deepEqual(await c.languages(),['es','fr'])
  reply(200,{translations:['a','b']});assert.deepEqual(await c.translate(['x','y'],'es'),['a','b'])
  reply(200,{translations:['a']});await assert.rejects(c.translate(['x','y'],'es'),(e:unknown)=>e instanceof TranslationError&&e.code==='bad_response')
  reply(402,{error:{code:'quota',message:'Quota used up.'}});await assert.rejects(c.translate(['x'],undefined),(e:unknown)=>e instanceof TranslationError&&e.code==='quota')
  reply(429,{});await assert.rejects(c.translate(['x'],undefined),(e:unknown)=>e instanceof TranslationError&&e.code==='rate_limited')
  globalThis.fetch=(async()=>{throw new TypeError('offline')})as typeof fetch;await assert.rejects(c.translate(['x'],undefined),(e:unknown)=>e instanceof TranslationError&&e.code==='network')
 }finally{globalThis.fetch=real}
 assert.match(friendlyError(new TranslationError('quota','')),/quota/)})
