import {test} from 'node:test'
import assert from 'node:assert/strict'
import {SOURCES,evaluateSource,canDownload,isPlayable,getSource,availabilityFor} from '../sources'
import {SAMPLE} from '../sample'
import {search} from '../search'
import {createMetadata,MetadataError} from '../metadata'
import type {Source} from '../types'
const mkKV=()=>{const m=new Map<string,string>();return{get:async(k:string)=>m.get(k)??null,set:async(k:string,v:string)=>{m.set(k,v)},remove:async(k:string)=>{m.delete(k)},keys:async()=>[...m.keys()]}}
const base:Source={id:'t',movieId:'x',provider:{name:'p',url:'https://p'},mediaUrl:'https://p/x.mp4',mediaType:'mp4',license:{name:'l',url:'https://l',status:'cc-by'},evidence:['https://e'],streaming:true,download:true,territories:'worldwide',verified:true,verifiedAt:'2026-01-01',attribution:'a'}
test('every source record is well-formed',()=>{for(const s of SOURCES){assert.ok(SAMPLE.some(m=>m.id===s.movieId),`${s.id}: movie ${s.movieId} missing`);assert.match(s.mediaUrl,/^https:\/\//,`${s.id} must be https`)
 assert.ok(s.mediaUrl.toLowerCase().endsWith('.'+s.mediaType),`${s.id} extension vs type`);assert.ok(s.evidence.length>0,`${s.id} evidence`)
 if(s.verified){assert.ok(s.verifiedAt,`${s.id} verifiedAt`);assert.ok(s.license.url.startsWith('https://'),`${s.id} license url`);assert.ok(s.attribution.length>3)}}
 assert.equal(new Set(SOURCES.map(s=>s.movieId)).size,SOURCES.length,'one source per movie')})
test('availability rules',()=>{const ev=(o:Partial<Source>,r?:string)=>evaluateSource({...base,...o},r,new Date('2026-10-19'))
 assert.equal(ev({}).ok,true);assert.equal(ev({withdrawn:true}).state,'withdrawn');assert.equal(ev({expiresAt:'2026-10-01'}).state,'expired');assert.equal(ev({expiresAt:'2027-01-01'}).ok,true)
 assert.equal(ev({verified:false}).state,'under-review');assert.equal(ev({streaming:false}).state,'no-streaming')
 assert.equal(ev({territories:['US']}).state,'region');assert.match(ev({territories:['US']}).message,/Settings/);assert.equal(ev({territories:['US']},'NG').state,'region');assert.equal(ev({territories:['US','NG']},'NG').ok,true)
 assert.equal(ev({withdrawn:true,verified:false}).state,'withdrawn','withdrawn wins')})
test('download rules',()=>{const cd=(o:Partial<Source>)=>canDownload({...base,...o});assert.equal(cd({}).ok,true);assert.equal(cd({download:false}).ok,false);assert.equal(cd({drm:true}).ok,false);assert.equal(cd({mediaType:'hls'}).ok,false);assert.equal(cd({verified:false}).ok,false);assert.equal(cd({withdrawn:true}).ok,false)})
test('catalog gating: playable titles are exactly the verified sources',()=>{for(const m of SAMPLE)assert.equal(isPlayable(m.id),Boolean(getSource(m.id)?.verified),m.title);assert.equal(availabilityFor('s-1'),undefined)})
const top=(q:string)=>search(SAMPLE,q)[0]?.title
test('SAMPLE-mode search accuracy report',()=>{const cases:[string,string|undefined][]=[['nosferatu','Nosferatu'],['Nosferato','Nosferatu'],['nosfer','Nosferatu'],['spirted away','Spirited Away'],['parasit','Parasite'],['lagan','Lagaan'],['living bondage','Living in Bondage'],['tears steel','Tears of Steel'],['sintle','Sintel'],['aamir khan','Lagaan'],['miyazaki',undefined],['korean','Parasite'],['2019','Parasite'],['nigeria','Living in Bondage'],['rabbit','Big Buck Bunny'],['madmax','Mad Max: Fury Road'],['xyzzy',undefined],['???',undefined],['',undefined],['a',undefined]]
 const bad:string[]=[];for(const[q,exp]of cases){const got=top(q);if(got!==exp)bad.push(`"${q}": expected ${exp??'none'}, got ${got??'none'}`)}
 console.log(`SEARCH ${cases.length-bad.length}/${cases.length} as expected`);bad.forEach(b=>console.log('  MISS '+b))
 assert.doesNotThrow(()=>search(SAMPLE,'('.repeat(500)));assert.doesNotThrow(()=>search(SAMPLE,'x'.repeat(5000)))})
test('SAMPLE metadata completeness report',()=>{const miss={poster:0,cast:0,runtime:0,synopsis:0,director:0};for(const m of SAMPLE){if(!m.poster)miss.poster++;if(!m.cast.length)miss.cast++;if(!m.runtime)miss.runtime++;if(!m.synopsis)miss.synopsis++;if(!('director' in m))miss.director++}
 console.log(`METADATA of ${SAMPLE.length} sample records missing:`,JSON.stringify(miss))})
const res=(body:unknown,status=200,h:Record<string,string>={})=>new Response(JSON.stringify(body),{status,headers:h})
const raw=(id:number,t:string)=>({id,title:t,release_date:'2001-05-01',genre_ids:[28],original_language:'fr',overview:'o',poster_path:'/p.jpg',backdrop_path:null})
test('metadata client: pagination, mapping, caching, errors, retries',async()=>{const calls:string[]=[];let mode='ok';const real=globalThis.fetch
 globalThis.fetch=(async(u:string|URL|Request)=>{const url=String(u);calls.push(url);if(mode==='net')throw new TypeError('x');if(mode==='500')return res({},500);if(mode==='429once'){mode='ok';return res({},429,{'retry-after':'0'})}
  if(url.includes('/genre/movie/list'))return res({genres:[{id:28,name:'Action'}]});const pg=Number(/page=(\d+)/.exec(url)?.[1]||1)
  if(url.includes('/movie/999'))return res({},404);if(/\/movie\/\d+\?/.test(url))return res({...raw(7,'Seven'),genres:[{id:28,name:'Action'}],runtime:101,production_countries:[{name:'France'}],spoken_languages:[{english_name:'French'}],credits:{cast:[{name:'A'},{name:'B'}]}})
  return res({results:[raw(pg*10,'P'+pg)],page:pg,total_pages:900,total_results:9000})})as typeof fetch
 try{const m=createMetadata({baseUrl:'https://x.test/tmdb/',anonKey:'k',storage:mkKV()})
  const p2=await m.discover({page:2,genre:'28',year:'2001'});assert.equal(p2.page,2);assert.equal(p2.totalPages,500,'capped at 500');assert.equal(p2.items[0].genres[0],'Action');assert.equal(p2.items[0].language,'French');assert.ok(calls.some(c=>c.includes('with_genres=28')&&c.includes('primary_release_year=2001')&&c.includes('page=2')))
  const n=calls.length;await m.discover({page:2,genre:'28',year:'2001'});assert.equal(calls.length,n,'cached');const d=await m.getMovieDetails(7);assert.equal(d.runtime,101);assert.deepEqual(d.cast,['A','B']);assert.equal(d.country,'France')
  await assert.rejects(m.getMovieDetails(999),(e:unknown)=>e instanceof MetadataError&&e.status===404);const before=calls.length;assert.equal((await m.searchMovies('   ')).items.length,0);assert.equal(calls.length,before,'blank search makes no request')
  mode='429once';assert.ok((await m.searchMovies('a b&c=d')).items.length>0);assert.ok(calls.some(c=>c.includes('query=a%20b%26c%3Dd')),'query is URL-encoded')
  assert.ok(await m.recall('tmdb-7'),'recently-seen cache filled')
  mode='net';await assert.rejects(m.searchMovies('zzz'),/Network error/);mode='500';await assert.rejects(m.searchMovies('yyy'),(e:unknown)=>e instanceof MetadataError&&e.status===500)
  assert.equal(createMetadata({storage:mkKV()}).configured,false);await assert.rejects(createMetadata({storage:mkKV()}).searchMovies('x'),/not configured/)
 }finally{globalThis.fetch=real}})
test('catalog: titles that appear in several TMDB lists stay in every list (rows must not vanish)',async()=>{const real=globalThis.fetch
 globalThis.fetch=(async(u:string|URL|Request)=>{const url=String(u);if(url.includes('/genre/'))return res({genres:[]});return res({results:[raw(1,'A'),raw(2,'B')],page:1,total_pages:1,total_results:2})})as typeof fetch
 try{const{loadCatalog}=await import('../metadata');const{movies,live}=await loadCatalog(createMetadata({baseUrl:'https://x.test',storage:mkKV()}),true);assert.equal(live,true);const a=movies.find(m=>m.id==='tmdb-1')!
  assert.deepEqual([...a.collections!].sort(),['Recently added','Top rated','Trending']);assert.equal(movies.filter(m=>m.id==='tmdb-1').length,1,'no duplicate cards')}finally{globalThis.fetch=real}})
