import type {Cue,SubtitleTrack} from './types'
// SRT and WebVTT parsing/serializing. Pure functions, no platform APIs. Times are integer milliseconds.
export class SubtitleError extends Error{}
const MAX_CHARS=2*1024*1024,MAX_CUES=20000
const TIME=/(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{1,3})/
export function parseTimestamp(s:string):number|null{const m=TIME.exec(s.trim());if(!m)return null
 return(((m[1]?+m[1]:0)*3600+(+m[2])*60+(+m[3]))*1000)+Number(m[4].padEnd(3,'0'))}
export function parseSubtitles(input:string):{format:'srt'|'vtt';cues:Cue[]}{
 if(input.length>MAX_CHARS)throw new SubtitleError('This subtitle file is too large (over 2 MB).')
 const text=input.replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n').trim()
 if(!text)throw new SubtitleError('The subtitle file is empty.')
 const vtt=/^WEBVTT/.test(text),cues:Cue[]=[]
 for(const block of text.split(/\n{2,}/)){const lines=block.split('\n'),ti=lines.findIndex(l=>l.includes('-->'))
  if(ti<0||(vtt&&/^(NOTE|STYLE|REGION)\b/.test(lines[0])))continue
  const[a,rest]=lines[ti].split('-->'),start=parseTimestamp(a),end=parseTimestamp(rest.trim().split(/\s+/)[0])
  const body=lines.slice(ti+1).join('\n').trim()
  if(start===null||end===null||end<=start||!body)continue   // skip malformed cues instead of failing the whole file
  cues.push({start,end,text:body,...(ti>0&&lines[0].trim()?{id:lines[0].trim()}:{})})}
 if(!cues.length)throw new SubtitleError('No subtitle lines were found. Is this an SRT or WebVTT file?')
 if(cues.length>MAX_CUES)throw new SubtitleError('This subtitle file has too many lines.')
 return{format:vtt?'vtt':'srt',cues:cues.sort((x,y)=>x.start-y.start)}}
const pad=(n:number,w:number)=>String(n).padStart(w,'0')
export const formatTimestamp=(ms:number,sep:','|'.')=>{const t=Math.round(ms);return`${pad(Math.floor(t/3600000),2)}:${pad(Math.floor(t%3600000/60000),2)}:${pad(Math.floor(t%60000/1000),2)}${sep}${pad(t%1000,3)}`}
export const serializeSrt=(c:Cue[])=>c.map((x,i)=>`${i+1}\n${formatTimestamp(x.start,',')} --> ${formatTimestamp(x.end,',')}\n${x.text}`).join('\n\n')+'\n'
export const serializeVtt=(c:Cue[])=>'WEBVTT\n\n'+c.map(x=>`${formatTimestamp(x.start,'.')} --> ${formatTimestamp(x.end,'.')}\n${x.text}`).join('\n\n')+'\n'
/** Visible text for display: drops markup like <i> and {\an8}; keeps line breaks. */
export const stripTags=(s:string)=>s.replace(/\{\\[^}]*\}/g,'').replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&')
/** Active cue at `ms` (cues sorted by start). A positive subtitle delay is applied by the caller as ms - delay. */
export function cueAt(cues:Cue[],ms:number):Cue|undefined{let lo=0,hi=cues.length-1,f=-1
 while(lo<=hi){const mid=(lo+hi)>>1;if(cues[mid].start<=ms){f=mid;lo=mid+1}else hi=mid-1}
 for(let i=f;i>=0&&i>f-5;i--)if(ms>=cues[i].start&&ms<cues[i].end)return cues[i]
 return undefined}
export const primaryLang=(l:string)=>l.toLowerCase().split(/[-_]/)[0]
export const SUB_LANGS:[string,string][]=[['und','Not sure'],['es','Spanish'],['fr','French'],['de','German'],['pt','Portuguese'],['it','Italian'],['hi','Hindi'],['ko','Korean'],['ja','Japanese'],['zh','Chinese'],['ar','Arabic'],['ru','Russian'],['tr','Turkish'],['yo','Yoruba'],['sw','Swahili'],['en','English']]
export const langName=(code:string)=>SUB_LANGS.find(x=>x[0]===primaryLang(code))?.[1]||code
/** Decode raw file bytes: UTF-16 BOM, then UTF-8, else a Windows-1252 guess. */
export function decodeSubtitleBytes(b:Uint8Array):string{const TD=(globalThis as unknown as {TextDecoder?:new(l:string,o?:{fatal:boolean})=>{decode(x:Uint8Array):string}}).TextDecoder
 if(!TD)throw new SubtitleError('This device can’t decode subtitle files.')
 if(b[0]===0xFF&&b[1]===0xFE)return new TD('utf-16le').decode(b.subarray(2))
 if(b[0]===0xFE&&b[1]===0xFF)return new TD('utf-16be').decode(b.subarray(2))
 try{return new TD('utf-8',{fatal:true}).decode(b)}catch{return new TD('windows-1252').decode(b)}}
export function makeImportedTrack(fileName:string,content:string,lang:string):SubtitleTrack{const{format,cues}=parseSubtitles(content)
 return{id:'imp-'+Math.random().toString(36).slice(2,8),label:fileName.replace(/\.[^.]+$/,'')||'Imported subtitles',lang,origin:'imported',format,cues}}
