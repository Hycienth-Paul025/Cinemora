// Checks that a playback URL really serves media. Needs internet, so it is run by you (npm run check:sources), not by the app.
export interface CheckResult{ok:boolean;status?:number;contentType?:string;bytes?:number;warning?:string;problem?:string}
export async function checkSource(url:string,f:typeof fetch=fetch,timeoutMs=15000):Promise<CheckResult>{
 const c=new AbortController(),t=setTimeout(()=>c.abort(),timeoutMs)
 try{const r=await f(url,{headers:{Range:'bytes=0-1023'},redirect:'follow',signal:c.signal})
  const ct=r.headers.get('content-type')||'',cr=/\/(\d+)$/.exec(r.headers.get('content-range')||''),bytes=cr?Number(cr[1]):Number(r.headers.get('content-length')||0)
  await r.body?.cancel().catch(()=>undefined)
  if(r.status!==200&&r.status!==206)return{ok:false,status:r.status,problem:`HTTP ${r.status}`}
  if(!/^(video|audio)\//i.test(ct)&&!/octet-stream/i.test(ct))return{ok:false,status:r.status,contentType:ct,problem:`unexpected content type "${ct}" (an error page?)`}
  if(bytes&&bytes<100_000)return{ok:false,status:r.status,contentType:ct,bytes,problem:'file is suspiciously small'}
  return{ok:true,status:r.status,contentType:ct,bytes:bytes||undefined,warning:r.status===206?undefined:'server ignored the Range request: seeking and download resume may not work'}}
 catch(e){return{ok:false,problem:(e as Error).name==='AbortError'?'timed out':`network error: ${(e as Error).message}`}}
 finally{clearTimeout(t)}}
