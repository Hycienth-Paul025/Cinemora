#!/usr/bin/env node
// Release/security gate. Usage: node scripts/check-env.cjs <project dir> [--release]
// Fails if a variable that ships inside the app (VITE_* / EXPO_PUBLIC_*) looks like a secret, or (with --release) if Android release settings are unsafe.
const fs=require('fs'),path=require('path')
const dir=path.resolve(process.argv[2]||'.'),release=process.argv.includes('--release'),problems=[]
const env={},f=path.join(dir,'.env')
if(fs.existsSync(f))for(const line of fs.readFileSync(f,'utf8').split(/\r?\n/)){if(line.trim().startsWith('#'))continue;const m=/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);if(m)env[m[1]]=m[2].replace(/^["']|["']$/g,'')}
for(const[k,v]of Object.entries(process.env))if(/^(VITE_|EXPO_PUBLIC_)/.test(k)&&!(k in env))env[k]=v||''
const pub=Object.entries(env).filter(([k])=>/^(VITE_|EXPO_PUBLIC_)/.test(k))
const b64=s=>JSON.parse(Buffer.from(s.replace(/-/g,'+').replace(/_/g,'/'),'base64').toString('utf8'))
for(const[k,v]of pub){
 if(/(SECRET|PRIVATE|SERVICE_ROLE|PASSWORD|TOKEN|API_?KEY)/i.test(k))problems.push(`${k}: variables with this prefix ship inside the app; secrets belong on the server.`)
 if(!v)continue
 const jm=/^eyJ[\w-]+\.([\w-]+)\.[\w-]*$/.exec(v)
 if(jm){let role;try{role=b64(jm[1]).role}catch{/* not JSON */}if(role!=='anon')problems.push(`${k}: looks like a private token (${role?`role "${role}"`:'a JWT without the anon role'}). Only the Supabase anon key may be public.`)}
 if(/^http:\/\//i.test(v)&&!/^http:\/\/(localhost|127\.0\.0\.1)(:|\/|$)/.test(v))problems.push(`${k}: uses http://; use https:// (cleartext is blocked on Android and unsafe on the web).`)
 if(/:fx$/.test(v)||/sk-[A-Za-z0-9]{20,}/.test(v))problems.push(`${k}: the value looks like a provider API key.`)}
if(release){const a=path.join(dir,'app.json')
 if(!fs.existsSync(a))problems.push('app.json not found.')
 else{const x=JSON.parse(fs.readFileSync(a,'utf8')).expo||{},pkg=x.android&&x.android.package
  if(!pkg||!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(pkg))problems.push(`android.package "${pkg}" is not a valid Android package id.`)
  else if(/^com\.example(\.|$)/.test(pkg))problems.push(`android.package is still the placeholder "${pkg}". Choose a permanent unique id before a release (it cannot change after publishing).`)
  for(const[label,p]of[['icon',x.icon],['adaptive icon',x.android&&x.android.adaptiveIcon&&x.android.adaptiveIcon.foregroundImage]])if(!p||!fs.existsSync(path.join(dir,p)))problems.push(`${label} file is missing${p?': '+p:''}.`)
  if(!x.android||x.android.allowBackup!==false)problems.push('android.allowBackup must be false so downloaded files are not copied to cloud backups.')}}
if(problems.length){console.error('Release/security check FAILED:\n'+problems.map(p=>' - '+p).join('\n'));process.exit(1)}
console.log(`Release/security check passed (${pub.length} public variables checked${release?', release settings checked':''}).`)
