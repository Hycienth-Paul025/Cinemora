// Usage: npm run check:sources   (needs internet). Fails if a verified source does not serve real media. Run before every release and on a schedule.
import {SOURCES} from '../shared/sources'
import {checkSource} from '../shared/sourceCheck'
;(async()=>{let bad=0
 for(const s of SOURCES.filter(x=>x.verified&&x.streaming&&!x.withdrawn)){const r=await checkSource(s.mediaUrl)
  console.log(`${r.ok?'OK  ':'FAIL'} ${s.id}  ${r.ok?`${r.status} ${r.contentType}${r.bytes?` ${(r.bytes/1048576).toFixed(0)} MB`:''}${r.warning?`  (warning: ${r.warning})`:''}`:r.problem}`);if(!r.ok)bad++}
 if(bad){console.error(`\n${bad} source(s) failed. Withdraw or fix them (set withdrawn:true or update the URL) before releasing.`);process.exit(1)}
 console.log('\nAll verified sources serve media. This does not prove the file is the right film: watch each one once.')})()
