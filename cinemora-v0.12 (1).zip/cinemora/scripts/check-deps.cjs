#!/usr/bin/env node
// Usage: node scripts/check-deps.cjs <project dir> [--warn]. Blocks unpinned dependency ranges and a missing lockfile (reproducible, auditable builds).
const fs=require('fs'),path=require('path')
const dir=path.resolve(process.argv[2]||'.'),warnOnly=process.argv.includes('--warn'),problems=[]
const pj=JSON.parse(fs.readFileSync(path.join(dir,'package.json'),'utf8'))
for(const[name,v]of Object.entries({...pj.dependencies,...pj.devDependencies})){if(/^(\*|latest|x|)$/i.test(v)||/^(git|github:|https?:)/i.test(v))problems.push(`${name}: version "${v||'(empty)'}" is not pinned.`)}
if(!['package-lock.json','yarn.lock','pnpm-lock.yaml','bun.lock','bun.lockb'].some(f=>fs.existsSync(path.join(dir,f))))problems.push('no lockfile found. Run the install on your machine and commit it.')
if(problems.length){console.error(`Dependency check ${warnOnly?'warning':'FAILED'}:\n`+problems.map(p=>' - '+p).join('\n')+(path.basename(dir)==='mobile'?'\n   Fix: npm install && npx expo install --fix, then commit package.json and the lockfile.':''));process.exit(warnOnly?0:1)}
console.log('Dependency check passed.')
