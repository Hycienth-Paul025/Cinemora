import {useEffect,useState} from 'react'
import {useApp} from '../store'
import {Movie} from '../types'
import {getMovieDetails,recall,tmdbConfigured} from '../services/tmdb'
/** Resolve ids to movies from the loaded catalog, the recently-seen cache, or (if needed) the metadata API. */
export function useMovies(ids:string[]):Movie[]{const{movies}=useApp();const[extra,setExtra]=useState<Record<string,Movie>>({})
 useEffect(()=>{if(!tmdbConfigured)return
  ids.filter(id=>id.startsWith('tmdb-')&&!movies.some(m=>m.id===id)&&!recall(id)&&!extra[id]).forEach(id=>{getMovieDetails(Number(id.slice(5))).then(m=>setExtra(x=>({...x,[id]:m}))).catch(()=>undefined)})
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[ids.join(','),movies])
 return ids.map(id=>movies.find(m=>m.id===id)||recall(id)||extra[id]).filter((m):m is Movie=>Boolean(m))}
