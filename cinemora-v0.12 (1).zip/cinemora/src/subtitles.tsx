import {ReactNode,RefObject,useEffect,useRef,useState} from 'react'
import {useApp} from './store'
import {SubtitleTrack} from './types'
import {SUB_LANGS,SubtitleError,cueAt,decodeSubtitleBytes,langName,makeImportedTrack,primaryLang,stripTags} from '../shared/subtitles'
import {TranslationError,createTranslationClient,friendlyError,translateCues,translatedTrack} from '../shared/translate'
import {loadTracks,saveTracks} from '../shared/subtitleStore'
import {webKV} from './services/kv'
const translator=createTranslationClient({baseUrl:import.meta.env.VITE_TRANSLATE_PROXY_URL as string|undefined,anonKey:import.meta.env.VITE_SUPABASE_ANON_KEY as string|undefined})
const box='p-4 rounded-2xl bg-panel border border-line text-sm max-w-3xl mt-4 grid gap-3'
/** Subtitle selection, import and English translation for the web player. Returns an overlay (inside the video box) and a control panel. */
export function useSubtitles(movieId:string,videoRef:RefObject<HTMLVideoElement>):{overlay:ReactNode;panel:ReactNode}{
 const{settings,setSettings}=useApp()
 const[tracks,setTracks]=useState<SubtitleTrack[]>([]),[sel,setSel]=useState('off'),[delay,setDelay]=useState(0),[text,setText]=useState(''),[lang,setLang]=useState('und')
 const[note,setNote]=useState<{err:boolean;t:string}|null>(null),[prog,setProg]=useState<{done:number;total:number}|null>(null)
 const[svc,setSvc]=useState<'off'|'checking'|'ready'|'down'>(translator.configured?'checking':'off'),[langs,setLangs]=useState<string[]>([]),ctl=useRef<AbortController|null>(null)
 useEffect(()=>{let live=true;loadTracks(webKV,movieId).then(t=>{if(live)setTracks(t)});return()=>{live=false}},[movieId])
 useEffect(()=>{if(!translator.configured)return;translator.languages().then(l=>{setLangs(l);setSvc('ready')}).catch(()=>setSvc('down'))},[])
 const cur=tracks.find(t=>t.id===sel)
 useEffect(()=>{if(!cur){setText('');return}const id=setInterval(()=>{const v=videoRef.current;if(!v)return;const c=cueAt(cur.cues,v.currentTime*1000-delay*1000);setText(c?stripTags(c.text):'')},200);return()=>clearInterval(id)},[cur,delay,videoRef])
 const persist=async(next:SubtitleTrack[])=>{setTracks(next);try{await saveTracks(webKV,movieId,next)}catch{setNote({err:true,t:'These subtitles work now but couldn’t be saved on this device (storage is full).'})}}
 const onFile=async(f?:File)=>{if(!f)return;setNote(null)
  try{if(f.size>2*1024*1024)throw new SubtitleError('That file is over 2 MB, so it probably isn’t a subtitle file.');if(tracks.length>=6)throw new SubtitleError('Remove a subtitle track first (up to 6 per movie).')
   const t=makeImportedTrack(f.name,decodeSubtitleBytes(new Uint8Array(await f.arrayBuffer())),lang);await persist([...tracks,t]);setSel(t.id);setNote({err:false,t:`Loaded ${t.cues.length} lines (${t.format.toUpperCase()}).`})}
  catch(e){setNote({err:true,t:e instanceof SubtitleError?e.message:'Couldn’t read that file.'})}}
 const reason=(t:SubtitleTrack):string|null=>{if(t.origin==='translated'||primaryLang(t.lang)==='en')return null
  if(svc==='off')return'Translation isn’t set up in this build.';if(svc==='checking')return'Checking the translation service…';if(svc==='down')return'The translation service couldn’t be reached, so translation is unavailable right now.'
  if(t.lang!=='und'&&!langs.includes(primaryLang(t.lang)))return`The configured translation service doesn’t support ${langName(t.lang)}.`;return''}
 const translate=async(t:SubtitleTrack)=>{const have=tracks.find(x=>x.from===t.id);if(have){setSel(have.id);return}
  const c=new AbortController();ctl.current=c;setNote(null);setProg({done:0,total:t.cues.length})
  try{const r=await translateCues(t.cues,translator,{source:t.lang==='und'?undefined:primaryLang(t.lang),signal:c.signal,storage:webKV,onProgress:(done,total)=>setProg({done,total})})
   const nt=translatedTrack(t,r);await persist([...tracks,nt]);setSel(nt.id)
   setNote({err:!!r.failed,t:r.failed?`Translated ${r.translated} of ${r.translated+r.failed} lines. ${friendlyError(r.error)} The rest stay in the original language.`:'Translated to English. Machine translation can contain mistakes.'})}
  catch(e){setNote({err:!(e instanceof TranslationError&&e.code==='cancelled'),t:`${friendlyError(e)} Your original subtitles are unchanged.`})}
  finally{setProg(null);ctl.current=null}}
 const remove=async(id:string)=>{if(sel===id)setSel('off');await persist(tracks.filter(t=>t.id!==id&&t.from!==id))}
 const r=cur?reason(cur):null
 const overlay=text?<div className="absolute inset-x-0 bottom-14 flex justify-center pointer-events-none px-4"><span style={{fontSize:settings.subSize}} className="px-3 py-1 rounded bg-black/75 text-white text-center whitespace-pre-line max-w-[90%]">{text}</span></div>:null
 const panel=<section className={box} aria-label="Subtitles"><b>Subtitles</b>
  <label className="grid gap-1 text-zinc-400">Track<select value={sel} onChange={e=>setSel(e.target.value)} className="bg-ink border border-line rounded-lg px-3 py-2 text-white"><option value="off">Off</option>{tracks.map(t=><option key={t.id} value={t.id}>{t.label}</option>)}</select></label>
  {cur?.machine&&<p className="text-amber-300">Machine-translated. It can contain mistakes.</p>}
  <div className="grid sm:grid-cols-2 gap-3"><label className="grid gap-1 text-zinc-400">Size: {settings.subSize}px<input type="range" min={14} max={36} value={settings.subSize} onChange={e=>setSettings({...settings,subSize:Number(e.target.value)})}/></label>
   <label className="grid gap-1 text-zinc-400">Delay: {delay.toFixed(1)}s (positive = later)<input type="range" min={-5} max={5} step={0.5} value={delay} onChange={e=>setDelay(Number(e.target.value))}/></label></div>
  <div className="grid sm:grid-cols-2 gap-3 items-end"><label className="grid gap-1 text-zinc-400">Language of the file you’re adding<select value={lang} onChange={e=>setLang(e.target.value)} className="bg-ink border border-line rounded-lg px-3 py-2 text-white">{SUB_LANGS.map(([k,n])=><option key={k} value={k}>{n}</option>)}</select></label>
   <label className="grid gap-1 text-zinc-400">Add an SRT or WebVTT file<input type="file" accept=".srt,.vtt,.txt,text/vtt,application/x-subrip" onChange={e=>{void onFile(e.target.files?.[0]);e.target.value=''}} className="text-white"/></label></div>
  {cur&&<div className="flex gap-2 flex-wrap items-center">
   {cur.origin!=='translated'&&r===null&&<span className="text-zinc-500">This track is already English.</span>}
   {cur.origin!=='translated'&&r===''&&!prog&&<button onClick={()=>void translate(cur)} className="px-4 py-1.5 rounded-full bg-gold text-black font-medium">Translate to English</button>}
   {prog&&<><span aria-live="polite">Translating… {Math.min(prog.done,prog.total)} of {prog.total}</span><button onClick={()=>ctl.current?.abort()} className="px-4 py-1.5 rounded-full border border-line">Cancel</button></>}
   {r&&<span className="text-zinc-400">{r}</span>}
   <button onClick={()=>void remove(cur.id)} className="px-4 py-1.5 rounded-full border border-line">Remove track</button></div>}
  {note&&<p role={note.err?'alert':'status'} className={note.err?'text-amber-300':'text-emerald-300'}>{note.t}</p>}
  <p className="text-xs text-zinc-500">Subtitles show on the page, not in your browser’s native fullscreen. No subtitle files are bundled for the catalog yet; add your own. Translation is offered only when the server’s provider supports the file’s language.</p></section>
 return{overlay,panel}}
