import {createClient} from '@supabase/supabase-js'
const url=import.meta.env.VITE_SUPABASE_URL as string|undefined,key=import.meta.env.VITE_SUPABASE_ANON_KEY as string|undefined
export const supabase=url&&key?createClient(url,key):null
export const supabaseConfigured=Boolean(supabase)
// PLANNED: sign-in and syncing watchlist/progress/preferences. Not implemented in v0.1; local storage is used.
