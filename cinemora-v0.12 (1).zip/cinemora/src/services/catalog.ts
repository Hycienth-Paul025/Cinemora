import {Movie} from '../types'
import {SAMPLE} from '../data/sample'
import {clearMetadataCache,listMovies,tmdbConfigured} from './tmdb'
export const metadataConfigured=tmdbConfigured
export interface Catalog{movies:Movie[];live:boolean;fetchedAt?:number}
/** Home-screen catalog: 3 TMDB lists (first page each) + the sample records. A title in several lists keeps its first collection. */
export async function loadCatalog(force=false):Promise<Catalog>{
 if(!tmdbConfigured)return{movies:SAMPLE,live:false}
 if(force)clearMetadataCache()
 const[a,b,c]=await Promise.all([listMovies('popular',1,'Trending'),listMovies('now_playing',1,'Recently added'),listMovies('top_rated',1,'Top rated')])
 const byId=new Map<string,Movie>();for(const m of [...a.items,...b.items,...c.items]){const e=byId.get(m.id);if(e)e.collections=[...new Set([...(e.collections||[]),m.collection])];else byId.set(m.id,{...m,collections:[m.collection]})}
 const movies=[...byId.values()]
 return{movies:[...movies,...SAMPLE],live:true}}
