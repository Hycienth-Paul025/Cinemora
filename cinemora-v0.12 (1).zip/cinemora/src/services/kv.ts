import type {KV} from '../../shared/metadata'
export const webKV:KV={get:async k=>localStorage.getItem(k),set:async(k,v)=>{localStorage.setItem(k,v)},remove:async k=>{localStorage.removeItem(k)},keys:async()=>Object.keys(localStorage)}
