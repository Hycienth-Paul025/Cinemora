import {Movie} from '../types'
// Metadata only. Talks to YOUR proxy (supabase/functions/tmdb), never to TMDB directly, so no secret is in the browser.
const BASE=(import.meta.env.VITE_CATALOG_PROXY_URL as string|undefined)?.replace(/\/$/,'')
const ANON=import.meta.env.VITE_SUPABASE_ANON_KEY as string|undefined
export const tmdbConfigured=Boolean(BASE)
export interface Page{items:Movie[];page:number;totalPages:number;totalResults:number}
export class MetadataError extends Error{status:number;constructor(m:string,status=0){super(m);this.status=status}}
const TTL={list:6*3600e3,detail:24*3600e3,genres:7*864e5}   // TMDB allows caching up to 6 months; we stay far below.
const PFX='cm.tm.',mem=new Map<string,{at:number;v:unknown}>()
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms))
function read<T>(k:string,ttl:number):T|undefined{const m=mem.get(k);if(m&&Date.now()-m.at<ttl)return m.v as T
 try{const r=JSON.parse(localStorage.getItem(PFX+k)||'null') as {at:number;v:T}|null;if(r&&Date.now()-r.at<ttl){mem.set(k,r);return r.v}}catch{/* ignore */}}
function write(k:string,v:unknown){const e={at:Date.now(),v};mem.set(k,e)
 try{localStorage.setItem(PFX+k,JSON.stringify(e))}catch{purge(false)}}
function purge(memToo:boolean){if(memToo)mem.clear();try{Object.keys(localStorage).filter(k=>k.startsWith(PFX)).forEach(k=>localStorage.removeItem(k))}catch{/* ignore */}}
export const clearMetadataCache=()=>purge(true)
async function request<T>(path:string,params:Record<string,string|number|undefined>,ttl:number,signal?:AbortSignal):Promise<T>{
 if(!BASE)throw new MetadataError('Metadata service is not configured')
 const qs=new URLSearchParams();for(const[k,v]of Object.entries(params))if(v!==undefined&&v!=='')qs.set(k,String(v));qs.sort()
 const key=`${path}?${qs}`,hit=read<T>(key,ttl);if(hit)return hit
 for(let i=0;;i++){let res:Response
  try{res=await fetch(`${BASE}${path}?${qs}`,{signal,headers:ANON?{apikey:ANON,Authorization:`Bearer ${ANON}`}:undefined})}
  catch(e){if(signal?.aborted)throw e;if(i<2){await sleep(500*2**i);continue}throw new MetadataError('Network error. Check your connection and try again.')}
  if(res.ok){const j=await res.json() as T;write(key,j);return j}
  if((res.status===429||res.status>=500)&&i<2){await sleep(Number(res.headers.get('retry-after'))*1000||500*2**i);continue}
  throw new MetadataError(res.status===404?'Not found':res.status===429?'Too many requests. Wait a moment.':`Metadata service error (${res.status})`,res.status)}}
// ---- recently seen movies, so Watchlist/Continue can show items without refetching (30-day expiry)
const SEEN='cm.seen',SEEN_TTL=30*864e5
type SeenMap=Record<string,{at:number;m:Movie}>
const seen=():SeenMap=>{try{return JSON.parse(localStorage.getItem(SEEN)||'{}') as SeenMap}catch{return{}}}
export function remember(ms:Movie[]){const s=seen(),now=Date.now();for(const m of ms)if(m.verified)s[m.id]={at:now,m}
 const o:SeenMap={};Object.keys(s).filter(k=>now-s[k].at<SEEN_TTL).sort((a,b)=>s[b].at-s[a].at).slice(0,300).forEach(k=>{o[k]=s[k]})
 try{localStorage.setItem(SEEN,JSON.stringify(o))}catch{/* ignore */}}
export function recall(id:string):Movie|undefined{const e=seen()[id];return e&&Date.now()-e.at<SEEN_TTL?e.m:undefined}
// ---- mapping
const IMG='https://image.tmdb.org/t/p/'
interface RawList{id:number;title:string;release_date?:string;genre_ids?:number[];original_language?:string;overview?:string;poster_path?:string|null;backdrop_path?:string|null}
interface RawPage{results:RawList[];page:number;total_pages:number;total_results:number}
interface RawDetail extends Omit<RawList,'genre_ids'>{genres:{id:number;name:string}[];runtime?:number|null;tagline?:string;production_countries?:{name:string}[];spoken_languages?:{english_name:string}[];credits?:{cast:{name:string}[]}}
const langName=(c?:string)=>{if(!c)return'Unknown';try{return new Intl.DisplayNames(['en'],{type:'language'}).of(c)||c}catch{return c}}
const base=(r:RawList,collection:string):Movie=>({id:'tmdb-'+r.id,tmdbId:r.id,title:r.title,year:Number((r.release_date||'').slice(0,4))||0,genres:[],country:'Unknown',language:langName(r.original_language),runtime:0,synopsis:r.overview||'',cast:[],collection,poster:r.poster_path?IMG+'w342'+r.poster_path:undefined,backdrop:r.backdrop_path?IMG+'w780'+r.backdrop_path:undefined,verified:true})
export const getGenres=()=>request<{genres:{id:number;name:string}[]}>('/genre/movie/list',{language:'en-US'},TTL.genres).then(r=>r.genres)
let gm:Promise<Map<number,string>>|undefined
const genreMap=()=>gm??=getGenres().then(g=>new Map(g.map(x=>[x.id,x.name] as [number,string]))).catch(e=>{gm=undefined;throw e})
async function toPage(r:RawPage,collection:string):Promise<Page>{const g=await genreMap()
 const items=r.results.map(x=>({...base(x,collection),genres:(x.genre_ids||[]).map(i=>g.get(i)).filter((n):n is string=>Boolean(n))}))
 remember(items);return{items,page:r.page,totalPages:Math.min(r.total_pages,500),totalResults:r.total_results}}
export async function listMovies(kind:'popular'|'top_rated'|'now_playing',page=1,collection='Trending',signal?:AbortSignal){
 return toPage(await request<RawPage>(`/movie/${kind}`,{page,language:'en-US'},TTL.list,signal),collection)}
export async function discover(o:{page:number;genre?:string;language?:string;country?:string;year?:string},signal?:AbortSignal){
 return toPage(await request<RawPage>('/discover/movie',{page:o.page,with_genres:o.genre,with_original_language:o.language,with_origin_country:o.country,primary_release_year:o.year,sort_by:'popularity.desc',language:'en-US'},TTL.list,signal),'Explore')}
export async function searchMovies(query:string,page=1,signal?:AbortSignal):Promise<Page>{const q=query.trim().slice(0,100)
 if(!q)return{items:[],page:1,totalPages:1,totalResults:0}
 return toPage(await request<RawPage>('/search/movie',{query:q,page,language:'en-US'},TTL.list,signal),'Search')}
export async function getMovieDetails(tmdbId:number,signal?:AbortSignal):Promise<Movie>{
 const r=await request<RawDetail>(`/movie/${tmdbId}`,{language:'en-US'},TTL.detail,signal)
 const m:Movie={...base(r,'Details'),genres:r.genres.map(g=>g.name),runtime:r.runtime||0,country:r.production_countries?.[0]?.name||'Unknown',language:r.spoken_languages?.[0]?.english_name||langName(r.original_language),cast:(r.credits?.cast||[]).slice(0,8).map(c=>c.name),tagline:r.tagline||undefined}
 remember([m]);return m}
