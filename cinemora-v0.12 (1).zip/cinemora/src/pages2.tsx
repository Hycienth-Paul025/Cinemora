import {ReactNode,useEffect,useMemo,useRef,useState} from 'react'
import {Link,useParams,useSearchParams} from 'react-router-dom'
import {useApp} from './store'
import {Badge,Empty,Grid,Head,Poster,Row,Skeleton,Status} from './components'
import {search} from './lib/search'
import {SAMPLE} from './data/sample'
import {availabilityFor,getSource} from './data/sources'
import {AvailabilityInfo} from './pages3'
import {Movie} from './types'
import {Page,discover,getGenres,getMovieDetails,recall,searchMovies,tmdbConfigured} from './services/tmdb'
// Metadata-driven pages (search, explore, details). Playback sources come only from data/sources.ts.
function usePaged(fetcher:(page:number,s:AbortSignal)=>Promise<Page>,deps:unknown[]){
 const[items,setItems]=useState<Movie[]>([]),[page,setPage]=useState(0),[total,setTotal]=useState(1),[state,setState]=useState<'loading'|'ok'|'error'>('loading'),[err,setErr]=useState('')
 const attempt=useRef(1);const load=(p:number,s:AbortSignal)=>{attempt.current=p;setState('loading');fetcher(p,s).then(r=>{setItems(x=>p===1?r.items:[...x,...r.items]);setPage(r.page);setTotal(r.totalPages);setState('ok')}).catch((e:Error)=>{if(e.name!=='AbortError'){setErr(e.message);setState('error')}})}
 const ctl=useRef<AbortController|null>(null)
 useEffect(()=>{const c=new AbortController();ctl.current=c;load(1,c.signal);return()=>c.abort()},deps) // eslint-disable-line react-hooks/exhaustive-deps
 const next=()=>{ctl.current=new AbortController();load(state==='error'?attempt.current:page+1,ctl.current.signal)}
 return{items,state,err,hasMore:page>0&&page<total,next}}
function Results({p,empty}:{p:ReturnType<typeof usePaged>;empty:ReactNode}){
 if(p.state==='error'&&!p.items.length)return<div role="alert" className="mx-4 md:mx-8 p-4 rounded-xl bg-red-500/10 text-red-300 text-sm">{p.err} <button onClick={p.next} className="underline ml-2">Try again</button></div>
 if(p.state==='loading'&&!p.items.length)return<Skeleton/>
 if(!p.items.length)return<>{empty}</>
 return<><Grid items={p.items}/><div className="text-center mt-6">{p.state==='error'&&<p role="alert" className="text-red-300 mb-2">{p.err}</p>}
  {(p.hasMore||p.state==='error')&&<button disabled={p.state==='loading'} onClick={p.next} className="px-6 py-2 rounded-full border border-line">{p.state==='loading'?'Loading…':p.state==='error'?'Try again':'Load more'}</button>}</div></>}
const Pick=({l,v,o,on}:{l:string;v:string;o:[string,string][];on:(v:string)=>void})=><label className="text-sm text-zinc-400 grid gap-1">{l}<select value={v} onChange={e=>on(e.target.value)} className="bg-panel border border-line rounded-lg px-3 py-2 text-white"><option value="">All</option>{o.map(([k,n])=><option key={k} value={k}>{n}</option>)}</select></label>
const LANGS:[string,string][]=[['en','English'],['fr','French'],['es','Spanish'],['pt','Portuguese'],['de','German'],['it','Italian'],['hi','Hindi'],['ko','Korean'],['ja','Japanese'],['zh','Chinese'],['ar','Arabic'],['yo','Yoruba']]
const COUNTRIES:[string,string][]=[['US','United States'],['GB','United Kingdom'],['NG','Nigeria'],['GH','Ghana'],['ZA','South Africa'],['EG','Egypt'],['IN','India'],['KR','South Korea'],['JP','Japan'],['CN','China'],['FR','France'],['DE','Germany'],['BR','Brazil'],['MX','Mexico']]
export function ExploreLive(){
 const[genres,setGenres]=useState<{id:number;name:string}[]>([]),[f,setF]=useState({g:'',l:'',c:'',y:''})
 useEffect(()=>{getGenres().then(setGenres).catch(()=>undefined)},[])
 const year=/^\d{4}$/.test(f.y)?f.y:''
 const p=usePaged((pg,s)=>discover({page:pg,genre:f.g,language:f.l,country:f.c,year},s),[f.g,f.l,f.c,year])
 return<><Head t="Explore"/><div className="grid grid-cols-2 md:grid-cols-4 gap-3 px-4 md:px-8 my-4">
  <Pick l="Genre" v={f.g} o={genres.map(g=>[String(g.id),g.name])} on={g=>setF({...f,g})}/><Pick l="Original language" v={f.l} o={LANGS} on={l=>setF({...f,l})}/><Pick l="Country" v={f.c} o={COUNTRIES} on={c=>setF({...f,c})}/>
  <label className="text-sm text-zinc-400 grid gap-1">Release year<input inputMode="numeric" maxLength={4} placeholder="e.g. 1999" value={f.y} onChange={e=>setF({...f,y:e.target.value.replace(/\D/g,'')})} className="bg-panel border border-line rounded-lg px-3 py-2 text-white"/></label></div>
  <Results p={p} empty={<Empty t="No titles match these filters" d="Remove a filter to see more."/>}/></>}
const POP=['Horror','Animation','Nollywood','Science fiction','Classic']
export function Search(){
 const{movies,recent,addRecent,clearRecent}=useApp();const[sp,setSp]=useSearchParams();const q=sp.get('q')||'';const[v,setV]=useState(q);useEffect(()=>setV(q),[q])
 const local=useMemo(()=>q?search(tmdbConfigured?SAMPLE.filter(m=>getSource(m.id)):movies,q):[],[q,movies])
 const p=usePaged(async(pg,s)=>{if(!q)return{items:[],page:1,totalPages:1,totalResults:0};if(!tmdbConfigured)return{items:local,page:1,totalPages:1,totalResults:local.length}
  const r=await searchMovies(q,pg,s);return pg===1?{...r,items:[...local,...r.items]}:r},[q])
 const[sug,setSug]=useState<Movie[]>([])
 useEffect(()=>{const t=v.trim();if(!t||t===q){setSug([]);return}const c=new AbortController()
  const id=setTimeout(()=>{(tmdbConfigured?searchMovies(t,1,c.signal).then(r=>r.items):Promise.resolve(search(movies,t))).then(x=>setSug(x.slice(0,5))).catch(()=>undefined)},tmdbConfigured?300:0)
  return()=>{clearTimeout(id);c.abort()}},[v,q,movies])
 const go=(s:string)=>{const t=s.trim();if(t){addRecent(t);setSug([]);setSp({q:t})}}
 return<><Head t="Search"/><form onSubmit={e=>{e.preventDefault();go(v)}} className="px-4 md:px-8 relative" role="search">
  <input autoFocus value={v} onChange={e=>setV(e.target.value)} placeholder="Title, actor, genre, year, language" aria-label="Search movies" className="w-full bg-panel border border-line rounded-full px-5 py-3"/>
  {sug.length>0&&<ul className="absolute left-4 right-4 md:left-8 md:right-8 mt-1 bg-panel border border-line rounded-2xl overflow-hidden z-10">{sug.map(m=><li key={m.id}><button type="button" onClick={()=>go(m.title)} className="w-full text-left px-5 py-2 hover:bg-line">{m.title} <span className="text-zinc-500 text-sm">{m.year||''}</span></button></li>)}</ul>}</form>
  {!q?<div className="px-4 md:px-8 mt-6 grid gap-5"><div><h2 className="text-lg mb-2">Popular searches <span className="text-xs text-zinc-500">(suggested topics)</span></h2><div className="flex flex-wrap gap-2">{POP.map(x=><button key={x} onClick={()=>go(x)} className="px-4 py-1.5 rounded-full border border-line">{x}</button>)}</div></div>
   {recent.length>0&&<div><h2 className="text-lg mb-2">Recent <button onClick={clearRecent} className="text-xs text-zinc-500 underline ml-2">Clear</button></h2><div className="flex flex-wrap gap-2">{recent.map(x=><button key={x} onClick={()=>go(x)} className="px-4 py-1.5 rounded-full bg-panel">{x}</button>)}</div></div>}</div>
  :<div className="mt-6"><Results p={p} empty={<><Empty t={`No close matches for “${q}”`} d="Check the spelling or try a shorter title, an actor or a year."/><Row title="Free to watch" items={SAMPLE.filter(m=>availabilityFor(m.id)?.ok)}/></>}/></div>}</>}
export function Details(){
 const{id=''}=useParams();const{movies,watchlist,toggle,progress,settings}=useApp()
 const live=id.startsWith('tmdb-')&&tmdbConfigured;const base=movies.find(x=>x.id===id)||recall(id)
 const[full,setFull]=useState<Movie>(),[st,setSt]=useState<'loading'|'ok'|'error'>(live?'loading':'ok'),[err,setErr]=useState(''),[n,setN]=useState(0)
 useEffect(()=>{setFull(undefined);if(!live){setSt('ok');return};const c=new AbortController();setSt('loading')
  getMovieDetails(Number(id.slice(5)),c.signal).then(m=>{setFull(m);setSt('ok')}).catch((e:Error)=>{if(e.name!=='AbortError'){setErr(e.message);setSt('error')}});return()=>c.abort()},[id,live,n])
 const m=full||base
 if(!m)return st==='loading'?<Skeleton/>:st==='error'?<div role="alert" className="m-8 p-4 rounded-xl bg-red-500/10 text-red-300">{err} <button className="underline ml-2" onClick={()=>setN(n+1)}>Try again</button></div>:<Empty t="Movie not found" d="It may have been removed from the catalog." to="/"/>
 const a=availabilityFor(m.id,settings.region),saved=watchlist.includes(m.id),rel=movies.filter(x=>x.id!==m.id&&x.genres.some(g=>m.genres.includes(g))).slice(0,10)
 return<><div className="px-4 md:px-8 py-6 grid md:grid-cols-[16rem_1fr] gap-6"><Poster m={m} cls="aspect-[2/3] w-48 md:w-full rounded-2xl border border-line"/><div><h1 className="text-4xl md:text-5xl">{m.title}</h1>
  {m.tagline&&<p className="text-gold mt-1">{m.tagline}</p>}
  <p className="text-zinc-400 mt-1">{m.year||'—'}{m.runtime?` · ${m.runtime} min`:''} · {m.language} · {m.country} · {m.genres.join(', ')||'—'}</p>
  <div className="mt-2"><Badge m={m}/> <span className="text-xs text-zinc-500 ml-1">{m.verified?'Metadata: TMDB':'Sample record, not verified'}</span></div>
  <p className="mt-4 max-w-2xl text-zinc-200">{m.synopsis||'No synopsis available.'}</p>
  {m.cast.length>0&&<p className="mt-3 text-sm text-zinc-400">Cast: {m.cast.join(', ')}</p>}
  {st==='loading'&&<p className="mt-2 text-xs text-zinc-500">Loading full details…</p>}
  {st==='error'&&<p role="alert" className="mt-2 text-xs text-red-300">Couldn’t load full details: {err} <button className="underline" onClick={()=>setN(n+1)}>Try again</button></p>}
  <div className="mt-5 flex gap-3 flex-wrap">{a?.ok&&<Link to={`/watch/${m.id}`} className="px-6 py-2.5 rounded-full bg-gold text-black font-semibold">{progress[m.id]?'Resume':'Watch now'}</Link>}<button onClick={()=>toggle(m.id)} aria-pressed={saved} className="px-6 py-2.5 rounded-full border border-line">{saved?'Remove from watchlist':'Add to watchlist'}</button></div>
  <div className="mt-5 p-4 rounded-2xl bg-panel border border-line text-sm max-w-xl"><b>Availability</b><br/><AvailabilityInfo id={m.id} region={settings.region}/></div></div></div><Row title="Related" items={rel}/></>}
