import {useEffect,useRef,useState} from 'react'
import {Link,useNavigate,useParams} from 'react-router-dom'
import {useApp} from './store'
import {Empty,Head} from './components'
import {useMovies} from './lib/useMovies'
import {listSources,evaluateSource,getSource} from './data/sources'
import {useSubtitles} from './subtitles'
const territories=(t:'worldwide'|string[])=>t==='worldwide'?'worldwide':t.join(', ')
export function AvailabilityInfo({id,region}:{id:string;region?:string}){const s=getSource(id)
 if(!s)return<>No authorized source is connected for this title, so it can’t be played here. Having metadata does not mean a film can be watched.</>
 const a=evaluateSource(s,region)
 return<><b className={a.ok?'text-emerald-300':'text-amber-300'}>{a.ok?'Streaming available':a.badge}.</b> {!a.ok&&a.message}<br/>
  License: {s.license.url?<a className="underline" href={s.license.url} target="_blank" rel="noreferrer">{s.license.name}</a>:s.license.name}. Source: <a className="underline" href={s.provider.url} target="_blank" rel="noreferrer">{s.provider.name}</a>.<br/>
  Streaming: {s.streaming?'permitted':'not permitted'}. Download: {s.download?'permitted by the license (in-app download is planned for the Android app)':'not permitted'}. Territories: {territories(s.territories)}.<br/>Credit: {s.attribution}</>}
const MSG:Record<number,string>={1:'Playback was cancelled.',2:'The network dropped while loading the video. Check your connection and try again.',3:'The video file couldn’t be decoded and may be damaged.',4:'The video couldn’t be loaded. The source may have moved, been removed, or be blocked on your network.'}
export function Watch(){
 const{id=''}=useParams();const{progress,setProgress,settings,sourcesReady}=useApp();const nav=useNavigate();const m=useMovies([id])[0]
 const src=getSource(id),a=src?evaluateSource(src,settings.region):undefined
 const v=useRef<HTMLVideoElement>(null);const[err,setErr]=useState(''),[busy,setBusy]=useState(true),[rate,setRate]=useState(1),[n,setN]=useState(0)
 useEffect(()=>{if(v.current)v.current.playbackRate=rate},[rate,n])
 const subs=useSubtitles(id,v);const last=useRef<HTMLVideoElement|null>(null);const sp=useRef(setProgress);sp.current=setProgress
 useEffect(()=>()=>{const e=last.current;if(e&&e.duration&&e.currentTime>1)sp.current(id,{t:e.currentTime,d:e.duration,at:Date.now()})},[id])
 const box=useRef<HTMLDivElement>(null);const[fs,setFs]=useState(false)
 useEffect(()=>{const f=()=>setFs(box.current!==null&&document.fullscreenElement===box.current);document.addEventListener('fullscreenchange',f);return()=>document.removeEventListener('fullscreenchange',f)},[])
 // Fullscreen on our own container (not the bare <video>) so the subtitle overlay stays visible. iPhone Safari can't do this and falls back to its system player.
 const toggleFs=()=>{const el=box.current;if(document.fullscreenElement){void document.exitFullscreen();return}if(el&&el.requestFullscreen)void el.requestFullscreen().catch(()=>undefined);else(v.current as unknown as {webkitEnterFullscreen?:()=>void}|null)?.webkitEnterFullscreen?.()}
 if(!sourcesReady)return<div className="px-4 md:px-8 py-6 text-zinc-400" role="status" aria-busy="true">Checking license status…</div>
 if(!m||!src||!a)return<Empty t="This title can’t be played" d="No authorized streaming source is connected for it." to="/"/>
 if(!a.ok)return<div className="px-4 md:px-8 py-6 max-w-xl"><h1 className="text-3xl">{m.title}</h1><div role="alert" className="mt-4 p-4 rounded-2xl bg-amber-400/10 text-amber-200"><b>{a.badge}.</b> {a.message}</div><Link to={`/movie/${m.id}`} className="inline-block mt-4 underline">Back to details</Link></div>
 const save=()=>{const e=v.current;if(e&&e.duration)setProgress(m.id,{t:e.currentTime,d:e.duration,at:Date.now()})}
 const p=progress[m.id];const resume=p&&p.t>5&&p.t<p.d-5
 const fail=(code:number)=>{setErr(navigator.onLine?MSG[code]||MSG[4]:'You’re offline. Video needs an internet connection.');setBusy(false)}
 return<div className="px-4 md:px-8 py-4"><button onClick={()=>window.history.length>1?nav(-1):nav(`/movie/${id}`)} className="text-sm text-zinc-400 mb-3">Back</button><h1 className="text-3xl mb-3">{m.title}</h1>
  {err?<div role="alert" className="p-6 rounded-2xl bg-red-500/10 text-red-300"><b>Can’t play this video.</b><p className="mt-1">{err}</p><button onClick={()=>{setErr('');setBusy(true);setN(n+1)}} className="mt-3 px-5 py-2 rounded-full border border-red-400/50">Try again</button><p className="text-xs text-zinc-500 mt-3">If it keeps failing, the source may be down. Nothing else is tried automatically, because only this authorized source is allowed.</p></div>
  :<div ref={box} className={fs?'relative bg-black flex items-center justify-center h-screen':'relative'}><video key={n} ref={v} src={src.mediaUrl} controls playsInline preload="metadata" controlsList={document.fullscreenEnabled?'nofullscreen':undefined} className={`w-full bg-black ${fs?'max-h-full h-full':'max-h-[70vh] rounded-2xl'}`}
   onLoadedMetadata={e=>{last.current=e.currentTarget;if(resume)e.currentTarget.currentTime=p.t;e.currentTarget.playbackRate=rate}} onCanPlay={()=>setBusy(false)} onPlaying={()=>setBusy(false)} onWaiting={()=>setBusy(true)} onStalled={()=>setBusy(true)}
   onTimeUpdate={()=>{if(Math.floor(v.current?.currentTime||0)%5===0)save()}} onPause={save} onEnded={save} onSeeked={save} onError={e=>fail(e.currentTarget.error?.code??4)}/>
   {fs&&<button onClick={toggleFs} className="absolute top-3 right-3 z-10 px-4 py-2 rounded-full bg-black/70 text-white text-sm border border-white/30">Exit fullscreen</button>}{subs.overlay}{busy&&<div className="absolute top-3 left-3 text-xs px-3 py-1 rounded-full bg-black/70" aria-live="polite">Loading…</div>}</div>}
  <div className="mt-4 grid sm:grid-cols-2 gap-4 max-w-3xl"><label className="text-sm text-zinc-400 grid gap-1">Playback speed<select value={rate} onChange={e=>setRate(Number(e.target.value))} className="bg-panel border border-line rounded-lg px-3 py-2 text-white">{[.5,.75,1,1.25,1.5,2].map(x=><option key={x} value={x}>{x}×</option>)}</select></label>
  <div className="p-4 rounded-2xl bg-panel border border-line text-sm text-zinc-400">{resume?`Resuming from ${Math.floor(p.t/60)}:${String(Math.floor(p.t%60)).padStart(2,'0')}. `:''}Picture-in-picture is in your browser’s player menu. On iPhone, fullscreen uses the system player and subtitles are hidden there.</div></div><button onClick={toggleFs} aria-pressed={fs} className="mt-4 px-5 py-2 rounded-full border border-line text-sm">{fs?'Exit fullscreen':'Fullscreen (keeps subtitles)'}</button>{subs.panel}
  <p className="text-xs text-zinc-500 mt-3 max-w-2xl">{src.attribution} · {src.license.name} · via {src.provider.name}</p></div>}
export function SourcesPage(){const{settings}=useApp();const ms=useMovies(listSources().map(s=>s.movieId));const title=(id:string)=>ms.find(m=>m.id===id)?.title||id
 return<><Head t="Content sources"/><p className="px-4 md:px-8 text-sm text-zinc-400 max-w-2xl">Every playable title is tracked here with its provider, license, permissions and review status. Only verified records can play.</p>
 <div className="px-4 md:px-8 mt-4 grid gap-3 max-w-3xl pb-6">{listSources().map(s=>{const a=evaluateSource(s,settings.region);const m=s.movieId
  return<article key={s.id} className="p-4 rounded-2xl bg-panel border border-line text-sm"><div className="flex justify-between gap-3 flex-wrap"><b className="text-base">{title(s.movieId)}</b><span className={a.ok?'text-emerald-300':'text-amber-300'}>{a.ok?'Available':a.badge}</span></div>
   <dl className="grid grid-cols-[8rem_1fr] gap-x-3 gap-y-1 mt-2 text-zinc-300">
    <dt className="text-zinc-500">Provider</dt><dd><a className="underline" href={s.provider.url} target="_blank" rel="noreferrer">{s.provider.name}</a></dd>
    <dt className="text-zinc-500">License</dt><dd>{s.license.name} ({s.license.status})</dd>
    <dt className="text-zinc-500">Streaming</dt><dd>{s.streaming?'Permitted':'Not permitted'}</dd><dt className="text-zinc-500">Download</dt><dd>{s.download?'Permitted':'Not permitted'}</dd>
    <dt className="text-zinc-500">Territories</dt><dd>{territories(s.territories)}</dd><dt className="text-zinc-500">Expires</dt><dd>{s.expiresAt||'No expiry recorded'}</dd>
    <dt className="text-zinc-500">Verified</dt><dd>{s.verified?`Yes, ${s.verifiedAt}`:'No'}</dd>
    <dt className="text-zinc-500">Evidence</dt><dd>{s.evidence.map(u=><a key={u} className="underline block break-all" href={u} target="_blank" rel="noreferrer">{u}</a>)}</dd>
    {s.restrictions&&<><dt className="text-zinc-500">Restrictions</dt><dd>{s.restrictions}</dd></>}{s.note&&<><dt className="text-zinc-500">Note</dt><dd>{s.note}</dd></>}</dl>
   <Link to={`/movie/${m}`} className="inline-block mt-3 underline">Open title</Link></article>})}</div></>}
export function DownloadPermissions(){const{settings}=useApp();const ms=useMovies(listSources().map(s=>s.movieId));const l=listSources().filter(s=>s.download&&evaluateSource(s,settings.region).ok)
 return<div className="p-4 rounded-2xl bg-panel border border-line text-sm"><b>Titles whose license permits downloads</b>{l.length?<ul className="mt-1 text-zinc-400 list-disc pl-5">{l.map(s=><li key={s.id}><Link className="underline" to={`/movie/${s.movieId}`}>{ms.find(m=>m.id===s.movieId)?.title||s.movieId}</Link>: download is allowed; saving them offline needs the planned Android app.</li>)}</ul>:<p className="text-zinc-400 mt-1">None yet.</p>}</div>}
