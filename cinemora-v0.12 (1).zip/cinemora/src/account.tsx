import {FormEvent,useState} from 'react'
import {useApp} from './store'
import {supabase,supabaseConfigured} from './services/supabase'
const box='p-4 rounded-2xl bg-panel border border-line text-sm'
export function AccountCard(){
 const{session,sync,syncError,deleteSyncedData}=useApp();const[email,setEmail]=useState(''),[pw,setPw]=useState(''),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false)
 if(!supabase||!supabaseConfigured)return<div className={box}><b>Account</b><p className="text-zinc-400 mt-1">Accounts are optional and not set up here. Your watchlist and progress stay on this device.</p></div>
 const db=supabase
 const act=async(f:()=>Promise<string>)=>{setBusy(true);setMsg('');try{setMsg(await f())}catch(e){setMsg((e as Error).message)}finally{setBusy(false)}}
 const signIn=(e:FormEvent)=>{e.preventDefault();void act(async()=>{const{error}=await db.auth.signInWithPassword({email,password:pw});return error?error.message:''})}
 const signUp=()=>act(async()=>{const{data,error}=await db.auth.signUp({email,password:pw});if(error)return error.message;return data.session?'':'Check your email to confirm your account, then sign in.'})
 if(!session)return<form onSubmit={signIn} className={`${box} grid gap-3`}><b>Sign in to sync across devices</b>
  <input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" aria-label="Email" autoComplete="email" className="bg-ink border border-line rounded-lg px-3 py-2"/>
  <input type="password" required minLength={8} value={pw} onChange={e=>setPw(e.target.value)} placeholder="Password (8+ characters)" aria-label="Password" autoComplete="current-password" className="bg-ink border border-line rounded-lg px-3 py-2"/>
  <div className="flex gap-2"><button disabled={busy} className="px-5 py-2 rounded-full bg-gold text-black font-medium">Sign in</button><button type="button" disabled={busy||!email||pw.length<8} onClick={()=>void signUp()} className="px-5 py-2 rounded-full border border-line">Create account</button></div>
  {msg&&<p role="alert" className="text-amber-300">{msg}</p>}<p className="text-xs text-zinc-500">On sign-in, this device’s watchlist and progress are merged into your account.</p></form>
 const del=()=>{if(!confirm('Delete your synced watchlist, progress and preferences from the server? Data on this device stays.'))return;void act(async()=>{await deleteSyncedData();return'Synced data deleted.'})}
 const delAcct=()=>{if(!confirm('Permanently delete your account and all synced data?'))return;void act(async()=>{const{error}=await db.functions.invoke('delete-user');if(error)return'Account deletion isn’t available: the delete-user function isn’t deployed. '+error.message;await db.auth.signOut();return''})}
 return<div className={`${box} grid gap-3`}><b>Account</b><p className="text-zinc-400">Signed in as {session.user.email}. Sync: {sync==='synced'?'up to date':sync==='syncing'?'syncing…':'problem'}.</p>
  {sync==='error'&&<p role="alert" className="text-red-300">Sync failed: {syncError}</p>}
  <div className="flex gap-2 flex-wrap"><button disabled={busy} onClick={()=>void db.auth.signOut()} className="px-4 py-1.5 rounded-full border border-line">Sign out</button><button disabled={busy} onClick={del} className="px-4 py-1.5 rounded-full border border-line">Delete synced data</button><button disabled={busy} onClick={delAcct} className="px-4 py-1.5 rounded-full border border-red-400/50 text-red-300">Delete account</button></div>{msg&&<p role="alert" className="text-amber-300">{msg}</p>}</div>}
