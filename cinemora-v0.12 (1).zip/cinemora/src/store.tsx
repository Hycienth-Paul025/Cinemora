import {createContext,useCallback,useContext,useEffect,useRef,useState,ReactNode} from 'react'
import type {Session} from '@supabase/supabase-js'
import {Movie,Progress,Settings} from './types'
import {loadCatalog} from './services/catalog'
import {supabase} from './services/supabase'
import {SAMPLE} from './data/sample'
import {fetchOverrides,readCachedOverrides} from '../shared/revocations'
import {setSourceOverrides} from './data/sources'
import {webKV} from './services/kv'
export function useLocal<T>(k:string,init:T):[T,(v:T)=>void]{
 const [v,s]=useState<T>(()=>{try{const r=localStorage.getItem(k);return r?JSON.parse(r) as T:init}catch{return init}})
 return [v,n=>{s(n);try{localStorage.setItem(k,JSON.stringify(n))}catch{}}]}
type SyncState='off'|'syncing'|'synced'|'error'
interface Ctx{sourcesRev:number;sourcesReady:boolean;movies:Movie[];status:'loading'|'ready'|'error';error:string;live:boolean;fetchedAt?:number;refresh:(f?:boolean)=>void;
 watchlist:string[];toggle:(id:string)=>void;progress:Record<string,Progress>;setProgress:(id:string,p:Progress)=>void;
 settings:Settings;setSettings:(s:Settings)=>void;recent:string[];addRecent:(q:string)=>void;clearRecent:()=>void;
 session:Session|null;sync:SyncState;syncError:string;deleteSyncedData:()=>Promise<void>}
const C=createContext<Ctx>(null as unknown as Ctx)
export const useApp=()=>useContext(C)
const DEF:Settings={subLang:'English',subSize:20,audioLang:'Original'}
export function Provider({children}:{children:ReactNode}){
 const [movies,setMovies]=useState<Movie[]>([]),[status,setStatus]=useState<Ctx['status']>('loading'),[error,setError]=useState(''),[live,setLive]=useState(false),[fetchedAt,setAt]=useState<number>()
 const [watchlist,setW]=useLocal<string[]>('cm.watch',[]),[progress,setP]=useLocal<Record<string,Progress>>('cm.progress',{}),[recent,setR]=useLocal<string[]>('cm.recent',[])
 const [settings,setS]=useLocal<Settings>('cm.settings',DEF)
 const [session,setSession]=useState<Session|null>(null),[sync,setSync]=useState<SyncState>('off'),[syncError,setSyncError]=useState('')
 const latest=useRef({watchlist,progress,settings});latest.current={watchlist,progress,settings}
 const lastPush=useRef<Record<string,number>>({})
 const uid=session?.user.id
 const refresh=useCallback((force=false)=>{setStatus('loading');loadCatalog(force).then(r=>{setMovies(r.movies);setLive(r.live);setAt(r.fetchedAt);setError('');setStatus('ready')}).catch((e:Error)=>{setMovies(SAMPLE);setLive(false);setError(e.message);setStatus('error')})},[])
 useEffect(()=>refresh(),[refresh])
 // Remote takedown feed: last known feed applies instantly; a fresh copy replaces it. The feed can only restrict access.
 const[rev,setRev]=useState(0),[srcReady,setSrcReady]=useState(false)
 useEffect(()=>{let live=true;const url=(import.meta.env.VITE_SOURCES_STATUS_URL as string|undefined)||'./sources-status.json'
  ;(async()=>{const c=await readCachedOverrides(webKV);if(!live)return;setSourceOverrides(c.overrides);setRev(r=>r+1);if(c.exists)setSrcReady(true)
   const f=await fetchOverrides(url,webKV);if(!live)return;if(f.fresh){setSourceOverrides(f.overrides);setRev(r=>r+1)};setSrcReady(true)})()
  return()=>{live=false}},[])
 useEffect(()=>{if(!supabase)return;supabase.auth.getSession().then(({data})=>setSession(data.session))
  const{data}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));return()=>data.subscription.unsubscribe()},[])
 const fail=(m:string)=>{setSync('error');setSyncError(m)}
 // On sign-in: merge device data with the account (union watchlist, newest progress wins, account settings win), then push local-only items.
 useEffect(()=>{if(!supabase||!uid){setSync('off');return}
  const db=supabase;let dead=false;setSync('syncing')
  ;(async()=>{
   const [w,p,pr]=await Promise.all([db.from('watchlist').select('movie_id'),db.from('progress').select('movie_id,t,d,at'),db.from('preferences').select('settings').maybeSingle()])
   const err=w.error||p.error||pr.error;if(err)throw new Error(err.message)
   const L=latest.current,remoteW=(w.data||[]).map(r=>r.movie_id as string),mergedW=[...new Set([...remoteW,...L.watchlist])]
   const mergedP:Record<string,Progress>={...L.progress};const pushP:{user_id:string;movie_id:string;t:number;d:number;at:number}[]=[]
   for(const r of p.data||[]){const loc=mergedP[r.movie_id];if(!loc||Number(r.at)>loc.at)mergedP[r.movie_id]={t:r.t,d:r.d,at:Number(r.at)}}
   for(const[id,v]of Object.entries(mergedP)){const r=(p.data||[]).find(x=>x.movie_id===id);if(!r||v.at>Number(r.at))pushP.push({user_id:uid,movie_id:id,...v})}
   const addW=mergedW.filter(id=>!remoteW.includes(id)).map(movie_id=>({user_id:uid,movie_id}))
   const rs=pr.data?.settings as Partial<Settings>|undefined,mergedS={...L.settings,...(rs||{})}
   const ops=[...(addW.length?[db.from('watchlist').upsert(addW)]:[]),...(pushP.length?[db.from('progress').upsert(pushP)]:[]),...(rs?[]:[db.from('preferences').upsert({user_id:uid,settings:mergedS})])]
   for(const r of await Promise.all(ops))if(r.error)throw new Error(r.error.message)
   if(dead)return;setW(mergedW);setP(mergedP);setS(mergedS);setSync('synced');setSyncError('')
  })().catch((e:Error)=>{if(!dead)fail(e.message)});return()=>{dead=true}
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[uid])
 const run=async(p:PromiseLike<{error:{message:string}|null}>)=>{const r=await p;if(r.error)fail(r.error.message);else if(sync!=='syncing'){setSync('synced')}}
 const toggle=(id:string)=>{const add=!watchlist.includes(id);setW(add?[...watchlist,id]:watchlist.filter(x=>x!==id))
  if(supabase&&uid)void run(add?supabase.from('watchlist').upsert({user_id:uid,movie_id:id}):supabase.from('watchlist').delete().eq('user_id',uid).eq('movie_id',id))}
 const setProgress=(id:string,p:Progress)=>{const prev=progress[id];if(prev&&Math.abs(prev.t-p.t)<4)return;setP({...progress,[id]:p})
  if(supabase&&uid&&Date.now()-(lastPush.current[id]||0)>10000){lastPush.current[id]=Date.now();void run(supabase.from('progress').upsert({user_id:uid,movie_id:id,...p}))}}
 const setSettings=(s:Settings)=>{setS(s);if(supabase&&uid)void run(supabase.from('preferences').upsert({user_id:uid,settings:s}))}
 const deleteSyncedData=async()=>{if(!supabase||!uid)return;const rs=await Promise.all([supabase.from('watchlist').delete().eq('user_id',uid),supabase.from('progress').delete().eq('user_id',uid),supabase.from('preferences').delete().eq('user_id',uid)])
  const e=rs.find(r=>r.error);if(e?.error)throw new Error(e.error.message)}
 const v:Ctx={sourcesRev:rev,sourcesReady:srcReady,movies,status,error,live,fetchedAt,refresh,watchlist,toggle,progress,setProgress,settings,setSettings,recent,session,sync,syncError,deleteSyncedData,
  addRecent:q=>setR([q,...recent.filter(x=>x!==q)].slice(0,6)),clearRecent:()=>setR([])}
 return <C.Provider value={v}>{children}</C.Provider>}
