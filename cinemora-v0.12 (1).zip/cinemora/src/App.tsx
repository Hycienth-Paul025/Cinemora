import {HashRouter,Route,Routes} from 'react-router-dom'
import {Provider} from './store'
import {Attribution,BottomNav,Logo,TopNav} from './components'
import {Continue,Downloads,ExploreLocal,Home,SettingsPage,Watchlist} from './pages'
import {SourcesPage,Watch} from './pages3'
import {Details,ExploreLive,Search} from './pages2'
import {tmdbConfigured} from './services/tmdb'
export default function App(){return<Provider><HashRouter><TopNav/><div className="md:hidden px-4 pt-3"><Logo/></div><main className="pb-24 md:pb-10"><Routes>
<Route path="/" element={<Home/>}/><Route path="/explore" element={tmdbConfigured?<ExploreLive/>:<ExploreLocal/>}/><Route path="/search" element={<Search/>}/><Route path="/movie/:id" element={<Details/>}/><Route path="/watch/:id" element={<Watch/>}/>
<Route path="/watchlist" element={<Watchlist/>}/><Route path="/continue" element={<Continue/>}/><Route path="/sources" element={<SourcesPage/>}/><Route path="/downloads" element={<Downloads/>}/><Route path="/settings" element={<SettingsPage/>}/><Route path="*" element={<Home/>}/></Routes><Attribution/></main><BottomNav/></HashRouter></Provider>}
