# Audit harness (how the browser tests were run)
Not part of the app. Paths inside the scripts (`/tmp/harness`, `/home/claude/...`) are from the sandbox; adjust them.
- `build.sh` bundles the real `src/` web app with esbuild, using `router.tsx` (a small stand-in for react-router-dom) and `supabase.ts` (stub), with no Tailwind CSS. It builds a "live" bundle (mock proxy URLs) and a "sample" bundle.
- `e2e.cjs` runs 25 Playwright tests against those bundles with mocked TMDB and translation services and a generated audio file standing in for the video. `VP=mobile` uses a 390x844 touch viewport.
- `layout.cjs` measures overflow and tap targets of the single-file prototype at four widths.
- Limits: real react-router, Tailwind styling and real network services were not involved. A real browser run with `npm run dev` is still needed.
