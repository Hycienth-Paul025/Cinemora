# Unreviewed files (moved here, not deleted)
Found in the project on 2026-10-21 but not written during the documented build sessions: an alternative URL checker (`sourcecheck.ts.txt`, lowercase twin of `shared/sourceCheck.ts`) and its test (`tools.test.ts.txt`).
- The two names differ only by letter case, so they would overwrite each other when unzipped on Windows or macOS.
- The test expects a different `check-deps.cjs` interface (`--release`, other messages) and fails against the current script.
- Nothing imports them. Origin unknown. Compare with `shared/sourceCheck.ts` and delete or merge as you prefer; the `.txt` suffix keeps them out of builds and tests.
