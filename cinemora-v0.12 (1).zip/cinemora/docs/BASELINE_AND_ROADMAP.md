# CINEMORA baseline audit and phased roadmap (2026-10-21, project v0.11)
Everything below comes from inspecting the real project and from tests actually run in the build sandbox (no internet, no Android device, no iOS, no Tailwind/router packages). Status words: **TESTED** (run here), **WRITTEN** (code exists, never run), **NOT BUILT**, **BLOCKED** (needs something outside the sandbox).

## 1. What the project is
- **Web**: React 18 + TypeScript + Tailwind + Vite, hash routing, installable PWA shell (service worker, manifest, PNG/SVG icons). ~440 dense lines in `src/`.
- **Android**: Expo SDK 56 / React Native / Expo Router in `mobile/` (~440 lines). `expo-video` playback, `expo-file-system` downloads, AsyncStorage persistence.
- **Shared logic** (`shared/`, ~550 lines): types, source/licence rules, search, TMDB client, subtitles, translation, takedown feed. Used by both apps.
- **Backend**: Supabase only (`supabase/schema.sql`, 3 Edge Functions: `tmdb`, `translate`, `delete-user`, plus `_shared/guard.ts`, `quota.ts`). No custom server.
- **Tooling**: `scripts/` (env/release gate, dependency gate, source checker), `audit/` (browser test harness), `samples/` (test subtitles).
- **iOS**: no iOS build was made or tested. Only the PWA could run in iOS Safari, untested.

## 2. Baseline status
| Area | Status | Evidence |
|---|---|---|
| Shared logic: search (20/20 on sample queries), availability rules, download rules, TMDB client (pagination, caching, retry, errors), subtitles (SRT/VTT, timing), translation pipeline, takedown feed, quota logic, request guard | **TESTED** | 36 unit tests pass; strict `tsc` clean on `shared/` and function helpers |
| Web app behaviour (navigation, search, explore, details, watchlist, player, subtitles, translation, takedown) | **TESTED** with limits | 32 browser tests pass at 1280x800 and 390x844 touch, using the real `src/` code but a router stand-in, mocked TMDB/translation, generated audio for video, no Tailwind CSS |
| Web layout/responsiveness of the Tailwind UI | **BLOCKED** | Tailwind not installable here; only the old single-file prototype was measured |
| Web type-check (`tsc` on `src/`), lint, production build | **BLOCKED** | packages not installable here; all 60 source files only parse-checked |
| Android app (all screens, playback, downloads, subtitles) | **WRITTEN** | never run, never type-checked |
| Offline downloads, purge of revoked downloads | **WRITTEN** | needs a device |
| Supabase sign-in/sync, schema + RLS, Edge Functions, quota SQL | **WRITTEN** | no live Supabase; guard and quota logic unit tested |
| Live TMDB, DeepL/LibreTranslate | **BLOCKED** | credentials and network |
| Video playback of the 3 verified films | **BLOCKED** | URLs never fetched; `npm run check:sources` exists for you to run |
| Content security policy | **WRITTEN** | `public/_headers`, never exercised in a browser |
| Installable APK/AAB, signing | **NOT BUILT** | no build was possible |

## 3. Broken or risky items found in this inspection
1. Two unreviewed files (a second URL checker and a failing test) were in the project; they would also have collided by name on Windows/macOS. Moved to `audit/unreviewed/` (see its README). Nothing deleted.
2. 14 of 14 Android dependencies are `*` and there is no lockfile anywhere (`npm run release-check` correctly blocks).
3. No ESLint config, no CI workflow, no `LICENSE`, `NOTICE`, `SECURITY.md` or `PRIVACY.md`.
4. No onboarding screen (the master prompt asks for one).
5. Poster images use a single size (TMDB `w342`), no `srcset`; backdrops are fetched but not shown anywhere.
6. In live mode the Nollywood/Bollywood/Hollywood/International rows contain only sample records; regional discovery via TMDB `with_origin_country` exists on Explore but not on Home.
7. No automated component tests in the project itself; the 32 browser tests live in `audit/` with sandbox-specific paths.
8. Known gaps listed in `AUDIT.md` (no audio/quality selection, no HLS, no parental controls, Android sign-in missing, etc.).

## 4. Data inventory (from the code)
- **On the device**: watchlist, playback progress, recent searches, subtitle tracks you import, translation cache, settings (country, subtitle size), cached TMDB responses (up to 30 days for recently seen titles), downloads (Android, app-private).
- **In Supabase, only if you sign in**: email (Supabase Auth), watchlist, playback progress, preferences. `delete-user` removes the account and cascades the rows; "Delete synced data" removes rows only.
- **Sent to third parties**: TMDB (queries via your proxy; poster requests go to TMDB's image CDN directly), Internet Archive (video requests, exposing the viewer's IP), your translation provider (the subtitle lines being translated, via your proxy). Supabase logs request metadata.
- **Not collected**: no analytics, ads or trackers. A privacy policy for users is still to be written and reviewed (Phase 1).

## 5. Phased roadmap
Each phase lists acceptance criteria; a phase is done only when all are met and recorded as PASS in `AUDIT.md`.

**Phase 0 - First real build (you, on your machine).** `npm install`, `npm run build`, `npm run test:shared`, `npx tsc --noEmit`; in `mobile/`: `npm install`, `npx expo install --fix`, `npm run typecheck`, `npx expo-doctor`; commit both lockfiles.
*Accept:* build and type-checks pass or errors are sent to me and fixed; lockfiles committed; `npm run release-check` passes.

**Phase 1 - Repository hygiene and release gates.** ESLint config + `npm run lint`; GitHub Actions workflow (install, lint, tsc, unit tests, build, `npm audit`); `SECURITY.md`; draft `PRIVACY.md` from section 4; `NOTICE` (TMDB, Blender films, Expo, React etc.); `LICENSE` once you choose one.
*Accept:* CI green on a clean checkout; `npm audit` high/critical issues triaged and documented; no secrets in git history (`git log -p` scan).

**Phase 2 - Android on a real phone.** Expo Go test, then `eas build -p android --profile preview` APK.
*Accept:* APK installs; Home, Explore, Search, Details, Player (Sintel), Downloads (download, pause, resume, cancel, delete, offline play), subtitles, takedown purge each marked PASS/FAIL on a named device and Android version; back button and rotation behave.

**Phase 3 - Web verification with real styling.** Run the existing browser tests against the real Vite build; add axe accessibility checks and large-text (200%) and 320 px checks.
*Accept:* no horizontal overflow at 320/390/768/1280 px; zero serious axe violations on Home, Search, Details, Player, Settings; keyboard-only path works for search to play.

**Phase 4 - UX gaps.** Onboarding (3 short steps: what the app is, set country, how availability works); backdrops on details; responsive `srcset`; Home regional rows from TMDB discover (NG, IN, US, GB/EU) labelled as "by country of origin"; honour saved subtitle preferences or remove them.
*Accept:* each item has a test; no dead controls.

**Phase 5 - Content and playback.** Run `npm run check:sources`; watch each film; add further public-domain or licensed titles only with recorded evidence; add HLS only when a licensed HLS source exists (and a maintained player library such as hls.js).
*Accept:* every `verified:true` source passes the checker and a human viewing; evidence URLs recorded.

**Phase 6 - Backend deployment and security.** Deploy functions and schema; test RLS with two real users; verify CSP in a browser; confirm limits and quota with real calls; test account deletion end to end.
*Accept:* user A cannot read or change user B's rows; blocked origins get 403; quota exhaustion returns the expected message; deletion removes all rows.

**Phase 7 - Release candidate.** PWA install test on Android Chrome (HTTPS); signed APK/AAB; release checklist (`release-check`, `check:sources`, CI green, privacy policy published, TMDB commercial status settled).
*Accept:* artifact installed and opened on a device; all critical tests PASS; remaining blockers listed.

## 6. Decisions I need from you (everything else I will infer safely)
1. **Licence** for the code (I recommend MIT or Apache-2.0, but this is your legal choice, so I have not added a `LICENSE`).
2. **Commercial status**: will Cinemora earn money (including sponsors)? TMDB's free tier is non-commercial.
3. **Hosting**: where the website will live (I assume a free static host such as Cloudflare Pages or Netlify).
4. **Android package id**: keep `app.cinemora.mobile` or choose another (permanent after Play release).

## 7. Feature checklist (current)
- [x] Search, explore, details, watchlist, continue watching (TESTED, web, mocked services)
- [x] Availability and licence gating; takedown feed (TESTED)
- [x] Subtitle import, display, English translation with graceful failures (TESTED, web, mock provider)
- [x] Per-IP and per-user limits, daily translation quota (logic TESTED; functions/SQL WRITTEN)
- [ ] Real-device Android verification (BLOCKED)
- [ ] Offline downloads on a device (WRITTEN)
- [ ] Live TMDB/Supabase/translation calls (BLOCKED)
- [ ] Onboarding, backdrops, srcset, Home regional rows (NOT BUILT)
- [ ] Lint, CI, dependency scan, privacy policy, licence (NOT BUILT / BLOCKED)
- [ ] iOS (NOT BUILT; no claim made)
