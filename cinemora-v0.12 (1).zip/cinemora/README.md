# Cinemora v0.1 — Every Story. Every World.

> Current status, risks and the phased roadmap: [docs/BASELINE_AND_ROADMAP.md](docs/BASELINE_AND_ROADMAP.md). Test results: [AUDIT.md](AUDIT.md).
React + TypeScript + Tailwind + Vite. Run: `npm install && npm run dev` (build: `npm run build`).

## Status
| Feature | Status |
|---|---|
| Home, Explore (genre/country/language/year), Search (partial + typo tolerant, recents, suggestions), Details, Watchlist, Continue Watching, Settings, responsive nav | Working on sample data |
| Playback with resume, speed, error handling | Three verified CC BY sources. See "Free-to-watch catalog" |
| Live metadata | Needs `VITE_CATALOG_PROXY_URL` (see below) |
| PWA install and app-shell offline | Present; needs HTTPS and PNG icons (192/512) for reliable Android install prompts |
| Supabase accounts and sync | Client stub only. Not implemented |
| Subtitles (SRT/WebVTT), translation | Not implemented. Settings store preferences only |
| Private offline downloads | Needs a separate Expo Android app. Not possible in a website |

## Sources
A title is playable only if `Movie.source` exists (`src/data/sample.ts`). Add real sources only with a verified license. Keep metadata and sources in separate tables when moving to Supabase.

## Supabase sign-in and sync (v0.2)
1. Create a Supabase project; run `supabase/schema.sql` (tables + row-level security).
2. Put the project URL and **anon** key in `.env` (copy `.env.example`). Never use the service_role key in the app.
3. In Auth settings choose whether email confirmation is required; add your site URL.
4. Optional account deletion: `supabase functions deploy delete-user` (untested). Without it, "Delete synced data" still works.

Behaviour: on sign-in the device's watchlist and progress are merged with the account (union, newest progress wins, account preferences win). Later changes sync as they happen; progress syncs at most every 10 s. Signed out, everything stays local. Not built: password reset, social login, realtime cross-device updates. Untested against a live Supabase project.

## Metadata API: TMDB (v0.3)
Metadata and playback are separate. `src/services/tmdb.ts` (metadata) never supplies video; playable sources exist only in `src/data/sources.ts`, keyed by `Movie.id`. A title is playable only if an entry exists there.

### Setup
1. Create a TMDB account, request an API key, and copy the **API Read Access Token** (v4). Review TMDB's API terms (see "Terms and attribution").
2. Deploy the proxy (any host works; this one is a Supabase Edge Function):
   ```
   supabase secrets set TMDB_READ_TOKEN=<token> ALLOWED_ORIGIN=https://your-site.example
   supabase functions deploy tmdb
   ```
3. In `.env` set `VITE_CATALOG_PROXY_URL=https://<ref>.supabase.co/functions/v1/tmdb`, plus `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`. JWT verification stays on; the app sends the anon key.
4. `npm run dev`. Without these values the app falls back to labeled sample data.

### What it does
- **Search**: server-side TMDB search with pagination ("Load more") and 300 ms debounced suggestions. Typo tolerance is whatever TMDB provides; the local fuzzy search is used only in sample mode.
- **Details**: `/movie/{id}` with credits (runtime, country, language, cast, tagline).
- **Genres**: `/genre/movie/list`, cached 7 days, used for Explore filters and card labels.
- **Explore**: `/discover/movie` filtered by genre, original language, origin country and release year, paginated to TMDB's 500-page cap.
- **Home**: popular, now playing and top rated (first page each). A title in several lists keeps its first collection.
- **Proxy hardening**: read-only allowlist of paths and query keys, page clamped to 1-500, adult content excluded, origin restricted by `ALLOWED_ORIGIN`.
- **Caching**: lists 6 h, details 24 h, genres 7 days (TMDB permits up to 6 months). Recently seen movies are kept 30 days for Watchlist and Continue. Retries with backoff on 429/5xx. Settings > Refresh now clears the cache.

### Terms and attribution
- The TMDB notice is shown in the app. **TMDB also requires its logo** in an About/credits area. The logo file is NOT included; download it from TMDB's brand assets and add it beside the notice.
- TMDB's free API tier is for non-commercial use. If Cinemora is commercial (including sponsorship revenue), confirm eligibility or get a commercial agreement before launch.
- Do not treat TMDB data as playback rights.

### Requires credentials / not verified
- Every live feature above needs a TMDB token and a deployed proxy. Nothing was run against live TMDB or a deployed function; expect small fixes.
- Not built: TMDB similar/recommended titles, actor/director search, scheduled server-side catalog refresh, rate limiting beyond TMDB's own and the origin check, per-title audio/subtitle/country availability (TMDB does not provide it).

## Free-to-watch catalog and source management (v0.4)
Metadata (TMDB) and playback are separate. Each playable title needs a record in `src/data/sources.ts` with: provider, media URL and type, license (name, URL, status), evidence pages checked, streaming permission, download permission, territories, expiry, withdrawn flag, verified flag and date, attribution, restrictions.

**Availability rules** (`evaluateSource`), checked in this order: withdrawn → expired → not verified → streaming not permitted → territory not allowed. The Watch button, the player and the badges all use the same function, so a source that stops being authorized stops playing everywhere. Set `withdrawn: true` for takedowns and `expiresAt` for time-limited licenses. Territory checks use the country chosen in Settings (the browser can't reliably know it); this is a courtesy check, not geo-enforcement. Enforce real geo-restrictions server-side if a license requires it.

**Current records** (checked 2026-10-18):
| Title | Status | Basis |
|---|---|---|
| Sintel (2010) | Verified, playable | CC BY 3.0 per durian.blender.org and the Internet Archive item. File is `Sintel.mp4` in IA item `Sintel_201709`; the URL follows IA's standard download pattern and was not test-played here. |
| Big Buck Bunny (2008) | Verified, playable | CC BY 3.0 per the official peach.blender.org About page. IA file `Big Buck Bunny.mp4`; URL not test-played. |
| Tears of Steel (2012) | Verified, playable (re-check advised) | CC BY 3.0 per a Xiph mirror README and a production artist page; official mango.blender.org not reached. IA file `Tears of Steel.mp4`; URL not test-played. |

Earlier builds used a Google-hosted sample URL that was never verified; it has been removed.

**Player**: HTML5 video (MP4/WebM/OGV) with resume, speed, buffering indicator, and specific errors for network loss, decode failure, missing/blocked source and offline, plus a retry button. It never falls back to another source. HLS/DASH are not implemented (the record type allows `hls`; add hls.js when a licensed HLS source exists).

**Adding a title**: find a source whose rights holder or license page clearly permits streaming; record the evidence URLs; set territories honestly (a film public domain in the US may still be protected elsewhere, so use `['US']`); leave `verified:false` until a person has checked it. Do not add a source just because the file is online. `supabase/schema.sql` includes a `sources` table (planned; not yet read by the app).

**Not done**: more titles (finding and verifying each license is manual work), public-domain feature films, in-app downloads (Android app), automated link health checks, subtitles.

**Candidate not added**: *A Trip to the Moon* (1902; Méliès died 1938, so public domain in life+70 countries). Wikimedia Commons lists Internet Archive ID `Levoyagedanslalune`, but no file name or URL was confirmed, so no record exists. Add one only after you can see the actual file.

## Subtitles and English translation (v0.8)
**Shared code** (`shared/subtitles.ts`, `shared/translate.ts`, `shared/subtitleStore.ts`) is used by the web player and the Android app. **16 unit tests pass** (`npm run test:shared`): SRT and WebVTT parsing (BOM, CRLF, ids, cue settings, NOTE blocks, malformed cues skipped), exact timestamp round trips, active-cue lookup, and the translation pipeline (timing and ids untouched, batching, retries, partial failure, total failure, cancellation, caching, malformed provider replies, client error mapping). The screens and the server function are NOT tested.

**What users can do** (web player page and Android player): choose Off or a track, add their own `.srt`/`.vtt`/`.txt` file (stating its language, or "Not sure"), change size and delay, remove tracks, and translate a track to English. Imported and translated tracks are saved per movie on the device. Test files: `samples/test-es.srt`, `samples/test-fr.vtt` (written for testing; not film dialogue).

**Translation design**
- Only English is a target. Only the cue text changes; start/end times, order and ids are never touched. Markup such as italics is removed before sending and line breaks are joined, so translated cues lose italics and manual line breaks.
- The app calls your proxy, `supabase/functions/translate`. Provider secrets exist only as server secrets: set `TRANSLATE_PROVIDER=deepl` with `DEEPL_API_KEY`, or `TRANSLATE_PROVIDER=libretranslate` with `LIBRETRANSLATE_URL` (and optional key). Then `supabase functions deploy translate`, and set `VITE_TRANSLATE_PROXY_URL` (web) / `EXPO_PUBLIC_TRANSLATE_PROXY_URL` (Android). To add another provider, implement the small `Adapter` interface in that file.
- **The Translate button appears only when the proxy answers a language-list request**, and only for languages that provider reports. With nothing configured the UI says translation isn't set up. No language is promised: for example DeepL's list is its own, and unsupported languages (possibly Yoruba, Igbo) get a clear "not supported" message instead of a button.
- Failures: a failed batch is retried; lines that still fail stay in the original language and the track says how many; if nothing translates, the original track is left untouched and the reason is shown. Users can cancel. Finished translations are cached so the provider isn't charged twice.
- Cost and abuse: every translation uses your provider quota. The proxy caps request size, but the anon key is public; set `REQUIRE_USER=true` (needs sign-in, not built on Android yet) and use provider spending limits.
- Machine translations are labeled "machine-translated". A "report an error" flow is not built.

**Not built**: subtitle files for catalog titles (none verified yet, so none bundled), automatic language detection on the client (provider auto-detect is used when you pick "Not sure"), subtitles in native fullscreen or picture-in-picture, subtitle color/background options, saved per-title delay, speech-recognition subtitles, exporting translated files.

## Before you deploy (v0.10 checklist)
1. Server secrets: `supabase secrets set ALLOWED_ORIGIN=https://your-site.example` (required: without it only localhost can call the proxies). Optional: `RATE_LIMIT_PER_MIN`.
2. Edit `public/_headers` (replace YOUR-PROJECT) and serve those headers; check the browser console for blocked requests.
3. `npm run build` runs `scripts/check-env.cjs` first and stops if a secret-looking value is in a `VITE_*` variable.
4. Android: set a permanent `android.package` in `mobile/app.json`, then `npm run release-check` in `mobile/` must pass before `eas build`.
5. Set spending caps on the translation provider; run `npx expo install --fix` and commit lockfiles.

## Takedowns, quotas and release gates (v0.11)
**Remote takedown.** Host `sources-status.json` (a template is in `public/`) next to the site. To pull a title, add it and redeploy:
`{"version":1,"updated":"2026-11-01","sources":{"src-sintel":{"withdrawn":true}}}`. Allowed fields: `withdrawn`, `expiresAt` (can only shorten), `verified:false`, `streaming:false`, `download:false`. Anything else, and anything that would grant access, is ignored, so a wrong or tampered file cannot make a title playable. Web checks the feed on every load (`VITE_SOURCES_STATUS_URL`, default `./sources-status.json`). Android checks at start and whenever the app returns to the foreground (`EXPO_PUBLIC_SOURCES_STATUS_URL`, your deployed https URL), applies the last known feed instantly (so it works offline once seen), and **deletes downloaded copies of revoked sources**, then tells the user on the Downloads screen. Limits: a phone that never comes online never learns of a takedown; on the very first run with the feed unreachable, built-in records apply; the feed is only as trustworthy as the host that serves it.

**Per-user limits.** The functions now limit per signed-in user across all their IPs (`USER_RATE_LIMIT_PER_MIN`: 90 TMDB, 20 translation, 3 account deletion) on top of per-IP limits. Keep JWT verification ON (the default) because the user id is read from the verified token. Translation also has a **daily character quota** per signed-in user (`TRANSLATE_DAILY_CHARS_PER_USER`, default 60,000) and for the whole service (`TRANSLATE_DAILY_CHARS_GLOBAL`, default 16,000, sized for DeepL Free's ~500,000/month; raise it with your plan). Anonymous users share the global budget. Apply `supabase/schema.sql` (new table and function) or translation will refuse to run; `TRANSLATE_QUOTA=off` disables the quota. Characters are counted before translating and not refunded if the provider fails; if the quota database is down, translation is blocked rather than unmetered.

**Checks you run (they need your machine's internet and installs):**
- `npm run check:sources`: requests each verified video URL and fails unless it serves real media. Run it before every release and on a schedule, then watch each film once. A passing check does not prove it is the right film.
- `cd mobile && npm install && npx expo install --fix`, commit `package.json` and the lockfile. `npm run release-check` in `mobile/` fails while any dependency is `*` or the lockfile is missing; the web build only warns.
- Android package id is now `app.cinemora.mobile` (my proposal, not verified as free on Google Play). Change it in `mobile/app.json` before your first Play upload if you want something else; it cannot change afterwards.
