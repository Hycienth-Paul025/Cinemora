// Subtitle translation proxy (Supabase Edge Function). UNTESTED against live providers; the app-side logic is unit tested.
// Provider secrets live ONLY here as function secrets. English is the only target.
//   TRANSLATE_PROVIDER = deepl | libretranslate        (unset = translation reports "not configured")
//   DEEPL_API_KEY (a key ending in ":fx" uses DeepL's free endpoint)
//   LIBRETRANSLATE_URL (e.g. https://your-host) and optional LIBRETRANSLATE_API_KEY
//   ALLOWED_ORIGIN (your site origin), REQUIRE_USER=true to demand a signed-in user's JWT instead of the anon key
// To add a provider, implement `Adapter` below and register it in ADAPTERS.
import {makeGuard,rejection,userFromAuth} from '../_shared/guard.ts'
import {consumeQuota} from '../_shared/quota.ts'
// Origin check + per-IP rate limit (best effort). Set ALLOWED_ORIGIN to your site's origin; native apps send no Origin and are allowed.
const guard=makeGuard({allowedOrigin:Deno.env.get('ALLOWED_ORIGIN'),limit:Number(Deno.env.get('RATE_LIMIT_PER_MIN')??30),userLimit:Number(Deno.env.get('USER_RATE_LIMIT_PER_MIN')??20),windowMs:60_000})
class PErr extends Error{code:string;status:number;constructor(code:string,message:string,status:number){super(message);this.code=code;this.status=status}}
interface Adapter{languages():Promise<string[]>;translate(texts:string[],source?:string):Promise<string[]>}
const fromStatus=(s:number)=>s===429?new PErr('rate_limited','The translation service is busy. Try again shortly.',429)
 :s===456||s===402?new PErr('quota','The translation quota has been used up.',402)
 :s===400?new PErr('unsupported_language','The translation service doesn’t support this language.',422)
 :s===401||s===403?new PErr('not_configured','The translation provider rejected the server’s credentials.',503)
 :new PErr('provider_error',`The translation provider returned an error (${s}).`,502)
function deepl():Adapter{const key=Deno.env.get('DEEPL_API_KEY');if(!key)throw new PErr('not_configured','No DeepL key is configured on the server.',503)
 const base=key.endsWith(':fx')?'https://api-free.deepl.com':'https://api.deepl.com',h={Authorization:`DeepL-Auth-Key ${key}`,'Content-Type':'application/json'}
 return{async languages(){const r=await fetch(`${base}/v2/languages?type=source`,{headers:h});if(!r.ok)throw fromStatus(r.status);return((await r.json()) as {language:string}[]).map(l=>l.language.toLowerCase().split('-')[0])},
  async translate(texts,source){const r=await fetch(`${base}/v2/translate`,{method:'POST',headers:h,body:JSON.stringify({text:texts,target_lang:'EN-US',...(source?{source_lang:source.toUpperCase()}:{})})});if(!r.ok)throw fromStatus(r.status)
   return((await r.json()) as {translations:{text:string}[]}).translations.map(t=>t.text)}}}
function libre():Adapter{const url=Deno.env.get('LIBRETRANSLATE_URL')?.replace(/\/$/,'');if(!url)throw new PErr('not_configured','No LibreTranslate URL is configured on the server.',503)
 const apiKey=Deno.env.get('LIBRETRANSLATE_API_KEY'),h={'Content-Type':'application/json'}
 return{async languages(){const r=await fetch(`${url}/languages`,{headers:h});if(!r.ok)throw fromStatus(r.status);return((await r.json()) as {code:string;targets:string[]}[]).filter(l=>l.targets.includes('en')).map(l=>l.code.toLowerCase())},
  async translate(texts,source){const r=await fetch(`${url}/translate`,{method:'POST',headers:h,body:JSON.stringify({q:texts,source:source||'auto',target:'en',format:'text',...(apiKey?{api_key:apiKey}:{})})});if(!r.ok)throw fromStatus(r.status)
   const j=await r.json() as {translatedText:string|string[]};return Array.isArray(j.translatedText)?j.translatedText:[j.translatedText]}}}
const ADAPTERS:Record<string,()=>Adapter>={deepl,libretranslate:libre}
Deno.serve(async req=>{
 const g=guard.check(req);if(!g.ok)return rejection(g)
 const json=(b:unknown,s=200)=>new Response(JSON.stringify(b),{status:s,headers:{...g.headers,'Content-Type':'application/json'}})
 if(req.method==='OPTIONS')return new Response(null,{headers:g.headers})
 const fail=(e:unknown)=>e instanceof PErr?json({error:{code:e.code,message:e.message}},e.status):json({error:{code:'provider_error',message:'The translation service had a problem.'}},502)
 try{
  if(Deno.env.get('REQUIRE_USER')==='true'){const{createClient}=await import('https://esm.sh/@supabase/supabase-js@2')
   const c=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:req.headers.get('Authorization')??''}}})
   const{data:{user}}=await c.auth.getUser();if(!user)return json({error:{code:'not_configured',message:'Sign in to use translation.'}},401)}
  const make=ADAPTERS[Deno.env.get('TRANSLATE_PROVIDER')??''];if(!make)throw new PErr('not_configured','No translation provider is configured on the server.',503)
  const ad=make(),url=new URL(req.url)
  if(req.method==='GET'&&url.searchParams.get('action')==='languages')return json({sources:await ad.languages()})
  if(req.method!=='POST')return json({error:{code:'provider_error',message:'Method not allowed.'}},405)
  const b=await req.json().catch(()=>null) as {texts?:unknown;source?:unknown;target?:unknown}|null
  const texts=b?.texts,source=b?.source
  if(!Array.isArray(texts)||texts.length<1||texts.length>50||texts.some(t=>typeof t!=='string'||t.length>1000)||(texts as string[]).reduce((n,t)=>n+t.length,0)>6000)return json({error:{code:'provider_error',message:'Invalid request: send 1-50 strings, at most 1000 characters each.'}},400)
  if(b?.target!=='en')return json({error:{code:'unsupported_language',message:'Only translation into English is supported.'}},422)
  if(source!==undefined&&(typeof source!=='string'||!/^[a-z]{2,3}$/.test(source)))return json({error:{code:'unsupported_language',message:'Invalid source language.'}},422)
  if(Deno.env.get('TRANSLATE_QUOTA')!=='off'){   // daily character budget per signed-in user and for the whole service (needs supabase/schema.sql); TRANSLATE_QUOTA=off disables
   const{createClient}=await import('https://esm.sh/@supabase/supabase-js@2'),surl=Deno.env.get('SUPABASE_URL')!,admin=createClient(surl,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
   const auth=req.headers.get('Authorization');let uid:string|null=null
   if(userFromAuth(auth)){const{data:{user}}=await createClient(surl,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:auth!}}}).auth.getUser();uid=user?.id??null}   // verified with Supabase Auth, not just decoded
   const q=await consumeQuota((fn,args)=>admin.rpc(fn,args),uid,(texts as string[]).reduce((n,t)=>n+t.length,0),{perUserDaily:Number(Deno.env.get('TRANSLATE_DAILY_CHARS_PER_USER')??60000),globalDaily:Number(Deno.env.get('TRANSLATE_DAILY_CHARS_GLOBAL')??16000)})
   if(!q.ok)return json({error:{code:q.code,message:q.message}},q.code==='quota'?402:503)}
  return json({translations:await ad.translate(texts as string[],source as string|undefined),provider:Deno.env.get('TRANSLATE_PROVIDER')})
 }catch(e){return fail(e)}})
