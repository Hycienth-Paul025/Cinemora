// Deploy: supabase functions deploy delete-user   (UNTESTED). Deleting the auth user cascades to all rows above.
import {createClient} from 'https://esm.sh/@supabase/supabase-js@2'
import {makeGuard,rejection} from '../_shared/guard.ts'
// Origin check + per-IP rate limit (best effort). Set ALLOWED_ORIGIN to your site's origin; native apps send no Origin and are allowed.
const guard=makeGuard({allowedOrigin:Deno.env.get('ALLOWED_ORIGIN'),limit:Number(Deno.env.get('RATE_LIMIT_PER_MIN')??5),userLimit:Number(Deno.env.get('USER_RATE_LIMIT_PER_MIN')??3),windowMs:60_000})
Deno.serve(async req=>{
  const g=guard.check(req);if(!g.ok)return rejection(g)
  const cors=g.headers
  if(req.method==='OPTIONS')return new Response(null,{headers:cors})
  const url=Deno.env.get('SUPABASE_URL')!
  const asUser=createClient(url,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:req.headers.get('Authorization')??''}}})
  const{data:{user}}=await asUser.auth.getUser()
  if(!user)return new Response('Unauthorized',{status:401,headers:cors})
  const admin=createClient(url,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const{error}=await admin.auth.admin.deleteUser(user.id)
  return new Response(error?error.message:'ok',{status:error?500:200,headers:cors})})
