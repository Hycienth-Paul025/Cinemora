// Server-side TMDB proxy (Supabase Edge Function). Holds the secret token; the browser never sees it. UNTESTED against live TMDB.
// Secrets: TMDB_READ_TOKEN (v4 "API Read Access Token"), ALLOWED_ORIGIN (your site origin; browsers on other sites are refused), RATE_LIMIT_PER_MIN (default 120 per IP, best effort).
import {makeGuard,rejection} from '../_shared/guard.ts'
// Origin check + per-IP rate limit (best effort). Set ALLOWED_ORIGIN to your site's origin; native apps send no Origin and are allowed.
const guard=makeGuard({allowedOrigin:Deno.env.get('ALLOWED_ORIGIN'),limit:Number(Deno.env.get('RATE_LIMIT_PER_MIN')??120),userLimit:Number(Deno.env.get('USER_RATE_LIMIT_PER_MIN')??90),windowMs:60_000})
const TMDB='https://api.themoviedb.org/3'
// Allowlist: only these read-only paths and query keys are forwarded.
const ROUTES:{re:RegExp;allow:string[];force?:Record<string,string>;ttl:number}[]=[
 {re:/^\/search\/movie$/,allow:['query','page','year','language'],force:{include_adult:'false'},ttl:3600},
 {re:/^\/discover\/movie$/,allow:['page','with_genres','with_original_language','with_origin_country','primary_release_year','sort_by','language'],force:{include_adult:'false'},ttl:3600},
 {re:/^\/movie\/(popular|top_rated|now_playing)$/,allow:['page','language'],ttl:3600},
 {re:/^\/movie\/\d{1,9}$/,allow:['language'],force:{append_to_response:'credits'},ttl:86400},
 {re:/^\/genre\/movie\/list$/,allow:['language'],ttl:604800}]
Deno.serve(async req=>{
 const g=guard.check(req);if(!g.ok)return rejection(g)
 const json=(b:unknown,s=200)=>new Response(JSON.stringify(b),{status:s,headers:{...g.headers,'Content-Type':'application/json'}})
 if(req.method==='OPTIONS')return new Response(null,{headers:g.headers})
 if(req.method!=='GET')return json({error:'Method not allowed'},405)
 const u=new URL(req.url),path=u.pathname.replace(/^.*\/tmdb(?=\/)/,'')
 const route=ROUTES.find(r=>r.re.test(path));if(!route)return json({error:'Not found'},404)
 const q=new URLSearchParams()
 for(const k of route.allow){const v=u.searchParams.get(k);if(v!==null&&v.length<=200)q.set(k,v)}
 if(q.has('page'))q.set('page',String(Math.min(500,Math.max(1,Math.floor(Number(q.get('page')))||1))))
 for(const[k,v]of Object.entries(route.force??{}))q.set(k,v)
 const token=Deno.env.get('TMDB_READ_TOKEN');if(!token)return json({error:'Server not configured'},500)
 const r=await fetch(`${TMDB}${path}?${q}`,{headers:{Authorization:`Bearer ${token}`,Accept:'application/json'}})
 const h:Record<string,string>={...g.headers,'Content-Type':'application/json'}
 if(r.ok)h['Cache-Control']=`public, max-age=${route.ttl}`
 const ra=r.headers.get('retry-after');if(ra)h['Retry-After']=ra
 return new Response(r.body,{status:r.status,headers:h})})
