// Daily translation quota (characters), per signed-in user and for the whole service, kept in Postgres (see supabase/schema.sql).
// It protects your provider bill: characters are counted BEFORE translating and are not refunded if the provider fails.
export const GLOBAL_ID='00000000-0000-0000-0000-000000000000'
export interface QuotaLimits{perUserDaily:number;globalDaily:number}
export type Rpc=(fn:string,args:Record<string,unknown>)=>PromiseLike<{data:unknown;error:{message:string}|null}>
export type QuotaResult={ok:true}|{ok:false;code:'quota'|'provider_error';message:string}
export async function consumeQuota(rpc:Rpc,userId:string|null,chars:number,l:QuotaLimits):Promise<QuotaResult>{
 const take=async(id:string,limit:number)=>{const r=await rpc('consume_translation_quota',{p_user:id,p_chars:chars,p_limit:limit});return r.error?'error' as const:r.data===true}
 if(userId){const u=await take(userId,l.perUserDaily);if(u==='error')return{ok:false,code:'provider_error',message:'The quota service is unavailable.'};if(!u)return{ok:false,code:'quota',message:'You have reached today’s translation limit. Try again tomorrow.'}}
 const g=await take(GLOBAL_ID,l.globalDaily);if(g==='error')return{ok:false,code:'provider_error',message:'The quota service is unavailable.'}
 if(!g)return{ok:false,code:'quota',message:'Translation has reached its daily capacity. Try again tomorrow.'}
 return{ok:true}}
