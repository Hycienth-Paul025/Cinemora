// Request guard shared by the Edge Functions: strict origin check + best-effort per-IP rate limit. No Deno APIs, so it can be unit tested.
// Limits: the counter lives in one function instance's memory, so it is best-effort (a new instance starts at zero). It stops casual abuse,
// not a determined attacker: add provider spending caps and, for public launch, a gateway/WAF rate limit.
export interface GuardConfig{allowedOrigin?:string;limit:number;userLimit?:number;windowMs:number;now?:()=>number}
export interface Req{method:string;headers:{get(k:string):string|null}}
export type Guard={ok:true;headers:Record<string,string>}|{ok:false;status:number;code:string;message:string;headers:Record<string,string>}
/** Signed-in user id from the Authorization JWT. Safe to use for rate-limit keys because Supabase verifies the signature before the function runs (keep JWT verification ON). Anon keys have no user. */
export function userFromAuth(h:string|null):string|null{const m=/^Bearer\s+[\w-]+\.([\w-]+)\.[\w-]*$/i.exec(h||'');if(!m)return null
 try{const p=JSON.parse(atob(m[1].replace(/-/g,'+').replace(/_/g,'/')));return p&&p.role==='authenticated'&&typeof p.sub==='string'?p.sub:null}catch{return null}}
const LOCAL=/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/
export function makeGuard(cfg:GuardConfig){
 const hits=new Map<string,{n:number;reset:number}>(),now=cfg.now??Date.now
 return{check(req:Req):Guard{
  const origin=req.headers.get('origin'),headers:Record<string,string>={'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info',Vary:'Origin'}
  // Browsers always send Origin; native apps send none. A browser on any other site is refused. With no ALLOWED_ORIGIN, only localhost (development) is accepted.
  if(origin){if(origin===cfg.allowedOrigin||(!cfg.allowedOrigin&&LOCAL.test(origin)))headers['Access-Control-Allow-Origin']=origin
   else return{ok:false,status:403,code:'forbidden_origin',message:'This site is not allowed to use the service.',headers}}
  if(req.method==='OPTIONS')return{ok:true,headers}   // preflight is free
  const ip=(req.headers.get('cf-connecting-ip')||req.headers.get('x-forwarded-for')||'unknown').split(',')[0].trim(),t=now()
  if(hits.size>5000)for(const[k,v]of hits)if(t>=v.reset)hits.delete(k)
  const over=(key:string,limit:number)=>{let h=hits.get(key);if(!h||t>=h.reset){h={n:0,reset:t+cfg.windowMs};hits.set(key,h)};return++h.n>limit?Math.max(1,Math.ceil((h.reset-t)/1000)):0}
  const user=userFromAuth(req.headers.get('authorization')),wait=over('ip:'+ip,cfg.limit)||(user?over('user:'+user,cfg.userLimit??cfg.limit):0)   // a signed-in user is limited across all their IPs
  if(wait)return{ok:false,status:429,code:'rate_limited',message:'Too many requests. Try again in a minute.',headers:{...headers,'Retry-After':String(wait)}}
  return{ok:true,headers}}}}
export const rejection=(g:Extract<Guard,{ok:false}>)=>new Response(JSON.stringify({error:{code:g.code,message:g.message}}),{status:g.status,headers:{...g.headers,'Content-Type':'application/json'}})
