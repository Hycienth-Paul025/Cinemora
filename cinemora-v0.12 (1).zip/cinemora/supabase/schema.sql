-- Run in the Supabase SQL editor. Every table is locked to the signed-in user by RLS.
create table public.watchlist(
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  movie_id text not null, added_at timestamptz not null default now(),
  primary key(user_id,movie_id));
create table public.progress(
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  movie_id text not null, t double precision not null, d double precision not null, at bigint not null,
  primary key(user_id,movie_id));
create table public.preferences(
  user_id uuid primary key default auth.uid() references auth.users on delete cascade,
  settings jsonb not null default '{}');
alter table public.watchlist enable row level security;
alter table public.progress enable row level security;
alter table public.preferences enable row level security;
create policy own_watchlist on public.watchlist for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy own_progress on public.progress for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy own_prefs on public.preferences for all using (user_id=auth.uid()) with check (user_id=auth.uid());

-- Source management (planned): the app currently reads src/data/sources.ts. Clients may only read verified, non-withdrawn rows; writes happen via the dashboard/service role.
create table public.sources(
  id text primary key, movie_id text not null,
  provider_name text not null, provider_url text, media_url text not null, media_type text not null check (media_type in ('mp4','webm','ogv','hls')),
  license_name text not null, license_url text, license_status text not null check (license_status in ('public-domain','cc-by','licensed-free')),
  evidence text[] not null default '{}', streaming boolean not null default false, download boolean not null default false,
  territories text[] not null default '{worldwide}', expires_at timestamptz, withdrawn boolean not null default false,
  verified boolean not null default false, verified_at date, attribution text not null, restrictions text, note text);
alter table public.sources enable row level security;
create policy read_verified_sources on public.sources for select using (verified and not withdrawn and (expires_at is null or expires_at > now()));

-- Translation quota (characters per day). Only the service role can touch it: RLS on with no policies, function not callable by clients.
create table public.translation_usage(user_id uuid not null, day date not null default current_date, chars integer not null default 0, primary key(user_id,day));
alter table public.translation_usage enable row level security;
create or replace function public.consume_translation_quota(p_user uuid, p_chars integer, p_limit integer) returns boolean
language plpgsql security definer set search_path=public as $$
declare used integer;
begin
  insert into public.translation_usage(user_id,day,chars) values(p_user,current_date,0) on conflict do nothing;
  update public.translation_usage set chars=chars+p_chars where user_id=p_user and day=current_date and chars+p_chars<=p_limit returning chars into used;
  return used is not null;
end $$;
revoke all on function public.consume_translation_quota(uuid,integer,integer) from public, anon, authenticated;
grant execute on function public.consume_translation_quota(uuid,integer,integer) to service_role;
