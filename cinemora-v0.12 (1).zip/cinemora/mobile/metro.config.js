// Lets Metro bundle the ../shared folder (business logic shared with the web app).
const {getDefaultConfig}=require('expo/metro-config');const path=require('path')
const config=getDefaultConfig(__dirname)
config.watchFolders=[...(config.watchFolders||[]),path.resolve(__dirname,'../shared')]
config.resolver.nodeModulesPaths=[path.resolve(__dirname,'node_modules')]
module.exports=config
