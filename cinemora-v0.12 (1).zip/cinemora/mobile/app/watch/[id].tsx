import {useEffect,useRef,useState} from 'react'
import {Text,View} from 'react-native'
import {useLocalSearchParams,useRouter} from 'expo-router'
import {VideoView,useVideoPlayer} from 'expo-video'
import {evaluateSource,getSource} from '../../src/shared'
import {useApp} from '../../src/store'
import {useMovies} from '../../src/hooks'
import {useSubtitles} from '../../src/subtitles'
import {removeDownload,useDownload} from '../../src/downloads'
import {Btn,Note,Screen} from '../../src/ui'
import {C} from '../../src/theme'
const RATES=[0.75,1,1.25,1.5,2]
export default function Watch(){const{id}=useLocalSearchParams<{id:string}>();const{progress,setProgress,settings,sourcesReady}=useApp();const m=useMovies([id])[0],r=useRouter()
 const src=getSource(id),a=src?evaluateSource(src,settings.region):undefined,ok=Boolean(sourcesReady&&src&&a?.ok)
 const dl=useDownload(id);const uri=useRef<string|null>(null);if(uri.current===null&&ok&&src)uri.current=dl?.state==='completed'?dl.fileUri:src.mediaUrl   // prefer the offline copy
 const player=useVideoPlayer(uri.current,p=>{p.timeUpdateEventInterval=5})
 const[err,setErr]=useState(''),[busy,setBusy]=useState(true),[rate,setRate]=useState(1)
 const subs=useSubtitles(id,player);const prog=useRef(progress[id]);prog.current=progress[id];const save=useRef(setProgress);save.current=setProgress;const resumed=useRef(false)
 useEffect(()=>{if(!ok)return
  const subs=[player.addListener('statusChange',({status,error})=>{setBusy(status==='loading')
   if(status==='error')setErr(error?.message?`The video couldn’t be loaded (${error.message}). Check your connection, or the source may have moved or been removed.`:'The video couldn’t be loaded. Check your connection, or the source may have moved or been removed.')
   if(status==='readyToPlay'&&!resumed.current){resumed.current=true;const p=prog.current;if(p&&p.t>5&&p.t<p.d-5)player.currentTime=p.t;player.play()}}),
   player.addListener('timeUpdate',({currentTime})=>{if(player.duration>0)save.current(id,{t:currentTime,d:player.duration,at:Date.now()})})]
  return()=>{try{if(player.duration>0)save.current(id,{t:player.currentTime,d:player.duration,at:Date.now()})}catch{/* player already released */}subs.forEach(x=>x.remove())}
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[player,ok])
 if(!sourcesReady)return<Note t="Checking license status…"/>
 if(!m||!src||!a)return<Note t="This title can’t be played" d="No authorized streaming source is connected for it."/>
 if(!a.ok)return<Screen><Note tone="warn" t={a.badge} d={a.message}/><View style={{margin:16}}><Btn l="Back to details" press={()=>r.back()}/>{dl&&<Btn l="Delete downloaded copy" press={()=>void removeDownload(id)}/>}</View></Screen>
 const retry=()=>{setErr('');setBusy(true);resumed.current=false;player.replace(uri.current||src.mediaUrl)}
 return<Screen><Text accessibilityRole="header" style={{color:C.text,fontSize:26,fontWeight:'800',padding:16}}>{m.title}</Text>
  {err?<><Note tone="err" t="Can’t play this video" d={err}/><View style={{margin:16}}><Btn l="Try again" press={retry}/><Text style={{color:C.mut,fontSize:12,marginTop:8}}>No other source is tried automatically, because only this authorized source is allowed.</Text></View></>
  :<View><VideoView player={player} nativeControls allowsPictureInPicture contentFit="contain" style={{width:'100%',aspectRatio:16/9,backgroundColor:'#000'}}/>{subs.overlay}{busy&&<Text style={{color:C.mut,padding:8}} accessibilityLiveRegion="polite">Loading…</Text>}</View>}
  <View style={{flexDirection:'row',flexWrap:'wrap',gap:8,padding:16}}>{RATES.map(x=><Btn key={x} l={`${x}×`} pri={rate===x} press={()=>{player.playbackRate=x;setRate(x)}}/>)}</View>
  {subs.panel}<Text style={{color:C.mut,paddingHorizontal:16}}>Fullscreen and picture-in-picture are in the player controls. Our subtitles don’t show in native fullscreen or picture-in-picture.</Text>
  <Text style={{color:C.mut,fontSize:12,padding:16}}>{src.attribution} · {src.license.name} · via {src.provider.name}{uri.current?.startsWith('file')?' · playing the downloaded copy':''}</Text></Screen>}
