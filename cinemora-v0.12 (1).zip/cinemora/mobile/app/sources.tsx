import {Text,View} from 'react-native'
import {listSources,evaluateSource} from '../src/shared'
import {useApp} from '../src/store'
import {useMovies} from '../src/hooks'
import {Screen} from '../src/ui'
import {C} from '../src/theme'
export default function Sources(){const{settings}=useApp();const ms=useMovies(listSources().map(s=>s.movieId))
 return<Screen><Text style={{color:C.mut,padding:16}}>Every playable title is tracked with its provider, license and review status. Only verified records can play.</Text>
  {listSources().map(s=>{const a=evaluateSource(s,settings.region);return<View key={s.id} style={{marginHorizontal:16,marginBottom:12,padding:14,borderRadius:16,backgroundColor:C.panel,borderColor:C.line,borderWidth:1,gap:3}}>
   <Text style={{color:C.text,fontWeight:'700',fontSize:16}}>{ms.find(m=>m.id===s.movieId)?.title||s.movieId}</Text><Text style={{color:a.ok?C.ok:C.warn}}>{a.ok?'Available':a.badge}</Text>
   <Text style={{color:C.mut}}>Provider: {s.provider.name}{'\n'}License: {s.license.name} ({s.license.status}){'\n'}Streaming: {s.streaming?'permitted':'no'} · Download: {s.download?'permitted':'no'}{'\n'}Territories: {s.territories==='worldwide'?'worldwide':s.territories.join(', ')}{'\n'}Verified: {s.verified?s.verifiedAt:'no'}{s.restrictions?`\nRestrictions: ${s.restrictions}`:''}{s.note?`\nNote: ${s.note}`:''}</Text></View>})}</Screen>}
