import {useEffect,useState} from 'react'
import {ActivityIndicator,Linking,Text,View} from 'react-native'
import {useLocalSearchParams,useRouter} from 'expo-router'
import {Movie,availabilityFor,getSource} from '../../src/shared'
import {meta} from '../../src/meta'
import {useApp} from '../../src/store'
import {Btn,Note,Poster,Row,Screen} from '../../src/ui'
import {DownloadControl} from '../../src/DownloadControl'
import {C} from '../../src/theme'
export default function Details(){const{id}=useLocalSearchParams<{id:string}>();const{movies,watchlist,toggle,progress,settings}=useApp();const r=useRouter()
 const live=id.startsWith('tmdb-')&&meta.configured,base=movies.find(x=>x.id===id)
 const[full,setFull]=useState<Movie>(),[st,setSt]=useState<'loading'|'ok'|'error'>(live?'loading':'ok'),[err,setErr]=useState(''),[n,setN]=useState(0)
 useEffect(()=>{setFull(undefined);if(!live){setSt('ok');return}const c=new AbortController();setSt('loading')
  meta.getMovieDetails(Number(id.slice(5)),c.signal).then(m=>{setFull(m);setSt('ok')}).catch((e:Error)=>{if(e.name!=='AbortError'){setErr(e.message);setSt('error')}});return()=>c.abort()},[id,live,n])
 const m=full||base
 if(!m)return st==='loading'?<ActivityIndicator style={{marginTop:60}} color={C.gold}/>:st==='error'?<View><Note tone="err" t="Couldn’t load this title" d={err}/><View style={{margin:16}}><Btn l="Try again" press={()=>setN(n+1)}/></View></View>:<Note t="Movie not found" d="It may have been removed from the catalog."/>
 const a=availabilityFor(m.id,settings.region),s=getSource(m.id),saved=watchlist.includes(m.id),rel=movies.filter(x=>x.id!==m.id&&x.genres.some(g=>m.genres.includes(g))).slice(0,10)
 return<Screen><View style={{padding:16,gap:8}}><Poster m={m} w={150}/><Text accessibilityRole="header" style={{color:C.text,fontSize:30,fontWeight:'800'}}>{m.title}</Text>
  {m.tagline?<Text style={{color:C.gold}}>{m.tagline}</Text>:null}
  <Text style={{color:C.mut}}>{m.year||'—'}{m.runtime?` · ${m.runtime} min`:''} · {m.language} · {m.country} · {m.genres.join(', ')||'—'}</Text>
  <Text style={{color:C.mut,fontSize:12}}>{m.verified?'Metadata: TMDB':'Sample record, not verified'}</Text>
  <Text style={{color:C.text,marginTop:6}}>{m.synopsis||'No synopsis available.'}</Text>
  {m.cast.length>0&&<Text style={{color:C.mut}}>Cast: {m.cast.join(', ')}</Text>}
  {st==='loading'&&<Text style={{color:C.mut,fontSize:12}}>Loading full details…</Text>}{st==='error'&&<Text style={{color:C.err,fontSize:12}}>Couldn’t load full details: {err}</Text>}
  <View style={{flexDirection:'row',gap:10,flexWrap:'wrap',marginTop:8}}>{a?.ok&&<Btn pri l={progress[m.id]?'Resume':'Watch now'} press={()=>r.push(`/watch/${m.id}`)}/>}<Btn l={saved?'Remove from watchlist':'Add to watchlist'} press={()=>toggle(m.id)}/></View><DownloadControl movieId={m.id} title={m.title}/></View>
  <View style={{marginHorizontal:16,padding:14,borderRadius:16,backgroundColor:C.panel,borderColor:C.line,borderWidth:1,gap:4}}><Text style={{color:C.text,fontWeight:'700'}}>Availability</Text>
   {s&&a?<><Text style={{color:a.ok?C.ok:C.warn}}>{a.ok?'Streaming available':`${a.badge}. ${a.message}`}</Text><Text style={{color:C.mut}}>License: {s.license.name}. Source: {s.provider.name}. Streaming: {s.streaming?'permitted':'not permitted'}. Download: {s.download?'permitted by the license (you can save it for offline use in the app)':'not permitted'}. Territories: {s.territories==='worldwide'?'worldwide':s.territories.join(', ')}.</Text><Text style={{color:C.mut}}>Credit: {s.attribution}</Text>
    {s.license.url?<Text style={{color:C.violet}} onPress={()=>Linking.openURL(s.license.url)}>View license</Text>:null}</>
   :<Text style={{color:C.mut}}>No authorized source is connected for this title, so it can’t be played. Having metadata does not mean a film can be watched.</Text>}</View>
  <Row title="Related" items={rel}/></Screen>}
