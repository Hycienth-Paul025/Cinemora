import {ActivityIndicator,Text,View} from 'react-native'
import {useRouter} from 'expo-router'
import {isPlayable} from '../../src/shared'
import {useApp} from '../../src/store'
import {useMovies} from '../../src/hooks'
import {Btn,Note,Poster,Row,Screen,H1} from '../../src/ui'
import {C} from '../../src/theme'
export default function Home(){const{movies,status,error,refresh,progress,watchlist,settings,live,hydrated}=useApp();const r=useRouter()
 const cont=useMovies(Object.keys(progress)),saved=useMovies(watchlist)
 if(status==='loading'||!hydrated)return<View style={{flex:1,backgroundColor:C.ink,justifyContent:'center'}}><ActivityIndicator color={C.gold} accessibilityLabel="Loading"/></View>
 const col=(c:string)=>movies.filter(m=>(m.collection===c||!!m.collections?.includes(c))),by=(f:(m:typeof movies[0])=>boolean)=>movies.filter(f)
 const hero=movies.find(m=>isPlayable(m.id,settings.region))||movies[0]
 return<Screen><H1 t="Cinemora"/>
  {status==='error'&&<Note tone="err" t="Couldn’t load live metadata" d={`${error}. Showing sample data.`}/>}
  {!live&&<Note t="Sample data" d="Records are labeled samples until a metadata proxy is configured."/>}
  {hero&&<View style={{margin:16,gap:10}}><Poster m={hero} w={160}/><Text style={{color:C.text,fontSize:28,fontWeight:'800'}}>{hero.title}</Text><Text numberOfLines={3} style={{color:C.mut}}>{hero.synopsis}</Text>
   <View style={{flexDirection:'row',gap:10}}>{isPlayable(hero.id,settings.region)&&<Btn pri l="Watch now" press={()=>r.push(`/watch/${hero.id}`)}/>}<Btn l="Details" press={()=>r.push(`/movie/${hero.id}`)}/></View></View>}
  <Row title="Continue watching" items={cont}/><Row title="Your watchlist" items={saved}/>
  <Row title="Free to watch" items={by(m=>isPlayable(m.id,settings.region))}/><Row title="Trending" items={col('Trending')}/><Row title="Top rated" items={col('Top rated')}/><Row title="Now in cinemas" items={col('Recently added')}/>
  {['Classic','Nollywood','Bollywood','Hollywood','International'].map(c=><Row key={c} title={c==='Classic'?'Classic cinema':c} items={col(c)}/>)}
  {['Horror','Science fiction','Action','Romance','Animation'].map(g=><Row key={g} title={g} items={by(m=>m.genres.includes(g))}/>)}
  {status==='error'&&<View style={{margin:16}}><Btn l="Try again" press={()=>refresh(true)}/></View>}</Screen>}
