import {useState} from 'react'
import {ActivityIndicator,ScrollView,Text,TextInput,View} from 'react-native'
import {SAMPLE,availabilityFor,search} from '../../src/shared'
import {meta} from '../../src/meta'
import {usePaged} from '../../src/hooks'
import {useApp} from '../../src/store'
import {Btn,Chip,Grid,H1,Note,Row} from '../../src/ui'
import {C} from '../../src/theme'
const POP=['Horror','Animation','Nollywood','Science fiction','Classic']
export default function Search(){const{movies,recent,addRecent,clearRecent}=useApp();const[v,setV]=useState(''),[q,setQ]=useState('')
 const p=usePaged(async(pg,s)=>{if(!q)return{items:[],page:1,totalPages:1,totalResults:0}
  const local=search(meta.configured?SAMPLE.filter(m=>availabilityFor(m.id)):movies,q)
  if(!meta.configured)return{items:local,page:1,totalPages:1,totalResults:local.length}
  const r=await meta.searchMovies(q,pg,s);return pg===1?{...r,items:[...local,...r.items]}:r},[q])
 const go=(t:string)=>{const x=t.trim();if(x){setV(x);setQ(x);addRecent(x)}}
 return<View style={{flex:1,backgroundColor:C.ink}}><H1 t="Search"/>
  <TextInput value={v} onChangeText={setV} onSubmitEditing={()=>go(v)} returnKeyType="search" placeholder="Title, actor, genre, year, language" placeholderTextColor={C.mut} accessibilityLabel="Search movies" style={{marginHorizontal:16,backgroundColor:C.panel,color:C.text,borderColor:C.line,borderWidth:1,borderRadius:99,paddingHorizontal:18,paddingVertical:10}}/>
  {!q?<ScrollView style={{padding:16}}><Text style={{color:C.text,fontSize:17,marginBottom:8}}>Popular searches</Text><View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}>{POP.map(x=><Chip key={x} l={x} on={false} press={()=>go(x)}/>)}</View>
    {recent.length>0&&<><Text style={{color:C.text,fontSize:17,marginVertical:8}}>Recent</Text><View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}>{recent.map(x=><Chip key={x} l={x} on={false} press={()=>go(x)}/>)}</View><Btn l="Clear recent" press={clearRecent}/></>}</ScrollView>
  :p.state==='error'&&!p.items.length?<Note tone="err" t="Search failed" d={p.err}/>
  :p.state==='loading'&&!p.items.length?<ActivityIndicator style={{marginTop:40}} color={C.gold}/>
  :!p.items.length?<ScrollView><Note t={`No close matches for “${q}”`} d="Check the spelling or try a shorter title, an actor or a year."/><Row title="Free to watch" items={SAMPLE.filter(m=>availabilityFor(m.id)?.ok)}/></ScrollView>
  :<Grid items={p.items} onEnd={()=>p.hasMore&&p.next()} footer={p.state==='loading'?<ActivityIndicator color={C.gold}/>:null}/>}</View>}
