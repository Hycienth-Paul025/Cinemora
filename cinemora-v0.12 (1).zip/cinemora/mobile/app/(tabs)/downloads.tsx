import {useEffect,useState} from 'react'
import {Alert,Text,View} from 'react-native'
import {listSources,canDownload} from '../../src/shared'
import {clearPurged,fmt,readPurged,removeAllDownloads,storageInfo,useDownloads} from '../../src/downloads'
import {DownloadControl} from '../../src/DownloadControl'
import {useApp} from '../../src/store'
import {useMovies} from '../../src/hooks'
import {Btn,H1,Note,Screen} from '../../src/ui'
import {C} from '../../src/theme'
export default function Downloads(){const[purged,setPurged]=useState<string[]>([]);const{settings}=useApp(),dls=useDownloads(),ms=useMovies(listSources().map(s=>s.movieId)),[st,setSt]=useState<{used:number;free:number;total:number}>()
 useEffect(()=>{void readPurged().then(setPurged)},[dls])
 useEffect(()=>{storageInfo().then(setSt).catch(()=>undefined)},[dls])
 const avail=listSources().filter(s=>canDownload(s,settings.region).ok&&!dls.some(d=>d.movieId===s.movieId))
 const title=(id:string)=>ms.find(m=>m.id===id)?.title||id
 return<Screen><H1 t="Downloads"/>
  {purged.length>0&&<><Note tone="warn" t="Some downloads were removed" d={`Their license changed, so these were deleted from this device: ${purged.join(', ')}.`}/><View style={{margin:16}}><Btn l="Dismiss" press={()=>{void clearPurged();setPurged([])}}/></View></>}
  <Note t="Storage" d={st?`Cinemora downloads: ${fmt(st.used)}. Device free space: ${fmt(st.free)} of ${fmt(st.total)}.`:'Reading storage…'}/>
  <Note t="How downloads work" d="Files are saved privately inside this app and are removed if you uninstall it or clear its data. Only titles whose license permits copies can be downloaded, and only DRM-free files. Downloads run while the app is open; if Android stops one, use Resume."/>
  {dls.length>0&&<Text style={{color:C.text,fontSize:20,fontWeight:'700',padding:16,paddingBottom:0}}>Your downloads</Text>}
  {dls.map(d=><View key={d.movieId}><Text style={{color:C.text,marginHorizontal:16,marginTop:14,fontWeight:'600'}}>{d.title}</Text><DownloadControl movieId={d.movieId} title={d.title}/></View>)}
  {dls.length>1&&<View style={{margin:16}}><Btn l="Delete all downloads" press={()=>Alert.alert('Delete all downloads?','All downloaded files will be removed from this device.',[{text:'Keep',style:'cancel'},{text:'Delete all',style:'destructive',onPress:()=>void removeAllDownloads()}])}/></View>}
  <Text style={{color:C.text,fontSize:20,fontWeight:'700',padding:16,paddingBottom:0}}>Available to download</Text>
  {avail.length?avail.map(s=><View key={s.id}><Text style={{color:C.text,marginHorizontal:16,marginTop:14,fontWeight:'600'}}>{title(s.movieId)}</Text><DownloadControl movieId={s.movieId} title={title(s.movieId)}/></View>):<Note t="Nothing else yet" d="Titles appear here when their license permits downloading."/>}</Screen>}
