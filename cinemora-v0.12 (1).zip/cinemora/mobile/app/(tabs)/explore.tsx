import {useEffect,useState} from 'react'
import {ActivityIndicator,ScrollView,Text,View} from 'react-native'
import {SAMPLE} from '../../src/shared'
import {meta} from '../../src/meta'
import {usePaged} from '../../src/hooks'
import {useApp} from '../../src/store'
import {Btn,Chip,Grid,H1,Note} from '../../src/ui'
import {C} from '../../src/theme'
const LANGS:[string,string][]=[['en','English'],['fr','French'],['es','Spanish'],['hi','Hindi'],['ko','Korean'],['ja','Japanese'],['zh','Chinese'],['ar','Arabic'],['yo','Yoruba'],['pt','Portuguese']]
export default function Explore(){const{movies}=useApp()
 const[genres,setGenres]=useState<{id:string;name:string}[]>([]),[g,setG]=useState(''),[l,setL]=useState('')
 useEffect(()=>{if(meta.configured)meta.getGenres().then(x=>setGenres(x.map(y=>({id:String(y.id),name:y.name})))).catch(()=>undefined);else setGenres([...new Set(SAMPLE.flatMap(m=>m.genres))].sort().map(n=>({id:n,name:n})))},[])
 const p=usePaged(async(pg,s)=>{if(meta.configured)return meta.discover({page:pg,genre:g,language:l},s)
  const items=movies.filter(m=>(!g||m.genres.includes(g))&&(!l||m.language.toLowerCase().startsWith(LANGS.find(x=>x[0]===l)?.[1].toLowerCase()||'')));return{items,page:1,totalPages:1,totalResults:items.length}},[g,l,movies])
 return<View style={{flex:1,backgroundColor:C.ink}}><H1 t="Explore"/>
  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{flexGrow:0,paddingHorizontal:16}}><Chip l="All genres" on={!g} press={()=>setG('')}/>{genres.map(x=><Chip key={x.id} l={x.name} on={g===x.id} press={()=>setG(g===x.id?'':x.id)}/>)}</ScrollView>
  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{flexGrow:0,paddingHorizontal:16,marginTop:10}}><Chip l="Any language" on={!l} press={()=>setL('')}/>{LANGS.map(([k,n])=><Chip key={k} l={n} on={l===k} press={()=>setL(l===k?'':k)}/>)}</ScrollView>
  {p.state==='error'&&!p.items.length?<View><Note tone="err" t="Couldn’t load titles" d={p.err}/></View>
  :p.state==='loading'&&!p.items.length?<ActivityIndicator style={{marginTop:40}} color={C.gold}/>
  :!p.items.length?<Note t="No titles match these filters" d="Remove a filter to see more."/>
  :<Grid items={p.items} onEnd={()=>p.hasMore&&p.next()} footer={p.state==='loading'?<ActivityIndicator color={C.gold}/>:p.state==='error'?<View style={{gap:8}}><Text style={{color:C.err}}>{p.err}</Text><Btn l="Try again" press={p.next}/></View>:null}/>}</View>}
