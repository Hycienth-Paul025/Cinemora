import {Tabs} from 'expo-router'
import {Text} from 'react-native'
import {C} from '../../src/theme'
const icon=(g:string)=>({color}:{color:string})=><Text style={{color,fontSize:18}}>{g}</Text>
export default function TabsLayout(){return<Tabs screenOptions={{headerStyle:{backgroundColor:C.ink},headerTintColor:C.text,headerShown:false,tabBarStyle:{backgroundColor:C.ink,borderTopColor:C.line},tabBarActiveTintColor:C.gold,tabBarInactiveTintColor:C.mut}}>
 <Tabs.Screen name="index" options={{title:'Home',tabBarIcon:icon('⌂')}}/><Tabs.Screen name="explore" options={{title:'Explore',tabBarIcon:icon('◎')}}/><Tabs.Screen name="search" options={{title:'Search',tabBarIcon:icon('⌕')}}/>
 <Tabs.Screen name="downloads" options={{title:'Downloads',tabBarIcon:icon('↓')}}/><Tabs.Screen name="profile" options={{title:'Profile',tabBarIcon:icon('☺')}}/></Tabs>}
