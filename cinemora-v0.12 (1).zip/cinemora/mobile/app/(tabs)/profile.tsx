import {Text,View} from 'react-native'
import {useRouter} from 'expo-router'
import {REGIONS} from '../../src/shared'
import {meta} from '../../src/meta'
import {useApp} from '../../src/store'
import {Btn,Chip,H1,Note,Screen} from '../../src/ui'
import {C} from '../../src/theme'
export default function Profile(){const{settings:s,setSettings,live,refresh,watchlist,progress}=useApp();const r=useRouter()
 return<Screen><H1 t="Profile and settings"/>
  <Note t="Your country" d="Used to check regional licensing. Saved on this device."/>
  <View style={{flexDirection:'row',flexWrap:'wrap',gap:8,padding:16}}><Chip l="Not set" on={!s.region} press={()=>setSettings({...s,region:undefined})}/>{REGIONS.map(([k,n])=><Chip key={k} l={n} on={s.region===k} press={()=>setSettings({...s,region:k})}/>)}</View>
  <Note t="Subtitle preferences" d="Saved only. Subtitle rendering and translation are not implemented yet."/>
  <View style={{flexDirection:'row',alignItems:'center',gap:12,padding:16}}><Btn l="−" press={()=>setSettings({...s,subSize:Math.max(14,s.subSize-2)})}/><Text style={{color:C.text}}>Size {s.subSize}</Text><Btn l="+" press={()=>setSettings({...s,subSize:Math.min(36,s.subSize+2)})}/></View>
  <Note t="Account" d={`Sign-in and sync are not built in the mobile app yet. ${watchlist.length} saved title(s) and ${Object.keys(progress).length} in progress live on this device.`}/>
  <Note t="Catalog" d={live?'Live metadata from TMDB (cached up to 6 hours). This product uses the TMDB API but is not endorsed or certified by TMDB.':'Sample data only. Set EXPO_PUBLIC_CATALOG_PROXY_URL to load live metadata.'}/>
  <View style={{flexDirection:'row',gap:10,margin:16,flexWrap:'wrap'}}>{meta.configured&&<Btn l="Refresh catalog" press={()=>refresh(true)}/>}<Btn l="Content sources and licenses" press={()=>r.push('/sources')}/></View></Screen>}
