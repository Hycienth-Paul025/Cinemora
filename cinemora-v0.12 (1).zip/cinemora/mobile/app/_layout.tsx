import {Stack} from 'expo-router'
import {StatusBar} from 'expo-status-bar'
import {Provider} from '../src/store'
import {C} from '../src/theme'
export default function Root(){return<Provider><StatusBar style="light"/>
 <Stack screenOptions={{headerStyle:{backgroundColor:C.ink},headerTintColor:C.text,contentStyle:{backgroundColor:C.ink}}}>
  <Stack.Screen name="(tabs)" options={{headerShown:false}}/><Stack.Screen name="movie/[id]" options={{title:''}}/><Stack.Screen name="watch/[id]" options={{title:'Now playing'}}/><Stack.Screen name="sources" options={{title:'Content sources'}}/></Stack></Provider>}
