export const C={ink:'#0d0c11',panel:'#17151e',line:'#2a2735',gold:'#d4a954',violet:'#8b6cf0',text:'#f1eadf',mut:'#a99d8e',ok:'#6ee7b7',warn:'#fcd34d',err:'#fca5a5'}
