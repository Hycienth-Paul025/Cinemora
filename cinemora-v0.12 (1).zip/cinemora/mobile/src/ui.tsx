import {ReactNode} from 'react'
import {FlatList,Image,Pressable,ScrollView,StyleSheet,Text,View,useWindowDimensions} from 'react-native'
import {useRouter} from 'expo-router'
import {useSafeAreaInsets} from 'react-native-safe-area-context'
import {Movie,availabilityFor} from './shared'
import {useApp} from './store'
import {C} from './theme'
const hue=(id:string)=>[...id].reduce((a,c)=>a+c.charCodeAt(0)*7,0)%360
export const Screen=({children}:{children:ReactNode})=><ScrollView style={{flex:1,backgroundColor:C.ink}} contentContainerStyle={{paddingBottom:32}}>{children}</ScrollView>
export function H1({t}:{t:string}){const i=useSafeAreaInsets();return<Text accessibilityRole="header" style={[s.h1,{paddingTop:i.top+16}]}>{t}</Text>}
export function Poster({m,w}:{m:Movie;w:number}){const h=w*1.5
 return m.poster?<Image source={{uri:m.poster}} style={{width:w,height:h,borderRadius:14,backgroundColor:C.panel}} accessibilityLabel={`${m.title} poster`}/>
 :<View accessibilityLabel={`${m.title} poster placeholder`} style={{width:w,height:h,borderRadius:14,backgroundColor:`hsl(${hue(m.id)},40%,25%)`,justifyContent:'flex-end',padding:8}}><Text style={{color:C.text,fontWeight:'700'}}>{m.title}</Text></View>}
export function Badge({m}:{m:Movie}){const{settings}=useApp();const a=availabilityFor(m.id,settings.region)
 return<Text style={[s.badge,{color:a?(a.ok?C.ok:C.warn):C.mut}]}>{a?a.badge:'Info only'}</Text>}
export function Card({m,w=120}:{m:Movie;w?:number}){const r=useRouter()
 return<Pressable onPress={()=>r.push(`/movie/${m.id}`)} style={{width:w}} accessibilityRole="button" accessibilityLabel={`${m.title}, ${m.year||''}`}><Poster m={m} w={w}/><Text numberOfLines={1} style={s.title}>{m.title}</Text><Text style={s.meta}>{m.year||'—'} · {m.genres[0]||'Film'}</Text><Badge m={m}/></Pressable>}
export const Row=({title,items}:{title:string;items:Movie[]})=>items.length?<View style={{marginTop:24}}><Text style={s.h2}>{title}</Text><FlatList horizontal data={items} keyExtractor={m=>m.id} renderItem={({item})=><Card m={item}/>} contentContainerStyle={{paddingHorizontal:16,gap:12}} showsHorizontalScrollIndicator={false}/></View>:null
export function Grid({items,onEnd,footer}:{items:Movie[];onEnd?:()=>void;footer?:ReactNode}){const{width}=useWindowDimensions();const cols=width>700?5:3,w=(width-32-12*(cols-1))/cols
 return<FlatList key={cols} data={items} numColumns={cols} keyExtractor={m=>m.id} renderItem={({item})=><Card m={item} w={w}/>} columnWrapperStyle={{gap:12,marginBottom:16}} contentContainerStyle={{padding:16}} onEndReachedThreshold={0.6} onEndReached={onEnd} ListFooterComponent={<>{footer}</>} style={{flex:1,backgroundColor:C.ink}}/>}
export const Note=({t,d,tone}:{t:string;d?:string;tone?:'err'|'warn'})=><View accessibilityRole={tone?'alert':undefined} style={[s.note,tone==='err'&&{backgroundColor:'#7f1d1d33'},tone==='warn'&&{backgroundColor:'#78350f33'}]}><Text style={{color:tone==='err'?C.err:tone==='warn'?C.warn:C.text,fontWeight:'600'}}>{t}</Text>{d?<Text style={{color:C.mut,marginTop:4}}>{d}</Text>:null}</View>
export const Chip=({l,on,press}:{l:string;on:boolean;press:()=>void})=><Pressable onPress={press} accessibilityRole="button" accessibilityState={{selected:on}} style={[s.chip,on&&{backgroundColor:C.text}]}><Text style={{color:on?C.ink:C.text}}>{l}</Text></Pressable>
export const Btn=({l,press,pri,off}:{l:string;press:()=>void;pri?:boolean;off?:boolean})=><Pressable disabled={off} onPress={press} accessibilityRole="button" style={[s.btn,pri&&{backgroundColor:C.gold,borderColor:C.gold},off&&{opacity:.5}]}><Text style={{color:pri?'#1b1206':C.text,fontWeight:'600'}}>{l}</Text></Pressable>
export const s=StyleSheet.create({h1:{color:C.text,fontSize:30,fontWeight:'800',padding:16,paddingBottom:8},h2:{color:C.text,fontSize:21,fontWeight:'700',paddingHorizontal:16,marginBottom:10},title:{color:C.text,marginTop:6,fontSize:13},meta:{color:C.mut,fontSize:11},badge:{fontSize:11,marginTop:2},
 note:{backgroundColor:C.panel,borderColor:C.line,borderWidth:1,borderRadius:16,padding:14,marginHorizontal:16,marginTop:12},chip:{borderColor:C.line,borderWidth:1,borderRadius:99,paddingHorizontal:14,paddingVertical:7,marginRight:8},btn:{borderColor:C.line,borderWidth:1,borderRadius:99,paddingHorizontal:22,paddingVertical:11,backgroundColor:C.panel}})
