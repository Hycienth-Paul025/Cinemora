import AsyncStorage from '@react-native-async-storage/async-storage'
import {createContext,useCallback,useContext,useEffect,useRef,useState,ReactNode} from 'react'
import {AppState} from 'react-native'
import {Movie,Overrides,Progress,Settings,loadCatalog,SAMPLE,fetchOverrides,readCachedOverrides,setSourceOverrides} from './shared'
import {meta,storage} from './meta'
import {purgeRevoked} from './downloads'
function usePersist<T>(key:string,init:T):[T,(v:T)=>void,boolean]{const[v,setV]=useState(init),[ok,setOk]=useState(false)
 useEffect(()=>{AsyncStorage.getItem(key).then(r=>{if(r)try{setV(JSON.parse(r) as T)}catch{/* corrupt: keep default */}}).catch(()=>undefined).finally(()=>setOk(true))},[key])
 return[v,n=>{setV(n);AsyncStorage.setItem(key,JSON.stringify(n)).catch(()=>undefined)},ok]}
interface Ctx{sourcesRev:number;sourcesReady:boolean;movies:Movie[];status:'loading'|'ready'|'error';error:string;live:boolean;refresh:(f?:boolean)=>void;hydrated:boolean
 watchlist:string[];toggle:(id:string)=>void;progress:Record<string,Progress>;setProgress:(id:string,p:Progress)=>void
 settings:Settings;setSettings:(s:Settings)=>void;recent:string[];addRecent:(q:string)=>void;clearRecent:()=>void}
const C=createContext<Ctx>(null as unknown as Ctx);export const useApp=()=>useContext(C)
export function Provider({children}:{children:ReactNode}){
 const[movies,setMovies]=useState<Movie[]>([]),[status,setStatus]=useState<Ctx['status']>('loading'),[error,setError]=useState(''),[live,setLive]=useState(false)
 const[watchlist,setW,h1]=usePersist<string[]>('cm.watch',[]),[progress,setP,h2]=usePersist<Record<string,Progress>>('cm.progress',{}),[recent,setR,h3]=usePersist<string[]>('cm.recent',[])
 const[settings,setSettings,h4]=usePersist<Settings>('cm.settings',{subLang:'English',subSize:20,audioLang:'Original'})
 const latest=useRef(progress);latest.current=progress
 const refresh=useCallback((force=false)=>{setStatus('loading');loadCatalog(meta,force).then(r=>{setMovies(r.movies);setLive(r.live);setError('');setStatus('ready')}).catch((e:Error)=>{setMovies(SAMPLE);setLive(false);setError(e.message);setStatus('error')})},[])
 useEffect(()=>refresh(),[refresh])
 // Remote takedown feed (can only restrict). Applied from cache at once, refreshed at start and whenever the app returns to the foreground; revoked downloads are deleted.
 const[rev,setRev]=useState(0),[srcReady,setSrcReady]=useState(false)
 useEffect(()=>{let live=true
  const apply=(o:Overrides)=>{setSourceOverrides(o);setRev(r=>r+1);void purgeRevoked()}
  const pull=async()=>{const f=await fetchOverrides(process.env.EXPO_PUBLIC_SOURCES_STATUS_URL,storage);if(!live)return;if(f.fresh)apply(f.overrides);setSrcReady(true)}
  ;(async()=>{const c=await readCachedOverrides(storage);if(!live)return;if(c.exists){apply(c.overrides);setSrcReady(true)};await pull()})()
  const sub=AppState.addEventListener('change',s=>{if(s==='active')void pull()})
  return()=>{live=false;sub.remove()}},[])
 const v:Ctx={sourcesRev:rev,sourcesReady:srcReady,movies,status,error,live,refresh,hydrated:h1&&h2&&h3&&h4,watchlist,progress,settings,setSettings,recent,
  toggle:id=>setW(watchlist.includes(id)?watchlist.filter(x=>x!==id):[...watchlist,id]),
  setProgress:(id,p)=>{const prev=latest.current[id];if(prev&&Math.abs(prev.t-p.t)<4)return;setP({...latest.current,[id]:p})},
  addRecent:q=>setR([q,...recent.filter(x=>x!==q)].slice(0,6)),clearRecent:()=>setR([])}
 return<C.Provider value={v}>{children}</C.Provider>}
