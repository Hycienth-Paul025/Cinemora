import AsyncStorage from '@react-native-async-storage/async-storage'
import {KV,createMetadata} from './shared'
export const storage:KV={get:k=>AsyncStorage.getItem(k),set:(k,v)=>AsyncStorage.setItem(k,v),remove:k=>AsyncStorage.removeItem(k),keys:async()=>[...(await AsyncStorage.getAllKeys())]}
// EXPO_PUBLIC_* values are bundled into the app: public values only.
export const meta=createMetadata({baseUrl:process.env.EXPO_PUBLIC_CATALOG_PROXY_URL,anonKey:process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY,storage})
