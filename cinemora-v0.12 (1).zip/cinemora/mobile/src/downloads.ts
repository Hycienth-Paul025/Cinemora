import AsyncStorage from '@react-native-async-storage/async-storage'
import * as FS from 'expo-file-system/legacy'
import {useEffect,useSyncExternalStore} from 'react'
import {Source,canDownload,needsPurge} from './shared'
// Offline downloads. Files live in documentDirectory (app-private internal storage: not in the gallery or file manager;
// removed on uninstall or "clear data"). Downloads run inside the app process (no background service), so Android may stop them
// when the app is closed; they can then be resumed (or restarted).
export type DlState='downloading'|'paused'|'completed'|'failed'
export interface DlRecord{movieId:string;sourceId:string;title:string;url:string;fileUri:string;state:DlState;bytes:number;total:number;resumeData?:string;error?:string;at:number}
const KEY='cm.downloads',MB=1024*1024
let recs:Record<string,DlRecord>={},snap:DlRecord[]=[],ready:Promise<void>|undefined,lastSave=0
const live=new Map<string,FS.DownloadResumable>(),gens=new Map<string,number>(),subs=new Set<()=>void>()
const emit=()=>{snap=Object.values(recs).sort((a,b)=>b.at-a.at);subs.forEach(f=>f())}
const persist=(force:boolean)=>{if(!force&&Date.now()-lastSave<2000)return;lastSave=Date.now();AsyncStorage.setItem(KEY,JSON.stringify(recs)).catch(()=>undefined)}
const set=(id:string,p:Partial<DlRecord>,force=true)=>{const r=recs[id];if(!r)return;recs={...recs,[id]:{...r,...p}};emit();persist(force)}
export const fmt=(n:number)=>n>=1024*MB?`${(n/1024/MB).toFixed(1)} GB`:`${Math.max(1,Math.round(n/MB))} MB`
export function initDownloads(){return ready??=(async()=>{
 try{const raw=await AsyncStorage.getItem(KEY),saved=raw?JSON.parse(raw) as Record<string,DlRecord>:{}
  for(const r of Object.values(saved)){const info=await FS.getInfoAsync(r.fileUri).catch(()=>null)
   if(r.state==='completed'){if(info?.exists)recs[r.movieId]=r}   // file gone (data cleared): drop the record
   else recs[r.movieId]={...r,state:r.state==='failed'?'failed':'paused',bytes:info?.exists?info.size:0}}   // interrupted: needs resume/restart
 }catch{/* start empty */}
 recs={...recs};emit();persist(true)})()}
export async function getRemoteSize(url:string):Promise<number>{try{const r=await fetch(url,{method:'HEAD'}),n=Number(r.headers.get('content-length'));return Number.isFinite(n)?n:0}catch{return 0}}
async function finish(id:string,gen:number,run:()=>Promise<FS.FileSystemDownloadResult|undefined>){
 try{const res=await run();const r=recs[id];if(!r||gens.get(id)!==gen||r.state!=='downloading')return   // paused, cancelled or superseded
  if(!res||(res.status!==200&&res.status!==206))throw new Error(`The server replied ${res?.status??'nothing'}.`)
  const info=await FS.getInfoAsync(r.fileUri)
  if(!info.exists||info.size===0||(r.total>0&&info.size!==r.total))throw new Error('The file is incomplete or damaged. Try again.')
  set(id,{state:'completed',bytes:info.size,total:info.size,resumeData:undefined,error:undefined})
 }catch(e){const r=recs[id];if(!r||gens.get(id)!==gen||r.state!=='downloading')return;set(id,{state:'failed',error:(e as Error).message||'The download failed.'})}}
function begin(id:string,resumeData?:string){const r=recs[id];if(!r)return;const gen=(gens.get(id)||0)+1;gens.set(id,gen)
 const dr=FS.createDownloadResumable(r.url,r.fileUri,{},p=>set(id,{bytes:p.totalBytesWritten,total:p.totalBytesExpectedToWrite>0?p.totalBytesExpectedToWrite:r.total},false),resumeData)
 live.set(id,dr);void finish(id,gen,()=>resumeData?dr.resumeAsync():dr.downloadAsync())}
export async function startDownload(movieId:string,title:string,s:Source,region?:string){await initDownloads()
 const ok=canDownload(s,region);if(!ok.ok)throw new Error(ok.reason)
 if(recs[movieId]&&recs[movieId].state!=='failed')return
 const dir=FS.documentDirectory;if(!dir)throw new Error('App storage is unavailable on this device.')
 const total=await getRemoteSize(s.mediaUrl),free=await FS.getFreeDiskStorageAsync(),need=total+100*MB
 if(free<need)throw new Error(`Not enough free space. About ${fmt(need)} is needed and ${fmt(free)} is free.`)
 await FS.makeDirectoryAsync(dir+'downloads/',{intermediates:true}).catch(()=>undefined)
 const fileUri=`${dir}downloads/${movieId}.${s.mediaType}`;await FS.deleteAsync(fileUri,{idempotent:true})
 recs={...recs,[movieId]:{movieId,sourceId:s.id,title,url:s.mediaUrl,fileUri,state:'downloading',bytes:0,total,at:Date.now()}};emit();persist(true);begin(movieId)}
export async function pauseDownload(id:string){const r=recs[id],dr=live.get(id);if(!r||r.state!=='downloading'||!dr)return
 set(id,{state:'paused'})   // set first so the pending download promise is ignored
 try{const st=await dr.pauseAsync();set(id,{resumeData:st.resumeData})}catch(e){set(id,{state:'failed',error:(e as Error).message||'Could not pause.'})}}
export async function resumeDownload(id:string){await initDownloads();const r=recs[id];if(!r||(r.state!=='paused'&&r.state!=='failed'))return
 if(r.state==='paused'&&r.resumeData){set(id,{state:'downloading',resumeData:undefined,error:undefined});begin(id,r.resumeData)}
 else{await FS.deleteAsync(r.fileUri,{idempotent:true}).catch(()=>undefined);set(id,{state:'downloading',bytes:0,resumeData:undefined,error:undefined});begin(id)}}   // no safe resume point: restart
/** Cancel an in-progress download or delete a finished one: stops the transfer, deletes the file, removes the record. */
export async function removeDownload(id:string){const r=recs[id];if(!r)return;gens.set(id,(gens.get(id)||0)+1)
 const dr=live.get(id);if(r.state==='downloading'&&dr)await dr.pauseAsync().catch(()=>undefined)
 live.delete(id);await FS.deleteAsync(r.fileUri,{idempotent:true}).catch(()=>undefined)
 const next={...recs};delete next[id];recs=next;emit();persist(true)}
export async function removeAllDownloads(){for(const id of Object.keys(recs))await removeDownload(id)}
export async function storageInfo(){const used=Object.values(recs).reduce((n,r)=>n+(r.state==='completed'?r.total||r.bytes:r.bytes),0)
 const[free,total]=await Promise.all([FS.getFreeDiskStorageAsync(),FS.getTotalDiskCapacityAsync()]);return{used,free,total}}
const sub=(f:()=>void)=>{subs.add(f);return()=>{subs.delete(f)}}
export function useDownloads(){useEffect(()=>{void initDownloads()},[]);return useSyncExternalStore(sub,()=>snap)}
export const useDownload=(id:string)=>useDownloads().find(r=>r.movieId===id)
const PK='cm.purged'
export const readPurged=async():Promise<string[]>=>{try{return JSON.parse(await AsyncStorage.getItem(PK)||'[]') as string[]}catch{return[]}}
export const clearPurged=()=>AsyncStorage.removeItem(PK).catch(()=>undefined)
/** Delete downloaded copies whose source is no longer authorized (takedown, expiry, un-verified, download permission removed) and remember why for the Downloads screen. */
export async function purgeRevoked():Promise<string[]>{await initDownloads();const gone:string[]=[]
 for(const r of Object.values(recs))if(needsPurge(r.sourceId)){gone.push(r.title);await removeDownload(r.movieId)}
 if(gone.length)await AsyncStorage.setItem(PK,JSON.stringify([...new Set([...(await readPurged()),...gone])])).catch(()=>undefined)
 return gone}
