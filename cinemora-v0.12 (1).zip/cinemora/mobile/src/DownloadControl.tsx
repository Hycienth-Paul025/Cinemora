import {useEffect,useState} from 'react'
import {Alert,Text,View} from 'react-native'
import {useRouter} from 'expo-router'
import {canDownload,getSource} from './shared'
import {fmt,getRemoteSize,pauseDownload,removeDownload,resumeDownload,startDownload,useDownload} from './downloads'
import {useApp} from './store'
import {Btn,Note} from './ui'
import {C} from './theme'
export function DownloadControl({movieId,title}:{movieId:string;title:string}){
 const{settings}=useApp(),r=useRouter(),s=getSource(movieId),dl=useDownload(movieId),[size,setSize]=useState(0),[err,setErr]=useState('')
 const can=s?canDownload(s,settings.region):undefined
 useEffect(()=>{if(s&&can?.ok&&!dl)getRemoteSize(s.mediaUrl).then(setSize)},[movieId,Boolean(dl)]) // eslint-disable-line react-hooks/exhaustive-deps
 if(!s)return null
 const del=()=>Alert.alert('Delete this download?','The file is removed from this device. You can download it again later.',[{text:'Keep',style:'cancel'},{text:'Delete',style:'destructive',onPress:()=>void removeDownload(movieId)}])
 if(!dl){if(!can?.ok)return<Note t="Download not available" d={can?.reason}/>
  return<View style={{marginHorizontal:16,marginTop:12,gap:8}}><Btn l="Download for offline" press={()=>{setErr('');startDownload(movieId,title,s,settings.region).catch((e:Error)=>setErr(e.message))}}/>
   <Text style={{color:C.mut,fontSize:12}}>{size?`About ${fmt(size)}. `:''}Saved privately inside this app. Uses mobile data unless you are on Wi-Fi.</Text>{err?<Text style={{color:C.err}} accessibilityRole="alert">{err}</Text>:null}</View>}
 const pct=dl.total>0?Math.min(100,Math.round(dl.bytes/dl.total*100)):0
 return<View style={{marginHorizontal:16,marginTop:12,padding:14,borderRadius:16,backgroundColor:C.panel,borderColor:C.line,borderWidth:1,gap:8}}>
  {dl.state!=='completed'&&<><View accessibilityRole="progressbar" accessibilityValue={{min:0,max:100,now:pct}} style={{height:6,backgroundColor:C.line,borderRadius:3}}><View style={{width:`${pct}%`,height:6,backgroundColor:C.ok,borderRadius:3}}/></View>
   <Text style={{color:C.mut,fontSize:12}}>{dl.state==='downloading'?'Downloading':dl.state==='paused'?'Paused':'Failed'} · {fmt(dl.bytes)}{dl.total?` of ${fmt(dl.total)}`:''}{dl.total?` (${pct}%)`:''}</Text></>}
  {dl.state==='completed'&&<Text style={{color:C.ok}}>Downloaded · {fmt(dl.total||dl.bytes)}</Text>}
  {dl.error?<Text style={{color:C.err}} accessibilityRole="alert">{dl.error}</Text>:null}
  {can&&!can.ok&&<Text style={{color:C.warn}}>{can.reason}</Text>}
  <View style={{flexDirection:'row',gap:8,flexWrap:'wrap'}}>
   {dl.state==='downloading'&&<Btn l="Pause" press={()=>void pauseDownload(movieId)}/>}
   {(dl.state==='paused'||dl.state==='failed')&&<Btn pri l={dl.state==='failed'?'Retry':'Resume'} press={()=>void resumeDownload(movieId)}/>}
   {dl.state==='completed'&&<Btn pri l="Play offline" press={()=>r.push(`/watch/${movieId}`)}/>}
   <Btn l={dl.state==='completed'?'Delete':'Cancel'} press={dl.state==='completed'?del:()=>void removeDownload(movieId)}/></View></View>}
