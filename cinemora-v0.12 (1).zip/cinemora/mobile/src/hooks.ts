import {useEffect,useRef,useState} from 'react'
import {Movie,Page} from './shared'
import {meta} from './meta'
import {useApp} from './store'
/** Resolve ids from the loaded catalog, the recently-seen cache, or the metadata API. */
export function useMovies(ids:string[]):Movie[]{const{movies}=useApp();const[extra,setExtra]=useState<Record<string,Movie>>({})
 useEffect(()=>{let dead=false
  ;(async()=>{for(const id of ids){if(!meta.configured||!id.startsWith('tmdb-')||movies.some(m=>m.id===id)||extra[id])continue
   const m=(await meta.recall(id))||await meta.getMovieDetails(Number(id.slice(5))).catch(()=>undefined);if(m&&!dead)setExtra(x=>({...x,[id]:m}))}})()
  return()=>{dead=true}
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[ids.join(','),movies])
 return ids.map(id=>movies.find(m=>m.id===id)||extra[id]).filter((m):m is Movie=>Boolean(m))}
export function usePaged(fetcher:(page:number,s:AbortSignal)=>Promise<Page>,deps:unknown[]){
 const[items,setItems]=useState<Movie[]>([]),[page,setPage]=useState(0),[total,setTotal]=useState(1),[state,setState]=useState<'loading'|'ok'|'error'>('loading'),[err,setErr]=useState('')
 const attempt=useRef(1);const load=(p:number,s:AbortSignal)=>{attempt.current=p;setState('loading');fetcher(p,s).then(r=>{setItems(x=>p===1?r.items:[...x,...r.items]);setPage(r.page);setTotal(r.totalPages);setState('ok')}).catch((e:Error)=>{if(e.name!=='AbortError'){setErr(e.message);setState('error')}})}
 const ctl=useRef<AbortController|null>(null)
 useEffect(()=>{const c=new AbortController();ctl.current=c;load(1,c.signal);return()=>c.abort()},deps) // eslint-disable-line react-hooks/exhaustive-deps
 return{items,state,err,hasMore:page>0&&page<total,next:()=>{if(state==='loading')return;ctl.current=new AbortController();load(state==='error'?attempt.current:page+1,ctl.current.signal)}}}
