import {ReactNode,useEffect,useRef,useState} from 'react'
import {ScrollView,Text,View} from 'react-native'
import * as DocumentPicker from 'expo-document-picker'
import * as FS from 'expo-file-system/legacy'
import type {VideoPlayer} from 'expo-video'
import {SUB_LANGS,SubtitleError,SubtitleTrack,TranslationError,cueAt,createTranslationClient,friendlyError,langName,loadTracks,makeImportedTrack,primaryLang,saveTracks,stripTags,translateCues,translatedTrack} from './shared'
import {storage} from './meta'
import {useApp} from './store'
import {Btn,Chip} from './ui'
import {C} from './theme'
const translator=createTranslationClient({baseUrl:process.env.EXPO_PUBLIC_TRANSLATE_PROXY_URL,anonKey:process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY})
/** Subtitle selection, import and English translation for the Android player. Overlay sits inside the video box. */
export function useSubtitles(movieId:string,player:VideoPlayer):{overlay:ReactNode;panel:ReactNode}{
 const{settings,setSettings}=useApp()
 const[tracks,setTracks]=useState<SubtitleTrack[]>([]),[sel,setSel]=useState('off'),[delay,setDelay]=useState(0),[text,setText]=useState(''),[lang,setLang]=useState('und')
 const[note,setNote]=useState<{err:boolean;t:string}|null>(null),[prog,setProg]=useState<{done:number;total:number}|null>(null)
 const[svc,setSvc]=useState<'off'|'checking'|'ready'|'down'>(translator.configured?'checking':'off'),[langs,setLangs]=useState<string[]>([]),ctl=useRef<AbortController|null>(null)
 useEffect(()=>{let live=true;loadTracks(storage,movieId).then(t=>{if(live)setTracks(t)});return()=>{live=false}},[movieId])
 useEffect(()=>{if(!translator.configured)return;translator.languages().then(l=>{setLangs(l);setSvc('ready')}).catch(()=>setSvc('down'))},[])
 const cur=tracks.find(t=>t.id===sel)
 useEffect(()=>{if(!cur){setText('');return}const id=setInterval(()=>{try{const c=cueAt(cur.cues,player.currentTime*1000-delay*1000);setText(c?stripTags(c.text):'')}catch{/* player released */}},250);return()=>clearInterval(id)},[cur,delay,player])
 const persist=async(next:SubtitleTrack[])=>{setTracks(next);try{await saveTracks(storage,movieId,next)}catch{setNote({err:true,t:'These subtitles work now but couldn’t be saved on this device.'})}}
 const pick=async()=>{setNote(null)
  try{const res=await DocumentPicker.getDocumentAsync({type:'*/*',copyToCacheDirectory:true});if(res.canceled||!res.assets?.[0])return;const f=res.assets[0]
   if(tracks.length>=6)throw new SubtitleError('Remove a subtitle track first (up to 6 per movie).');if((f.size??0)>2*1024*1024)throw new SubtitleError('That file is over 2 MB, so it probably isn’t a subtitle file.')
   const raw=await FS.readAsStringAsync(f.uri);const bad=(raw.match(/\uFFFD/g)||[]).length
   const t=makeImportedTrack(f.name,raw,lang);await persist([...tracks,t]);setSel(t.id)
   setNote({err:bad>5,t:bad>5?`Loaded ${t.cues.length} lines, but some characters look garbled. The file may not be UTF-8; re-save it as UTF-8 and add it again.`:`Loaded ${t.cues.length} lines (${t.format.toUpperCase()}).`})}
  catch(e){setNote({err:true,t:e instanceof SubtitleError?e.message:'Couldn’t read that file.'})}}
 const reason=(t:SubtitleTrack):string|null=>{if(t.origin==='translated'||primaryLang(t.lang)==='en')return null
  if(svc==='off')return'Translation isn’t set up in this build.';if(svc==='checking')return'Checking the translation service…';if(svc==='down')return'The translation service couldn’t be reached, so translation is unavailable right now.'
  if(t.lang!=='und'&&!langs.includes(primaryLang(t.lang)))return`The configured translation service doesn’t support ${langName(t.lang)}.`;return''}
 const translate=async(t:SubtitleTrack)=>{const have=tracks.find(x=>x.from===t.id);if(have){setSel(have.id);return}
  const c=new AbortController();ctl.current=c;setNote(null);setProg({done:0,total:t.cues.length})
  try{const r=await translateCues(t.cues,translator,{source:t.lang==='und'?undefined:primaryLang(t.lang),signal:c.signal,storage,onProgress:(done,total)=>setProg({done,total})})
   const nt=translatedTrack(t,r);await persist([...tracks,nt]);setSel(nt.id)
   setNote({err:!!r.failed,t:r.failed?`Translated ${r.translated} of ${r.translated+r.failed} lines. ${friendlyError(r.error)} The rest stay in the original language.`:'Translated to English. Machine translation can contain mistakes.'})}
  catch(e){setNote({err:!(e instanceof TranslationError&&e.code==='cancelled'),t:`${friendlyError(e)} Your original subtitles are unchanged.`})}
  finally{setProg(null);ctl.current=null}}
 const r=cur?reason(cur):null
 const overlay=text?<View pointerEvents="none" style={{position:'absolute',left:0,right:0,bottom:44,alignItems:'center',paddingHorizontal:16}}><Text style={{fontSize:settings.subSize,color:'#fff',backgroundColor:'#000c',paddingHorizontal:10,paddingVertical:3,borderRadius:6,textAlign:'center'}}>{text}</Text></View>:null
 const panel=<View accessibilityLabel="Subtitles" style={{margin:16,padding:14,borderRadius:16,backgroundColor:C.panel,borderColor:C.line,borderWidth:1,gap:10}}>
  <Text style={{color:C.text,fontWeight:'700'}}>Subtitles</Text>
  <ScrollView horizontal showsHorizontalScrollIndicator={false}><Chip l="Off" on={sel==='off'} press={()=>setSel('off')}/>{tracks.map(t=><Chip key={t.id} l={t.label.length>28?t.label.slice(0,26)+'…':t.label} on={sel===t.id} press={()=>setSel(t.id)}/>)}</ScrollView>
  {cur?.machine&&<Text style={{color:C.warn}}>Machine-translated. It can contain mistakes.</Text>}
  <View style={{flexDirection:'row',alignItems:'center',gap:8,flexWrap:'wrap'}}><Text style={{color:C.mut}}>Size {settings.subSize}</Text><Btn l="−" press={()=>setSettings({...settings,subSize:Math.max(14,settings.subSize-2)})}/><Btn l="+" press={()=>setSettings({...settings,subSize:Math.min(36,settings.subSize+2)})}/>
   <Text style={{color:C.mut,marginLeft:8}}>Delay {delay.toFixed(1)}s</Text><Btn l="−" press={()=>setDelay(Math.max(-5,delay-0.5))}/><Btn l="+" press={()=>setDelay(Math.min(5,delay+0.5))}/></View>
  <Text style={{color:C.mut}}>Language of the file you’re adding</Text>
  <ScrollView horizontal showsHorizontalScrollIndicator={false}>{SUB_LANGS.map(([k,n])=><Chip key={k} l={n} on={lang===k} press={()=>setLang(k)}/>)}</ScrollView>
  <Btn l="Add an SRT or WebVTT file" press={()=>void pick()}/>
  {cur&&<View style={{gap:8}}>
   {cur.origin!=='translated'&&r===null&&<Text style={{color:C.mut}}>This track is already English.</Text>}
   {cur.origin!=='translated'&&r===''&&!prog&&<Btn pri l="Translate to English" press={()=>void translate(cur)}/>}
   {prog&&<View style={{gap:8}}><Text style={{color:C.text}} accessibilityLiveRegion="polite">Translating… {Math.min(prog.done,prog.total)} of {prog.total}</Text><Btn l="Cancel" press={()=>ctl.current?.abort()}/></View>}
   {r?<Text style={{color:C.mut}}>{r}</Text>:null}
   <Btn l="Remove track" press={()=>{const id=cur.id;setSel('off');void persist(tracks.filter(t=>t.id!==id&&t.from!==id))}}/></View>}
  {note&&<Text accessibilityRole={note.err?'alert':undefined} style={{color:note.err?C.warn:C.ok}}>{note.t}</Text>}
  <Text style={{color:C.mut,fontSize:12}}>No subtitle files are bundled for the catalog yet; add your own. Translation is offered only when the server’s provider supports the file’s language.</Text></View>
 return{overlay,panel}}
