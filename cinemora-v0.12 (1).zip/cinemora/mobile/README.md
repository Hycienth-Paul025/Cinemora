# Cinemora Android (Expo + React Native)

Untested: this project was written without a network or Android toolchain, so nothing here has been installed, type-checked or run. Expect small fixes on first run. Written against Expo SDK 56 (React Native 0.85, released May 2026); run `npx expo install --fix` so package versions match the SDK.

## What is shared with the web app
`../shared` holds the platform-neutral code used by both apps: types, source management and availability rules (`sources.ts`), search, sample data, and the TMDB metadata client (`metadata.ts`, storage injected). The web app re-exports these files. The web app still has its own `src/services/tmdb.ts` (localStorage); moving it onto `shared/metadata.ts` is a small follow-up. Mobile-only: screens, navigation (Expo Router), AsyncStorage persistence, `expo-video` playback.

## Status
| Feature | Status |
|---|---|
| Tabs (Home, Explore, Search, Downloads, Profile), details, sources screen | Written |
| Playback with `expo-video`: native controls, fullscreen, PiP, speed, resume, specific errors, retry | Written; only verified, region-allowed sources play |
| Persistent watchlist, progress, recent searches, country and subtitle-size preferences (AsyncStorage) | Written |
| Live metadata (search, details, genres, pagination) | Needs `EXPO_PUBLIC_CATALOG_PROXY_URL` (the TMDB proxy from the web README) |
| Supabase sign-in and sync | Not built on mobile |
| Offline downloads (license-gated, private storage, progress, pause/resume/cancel, delete, storage view, offline playback) | Written, NOT tested on a device. See "Offline downloads" |
| Subtitles: choose/add SRT and WebVTT, size, delay, English translation through your proxy | Written; shared logic unit-tested (16 tests), screens untested. See root README "Subtitles" |

## Run it
```
cd mobile
npm install
npx expo install --fix        # aligns versions with the SDK
cp .env.example .env          # optional: add your proxy URL and anon key
npx expo start                # scan the QR code with Expo Go on an Android phone
```
- Press `a` to use an Android emulator instead (Android Studio, free).
- If Expo Go rejects a module, build a development client: `npx expo run:android`.
- Check setup problems with `npx expo-doctor` and types with `npm run typecheck`.

## Build an APK (three free routes)
Before any build, set a permanent `android.package` in `app.json` (the placeholder is `com.example.cinemora`; it cannot change after a Play release) and add an app icon.
1. **EAS cloud build** (free Expo account): `npm i -g eas-cli && eas login && eas build -p android --profile preview`. The `preview` profile in `eas.json` produces an installable `.apk`. Put the whole `cinemora` folder in one git repository first so `../shared` is uploaded with the build. Expo manages the signing key for you.
2. **Local build, no account**: install JDK 17 and the Android SDK, then `npx expo run:android --variant release`. It generates `android/` and builds an APK under `android/app/build/outputs/apk/release/`. It is signed with a debug key, which is fine for testing but not for Google Play.
3. **`eas build --local`**: same EAS config, built on your machine (still needs the free Expo account).

Install the APK: copy it to the phone and allow "install unknown apps" for your file manager or browser, or run `adb install app-release.apk`.

## Test checklist
Navigation on every tab; Explore filters and paging; Search (typo, empty result, offline); Details for a sample title and, with the proxy set, a TMDB title; Sintel playback, resume after closing, airplane-mode error then Try again; change country and confirm regional rules; kill and reopen the app and confirm watchlist, progress and preferences persisted.

## Free vs paid
| Item | Cost |
|---|---|
| Expo SDK, Expo Router, expo-video, React Native, Android Studio, local builds, sideloading APKs | Free |
| EAS Build free plan | Free; at last check up to 15 Android builds a month in a low-priority queue (waits can be long, and free builds have a shorter time limit). Verify at expo.dev/pricing |
| EAS Starter plan | About $19/month for priority builds and build credit. Optional |
| Google Play Console | One-time registration fee (about $25 at last check; confirm). Needed only to publish on Google Play, not to share an APK |
| Supabase free tier, TMDB free API tier | Free within limits. TMDB's free tier is for non-commercial use; commercial use needs a TMDB agreement |
| Video hosting | Free for third-party sources you link to (for example the Internet Archive). Hosting your own files costs storage and bandwidth |

## Offline downloads (v0.7)
**Rules enforced in code** (`canDownload` in `shared/sources.ts`, used by the download manager and the UI): the source must pass the normal availability check (verified, not withdrawn or expired, allowed in your country), its license must permit downloads, it must not be marked `drm: true`, and it must be a plain file (mp4/webm/ogv), not HLS. Otherwise no Download button appears and the reason is shown. Currently only the three verified Blender films qualify.

**How it works** (`src/downloads.ts`, `src/DownloadControl.tsx`, Downloads tab):
- Files are written to the app's `documentDirectory` (app-private internal storage), never to the gallery or shared folders. `allowBackup` is off so Android does not copy them into cloud backups. Uninstalling or clearing app data removes them.
- Uses `expo-file-system/legacy` `createDownloadResumable` (confirmed present in SDK 56 and 57 docs) for progress, pause and resume. Cancel and delete stop the transfer, delete the file and drop the record.
- Before starting: license check, free-space check (file size from a HEAD request plus 100 MB margin), and a size estimate in the UI.
- Finished files are verified (HTTP 200/206, non-empty, size equals the expected size) before being marked complete.
- Offline playback: the player prefers the downloaded `file://` copy through `expo-video`. The license is re-checked at play time, so a withdrawn or expired source blocks playback and offers "Delete downloaded copy". Records are saved in AsyncStorage; if Android cleared the file, the record is dropped on next launch.
- Storage management: Downloads tab shows space used by Cinemora and free device space, with per-item delete and Delete all.

**Limits and placeholders (be aware)**
- Downloads run in the app process. There is no foreground service or notification, so Android may stop a download when the app is closed. After an explicit Pause, Resume continues from the saved point. After an interruption with no saved resume point, Resume restarts from zero.
- DRM: only DRM-free files are downloaded. Protected content (Widevine offline licenses) is refused, not circumvented.
- Not built: Wi-Fi-only setting, background download service and notifications, HLS/DASH offline, download queue limits, per-download quality choice (each title has one file), subtitles in downloads.
- Progress after Resume depends on how the library reports resumed bytes; check it in the test below.

**Tested: NO. I could not run an Android device, emulator or build tools.** Everything above is untested code. Device test script:
1. Phone on Wi-Fi, app installed from an APK. Open Sintel, tap Download. Expect a size estimate, then a moving progress bar. Confirm the file is NOT visible in the Photos app or the Files app.
2. Pause mid-way, wait, Resume. Expect progress to continue (not restart) and the final file to play to the end.
3. Pause, force-close the app, reopen. Expect "Paused"; Resume should continue. Repeat without pausing first (force-close while downloading): expect Resume to restart from zero.
4. Cancel mid-way: record disappears and storage used returns to its previous value.
5. Let one finish. Turn on airplane mode, open Downloads, tap Play offline: video plays, resume position works after leaving and returning.
6. Delete it: file is gone, storage figure drops, Play offline disappears.
7. Fill the phone almost full (or test on a small emulator disk): Download shows a clear "not enough space" message.
8. Switch country in Profile to a region not allowed for a test source (edit `territories` for testing) and confirm download and offline playback are blocked with an explanation.
9. Set a source's `withdrawn: true`, rebuild, open an existing download: playback is blocked and "Delete downloaded copy" is offered.
10. Download two titles at once; pause one; delete all.
Record failures and device model/Android version when reporting.
